# Clean UI/UX Wireframe Principles

## Purpose

Use these principles when creating Antigravity prompts for enterprise workflow screens, operational dashboards, approval screens, data-entry screens, queue screens, and compliance-heavy systems.

## Core Layout Principles

1. Reduce unused white space
   - Use the available width with meaningful content.
   - Replace large blank areas with summary cards, next actions, queue statistics, filters, progress, exception details, or audit history.
   - Keep breathing room, but avoid empty panels that make the system look unfinished.

2. Align everything properly
   - Use a consistent grid.
   - Align headings, labels, fields, cards, tables, buttons, icons, and section headers.
   - Keep repeated elements the same size where possible.
   - Keep buttons in predictable positions: primary action on the right, secondary actions nearby but visually weaker.

3. Use clear visual hierarchy
   - Top: page title, module name, record identifiers, current status, primary action.
   - Upper middle: summary cards, key metrics, next action.
   - Middle: main work area such as queue, form, checklist, table, or task card.
   - Lower or side area: comments, exceptions, attachments, history, audit trail.

4. Make workflow status visible
   - Show current status, current owner, next owner, pending action, due/created time, and exception state.
   - Use badges/chips instead of long status paragraphs.
   - Keep status colours consistent and restrained.

5. Keep screens stakeholder-friendly
   - Use simple labels and action wording.
   - Avoid technical jargon.
   - Make the next step obvious.
   - Keep review/approval language clear and calm.

## Recommended Screen Structure

Use this structure for most workflow screens:

1. Header bar
   - System/module name
   - Screen or stage name
   - Record identifiers
   - Current status chip
   - Last updated timestamp
   - Primary action if appropriate

2. Summary area
   - Total records, pending, completed, exceptions, rejected, or ready-for-next-stage counts
   - Key identifiers or critical values
   - Current owner and next owner

3. Main work area
   - Queue table, active task card, data-entry form, checklist, report table, or approval panel
   - Clear primary action
   - Inline validation messages

4. Supporting detail area
   - Evidence/files, comments, exception reasons, related records, calculated values, preview panel, or side summary

5. Handoff/sign-off area
   - Review or approval action
   - Confirmation dialog if the action is important
   - User, role, timestamp, and status after completion

6. Audit/history area
   - Read-only activity log
   - Comments and previous decisions
   - Previous stage handover notes
   - Change history

## Data Flow Principles

1. Show what comes into the screen
   - Source module, previous stage, uploaded file, API feed, manual entry, or selected record.
   - Use a read-only source-data panel when users need context but should not edit it.

2. Show what the user changes
   - Editable fields should look editable.
   - Mandatory fields should be obvious.
   - Calculated/read-only values should be visually different from inputs.

3. Show what the system creates
   - Status changes, timestamps, calculated values, generated references, audit records, and handoff records.
   - Keep system-generated values visible after the action completes.

4. Show where the record goes next
   - Next queue, next module, next department, or next role.
   - After completion, show a short confirmation with the new status and next destination.

5. Show exceptions clearly
   - Capture reason, owner, evidence, comment, status, and resolution action.
   - Never allow exceptions to be hidden in generic comments only.

## Component Patterns

### Queue Table
Use for records waiting for action. Include record number, product/item/customer, quantity/value if relevant, current stage, required action, assigned user/department, exception status, last updated, and action button.

### Active Task Card
Use when the user selects one record. Show key details, required checks, editable fields, evidence/files, comments, sign-off, and next action in one compact area.

### Summary Cards
Use for quick operational visibility. Keep cards equal width and aligned. Use short labels and meaningful counts/statuses.

### Form Panel
Use for structured data entry. Group fields by meaning. Put validation close to fields. Avoid long single-column forms when there is enough width for two-column grouping.

### Evidence / Attachment Upload
Use for screenshots, documents, photos, approvals, or proof files. Show upload status, preview, uploaded by, timestamp, and whether the file is mandatory.

### Checklist
Use for repeatable checks. Include pass/fail/not applicable where relevant. Require reason and evidence for failed or exception items.

### Sign-Off / Approval Dialog
Use for important completion steps. Confirmation should be clear, for example: "Are you sure you want to sign off this stage?" After confirmation, show user, role, date/time, and make signed fields read-only.

### Exception Handling
Use visible exception badges and a structured reason area. Include owner, date/time, severity/impact if useful, and resolution status.

### Audit / History Panel
Use a read-only table or timeline. Include action, user, role, date/time, previous status, new status, and comment/reason.

## Visual Style Rules

- Use a modern enterprise SaaS style.
- Keep it compact, professional, clean, and calm.
- Use soft cards, subtle borders, consistent spacing, and readable tables.
- Avoid excessive decorative graphics, oversized icons, and unnecessary illustrations.
- Use colour mainly for status, alerts, and action priority.
- Keep tables scannable with clear column names and row actions.
- Ensure responsive behaviour for standard desktop screens.
- Avoid designing everything as separate cards; use tables when users need to compare multiple records.
- Avoid hiding key workflow steps inside menus unless they are secondary actions.

## Spacing and Alignment Standards

- Use consistent outer margins.
- Keep section gaps visually equal.
- Use consistent card padding.
- Keep form labels and inputs aligned.
- Align table columns and row actions.
- Keep primary and secondary buttons in consistent positions across screens.
- Avoid floating elements that do not align with the grid.
- Reduce vertical scrolling by using tabs, side panels, accordions, or two-column layouts where appropriate.

## Prompt Phrases to Reuse

- "Use a compact enterprise layout that reduces unused white space without making the screen feel crowded."
- "Align all sections to a consistent grid with equal spacing and clean vertical rhythm."
- "Preserve the existing business logic and do not change supplied data."
- "Make the screen easy for non-technical stakeholders and operational users to understand."
- "Show the full data flow: source data, user-entered data, system-generated data, output, and next handoff."
- "Use clear status chips, primary actions, validation messages, and read-only audit history."
- "Place evidence upload, comments, exception reason, approval/sign-off, and timestamp close to the action they support."
