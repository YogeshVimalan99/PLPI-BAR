---
name: enterprise-wireframe-designer
description: generate clean ui/ux design principles and ready-to-paste antigravity prompts for enterprise workflow screens from screenshots, rough process notes, stage names, data-flow explanations, or existing screen requirements. use this skill when the user wants ai-generated wireframes, screen redesign direction, navigation flow, form/table layout, role-based workflow screens, or data-flow-aware ui guidance for business systems such as plpi, cascade, 3pl, pharmacy, warehouse, qa, compliance, or other internal operational platforms.
---

# Enterprise Wireframe Designer

## Goal

Create practical, ready-to-paste Antigravity prompts that make AI generate clean, modern, professional workflow screens. Use the user's screenshots, rough notes, stage names, business rules, and data-flow explanation to define screens that are compact, aligned, easy to understand, and suitable for operational users.

Do not lock designs to PLPI only. Treat PLPI/pharmaceutical workflows as an important example domain, but apply the same design principles to any enterprise screen the user describes.

## Standard Workflow

1. Identify the system/module, screen purpose, user role, workflow stage, input data, output data, and next handoff.
2. Preserve all supplied business logic, labels, values, quantities, statuses, and data relationships unless the user explicitly asks to improve wording.
3. Convert rough notes into a structured screen and data-flow specification.
4. Apply the principles from `references/clean-uiux-wireframe-principles.md`.
5. Produce a ready-to-paste Antigravity prompt with sections for objective, screen flow, data flow, layout, components, interactions, validation, visual rules, and non-negotiables.
6. Add assumptions only when needed. Prefer a best-effort prompt over asking unnecessary follow-up questions.

## Default Output Format

Use this format unless the user asks for a different structure:

```markdown
## Antigravity Prompt

Create or update the wireframe screen for: [system/module/screen or workflow name].

### Objective
[1-3 sentences explaining what the screen must help the user complete.]

### Input Context
- Existing screen/screenshot: [summarise what was provided]
- Process notes: [summarise the core business rules]
- Workflow stage/range: [stage, journey, or process range]
- Primary users: [roles]
- Data shown on screen: [important input data]
- Data captured by screen: [important output data]

### Screen Flow
[Explain how the user enters the screen, what they do first, what happens next, and where the record moves after completion.]

### Data Flow
- Source data: [where the screen data comes from]
- User-entered data: [what the user must enter/upload/select]
- System-generated data: [status, timestamp, calculated values, audit entries]
- Output/handoff: [what is saved and which next module/stage receives it]
- Read-only data: [what must be visible but not editable]

### Layout Direction
[Describe the recommended layout in practical screen terms: header, summary, main work area, side panel, table/form, actions, history.]

### Required UI Sections
1. [section name] - [purpose]
2. [section name] - [purpose]
3. [section name] - [purpose]

### Key Components
- [component] - [what it shows/does]
- [component] - [what it shows/does]

### Workflow / Interaction Rules
- [rule]
- [rule]

### Validation, Evidence, and Audit
[Required validations, mandatory fields, reason capture, evidence upload, approval/sign-off, timestamp, and audit trail expectations if relevant.]

### UI/UX Principles to Follow
- Use a clean, compact enterprise layout with less unused white space.
- Align all cards, fields, tables, buttons, and section headers to a consistent grid.
- Use clear visual hierarchy: title, status, summary, main action area, supporting details, history.
- Use space purposefully; replace empty areas with useful summary, next action, progress, filters, or history panels.
- Keep labels simple and stakeholder-friendly.
- Use consistent spacing, card widths, table columns, button placement, and status chips.
- Make the primary action obvious and keep secondary actions visually quieter.
- Design the screen so a user can understand what to do next within a few seconds.

### Non-Negotiables
- Do not change the supplied business logic or data meaning.
- Do not remove required checks, approvals, evidence capture, comments, timestamps, or audit trail elements.
- Do not invent unrelated modules or decorative content.
- Keep the design professional, responsive, operationally useful, and suitable for stakeholder review.
```

## Core Design Rules

Always include these expectations when relevant:

- Use a compact but breathable enterprise layout; avoid large unused blank spaces.
- Align to a consistent grid, preferably a 12-column structure for desktop screens.
- Keep spacing consistent: equal card padding, equal section gaps, equal form-field heights, and aligned table columns.
- Put the most important status, record identifiers, and next action near the top.
- Group related information into clear sections: summary, active task, data entry, evidence/files, comments, exceptions, audit/history.
- Use cards for summaries and active work; use tables for queues, lists, history, and comparison data.
- Keep primary actions predictable, usually top-right of the active section or bottom-right of a form.
- Keep destructive or exception actions separated from normal completion actions.
- Use status chips/badges for Pending, In Progress, Completed, Exception, Approved, Rejected, On Hold, or Released states.
- Show read-only information clearly; do not make locked data look editable.
- Keep wording simple enough for non-technical stakeholders and operational users.

## Data-Flow Design Rules

When the user explains how data should move:

- Identify the record lifecycle: created, queued, assigned, reviewed, completed, rejected, moved to next stage, archived.
- Separate input data, editable data, calculated data, system-generated data, and read-only history.
- Show source and destination clearly, especially when one module hands over to another.
- Make ownership clear: current owner, previous owner, next owner, department, role, or queue.
- Make status changes visible and auditable.
- Put validation near the field or action that triggers it.
- Show handoff confirmation after completion: next stage, timestamp, user, and resulting status.
- Never hide important exceptions; show reason, owner, evidence, and resolution status.

## Handling Screenshots

When the user provides screenshots:

- Preserve the original screen purpose, data, logo, and brand identity unless the user asks for a full redesign.
- Improve layout, spacing, alignment, hierarchy, readability, and action placement.
- Remove visual congestion by grouping sections properly, not by deleting required content.
- Replace empty space with meaningful elements such as summary cards, filters, next actions, status panels, or audit/history.
- Keep existing data labels unless there is a clear readability issue.

## Handling Rough Process Notes

When the user provides rough notes:

- Convert them into clean product language.
- Break long paragraphs into screen sections, workflow steps, interaction rules, and data-flow rules.
- Identify users, inputs, outputs, approvals, handoffs, and exceptions.
- Turn operational actions into UI components: queue, task card, checklist, form, upload, sign-off, reason capture, comment, status update, audit log.
- Keep the final Antigravity prompt concise and directly usable.

## Domain Defaults

Use these only when the user gives no better context:

- Design style: modern enterprise SaaS, clean, compact, responsive, professional.
- Screen users: operators, supervisors, QA/review users, managers, admin users, pharmacy/warehouse/business users.
- Common screen types: dashboard, queue, record detail, approval screen, data-entry form, report screen, exception screen, audit/history screen, role-based worklist.
- Compliance-heavy systems: include evidence upload, controlled sign-off, timestamp, user name, reason capture, read-only history, and audit trail.
- PLPI/pharma systems: include electronic line clearance, batch/stage status, QA/RP/QP review patterns, evidence capture, and controlled release status when relevant.

## Quality Checklist Before Final Answer

Before responding, verify that the Antigravity prompt:

- Names the exact screen, module, or workflow stage.
- Preserves all user-supplied logic and data meaning.
- Includes screen flow and data flow when the user provides workflow details.
- Gives compact layout and reduced white-space guidance.
- Gives alignment/grid guidance.
- Includes validation, evidence, approval, sign-off, and audit trail guidance when relevant.
- Is ready to paste into Antigravity.
- Does not over-explain design theory unless the user asks for principles only.

## Reference

For detailed design principles, flow patterns, and component patterns, consult `references/clean-uiux-wireframe-principles.md` when extra detail is needed.
