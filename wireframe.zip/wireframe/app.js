﻿const stages = [
  {
    id: "packing-list",
    code: "Stage 1",
    title: "Goods-In / Packing List",
    loginTitle: "Packing List Login",
    user: "goods.in",
    role: "Goods-In User",
    owner: "Goods-In",
    status: "active",
    entry: "Supplier delivery and PO available",
    next: "RPi Pack / Product Check Log",
    approval: "Goods-In digital sign off",
    checks: [
      "Search the PO and pull packing list details into PLPI.",
      "Confirm supplier, delivery, invoice and product quantities.",
      "Upload supplier invoice, supplier declaration and temperature record.",
      "Complete Goods-In checklist digitally instead of printing the paper checklist.",
      "Sign off so the RPi Pack documents are available for downstream review."
    ],
    evidence: ["Purchase order", "Supplier invoice", "Supplier declaration", "Temperature record", "Goods-In checklist"],
    controls: [
      "Packing List cannot be completed until mandatory RPi Pack documents are attached.",
      "Goods-In sign off captures user, date and time.",
      "Completed documents are visible in the QP electronic batch pack."
    ],
    progress: [28, 20]
  },
  {
    id: "rp-pack",
    code: "Stage 2",
    title: "RPi Task",
    loginTitle: "RPi Task Login",
    user: "rp.user",
    role: "Responsible Person",
    owner: "RPi",
    status: "active",
    entry: "Goods-In sign off completed and documents attached",
    next: "BAR Creation",
    approval: "RPi digital sign off",
    checks: [
      "Review all Goods-In documents (Supplier Invoice, PO, Supplier Packing List, Supplier Declaration, Temperature Record, Goods Receiving Checklist, Delivery Details).",
      "Review the generated PO Packing List document.",
      "Confirm completeness and compliance of the RPi Pack.",
      "Provide digital sign off to release the RPi Pack for BAR creation."
    ],
    evidence: ["Goods-In Uploaded Pack", "Generated PO Packing List", "RPi Approval Check"],
    controls: [
      "RPi must verify all uploaded documents before sign off.",
      "Digital sign off captures user, date and time.",
      "Approved RPi Pack enables the downstream BAR Creation stage."
    ],
    progress: [0, 0]
  },
  {
    id: "batch-checker",
    code: "Stage 3",
    title: "Batch Checker",
    loginTitle: "Batch Checker Login",
    user: "batch.checker",
    role: "Batch Checker",
    owner: "Checker Team",
    status: "active",
    entry: "PO Packing List and RPi Pack approved",
    next: "BNS Batch Add",
    approval: "Batch check verification and PCL generation",
    checks: [
      "Search the PO to list all products associated to it.",
      "Select a product line to perform batch checking.",
      "Verify all product and packaging details against the reference sample.",
      "Record manufacturer address details and save.",
      "Generate the digital PCL sheet and complete line clearance.",
      "Print carton and box labels after verification."
    ],
    evidence: ["PCL generation", "Verification check", "Line clearance confirmation"],
    controls: [
      "Verification must be recorded for each batch line before label printing.",
      "Print PCL is required for downstream line clearance.",
      "Digital sign off captures user, date, and time."
    ],
    progress: [40, 25]
  },
  {
    id: "regulatory-task",
    code: "Stage 4",
    title: "Regulatory Task",
    loginTitle: "Regulatory Task Login",
    user: "reg.user",
    role: "Regulatory User",
    owner: "Regulatory",
    status: "active",
    entry: "BAR issued",
    next: "Under Construction",
    approval: "Regulatory approval",
    checks: [
      "Perform regulatory checks.",
      "Placeholder dummy stage."
    ],
    evidence: [],
    controls: [],
    progress: [0, 0]
  },
  {
    id: "bar-creation",
    code: "Stage 4",
    title: "BAR Creation",
    loginTitle: "BNS Batch Add Login",
    user: "bar.creation",
    role: "BAR Creation User",
    owner: "BAR Issuing User",
    status: "complete",
    entry: "Completed Product Check Log and sample pack",
    next: "Label Printing",
    approval: "Digital BAR issue confirmation",
    checks: [
      "Select the batch from BNS Batch Add after Batch Checking completion.",
      "Verify BAR details against PCL, product sample, batch number, expiry, and quantity.",
      "Review related batch or in-transit alerts before issuing BAR.",
      "Generate BAR sequence and confirm all pages are available.",
      "Complete digital line clearance before handoff."
    ],
    evidence: ["Generated BAR pack", "PCL and sample verification", "Related batch alert decision", "Digital line clearance"],
    controls: [
      "BAR cannot be issued until PCL and sample checks are complete.",
      "All BAR confirmations are timestamped with user identity.",
      "Mismatch routes are recorded before handoff."
    ],
    progress: [100, 92]
  },
  {
    id: "label-printing",
    code: "Stage 5",
    title: "Printer",
    loginTitle: "Printer Login",
    user: "printer.user",
    role: "Printer User",
    owner: "Print Team",
    status: "active",
    entry: "Issued BAR pack",
    next: "Leaflet Printing",
    approval: "Operator print and line clearance confirmation",
    checks: [
      "Open the printer module and retrieve batch details from the BAR queue.",
      "Confirm calculated label quantity and reboxing instruction where applicable.",
      "Check label details against BAR, PCL, system details, and sample.",
      "Record test label acceptance before full print run.",
      "Capture first and last label evidence digitally."
    ],
    evidence: ["Test label evidence", "First printed label", "Last printed label", "Finish line clearance"],
    controls: [
      "Full label printing remains blocked until the test label is accepted.",
      "Quantity change requires recorded reboxing approval evidence.",
      "RRF hold is raised for detail mismatch."
    ],
    progress: [64, 50]
  },
  {
    id: "leaflet-printing",
    code: "Stage 6",
    title: "Leaflet Printing",
    loginTitle: "Printer Login",
    user: "leaflet.print",
    role: "Leaflet Printing User",
    owner: "Print Team",
    status: "active",
    entry: "Completed label printing",
    next: "Carton / Braille Preparation",
    approval: "Master copy acceptance",
    checks: [
      "Retrieve batch from the Leaflet Printing queue.",
      "Verify leaflet reference, product, strength, PL number, and format.",
      "Print and review the master/test copy before full quantity.",
      "Record leaflet quantity printed and any waste or reprint reason.",
      "Complete digital finish line clearance."
    ],
    evidence: ["Master/test leaflet", "Foreign leaflet reference", "Quantity print record", "Line clearance"],
    controls: [
      "Full leaflet print is disabled until master copy check is complete.",
      "Reference and version are visible in the electronic batch pack.",
      "Rejected master copies are retained as exception evidence."
    ],
    progress: [48, 33]
  },
  {
    id: "carton-braille",
    code: "Stage 7",
    title: "Carton / Braille Preparation",
    loginTitle: "Pre Printed Material Login",
    user: "carton.braille",
    role: "Carton / Braille User",
    owner: "Packaging Team",
    status: "active",
    entry: "Completed leaflet printing",
    next: "Leaflet Folding",
    approval: "Route-specific preparation confirmation",
    checks: [
      "Confirm reboxing or relabelling route from BAR instruction.",
      "For reboxing, verify carton reference, location, box ID, and issued quantity.",
      "For relabelling, verify braille requirement and declaration/reference.",
      "Upload carton or braille sample evidence.",
      "Record digital line clearance before stage completion."
    ],
    evidence: ["Carton reference evidence", "Braille sample evidence", "Handheld issue record", "Route decision record"],
    controls: [
      "Route decision is driven by BAR/process instruction.",
      "Carton issue remains on hold until location, box ID, and quantity match.",
      "Braille preparation requires declaration/reference confirmation."
    ],
    progress: [58, 42]
  },
  {
    id: "leaflet-folding",
    code: "Stage 8",
    title: "Leaflet Folding",
    loginTitle: "Leaflet Folding Login",
    user: "leaflet.fold",
    role: "Leaflet Folding User",
    owner: "Folding Operator",
    status: "active",
    entry: "Prepared cartons or braille route",
    next: "Pre Assembly",
    approval: "Folding completion confirmation",
    checks: [
      "Open Leaflet Folding queue and select the BAR.",
      "Confirm operator identity and batch number.",
      "Recheck one printed leaflet before folding.",
      "Confirm folding format and leaflet size.",
      "Record folded leaflets placed in the correct batch box or bucket."
    ],
    evidence: ["Leaflet pre-fold check", "Fold format confirmation", "Operator scan record", "Completion timestamp"],
    controls: [
      "Batch and user are captured before folding starts.",
      "Folded leaflets remain linked to the batch box/bucket.",
      "Stage completion removes the batch from the folding queue."
    ],
    progress: [74, 67]
  },
  {
    id: "pre-assembly-qc",
    code: "Stage 9",
    title: "Pre Assembly",
    loginTitle: "Pre Assembly Login",
    user: "preassembly.qc",
    role: "Pre Assembly User",
    owner: "QC",
    status: "hold",
    entry: "Folded leaflets and batch pack received",
    next: "Production Control / Room Allocation",
    approval: "QC digital completion",
    checks: [
      "Confirm batch is active in the Pre Assembly module.",
      "Check labels, sample, PCL, leaflet, braille/carton, and mock-up details.",
      "Prepare the assembly reference sample using the selected mock-up.",
      "Record blank label or butter paper quantities and comments where applicable.",
      "Upload sample evidence and complete digital QC confirmation."
    ],
    evidence: ["Assembly reference sample", "Mock-up", "Label and leaflet evidence", "QC line clearance"],
    controls: [
      "Inactive batches cannot proceed.",
      "Pre Assembly is blocked by label, sample, leaflet, braille, or mock-up mismatch.",
      "Prepared sample evidence becomes part of the QP review pack."
    ],
    progress: [38, 25]
  },
  {
    id: "room-allocation",
    code: "Stage 10",
    title: "Production Control / Room Allocation",
    loginTitle: "Production Controller Login",
    user: "production.control",
    role: "Production Controller",
    owner: "Production Control",
    status: "active",
    entry: "Completed Pre Assembly",
    next: "Assembly Room Operations",
    approval: "Room allocation confirmation",
    checks: [
      "Review batches waiting for room allocation.",
      "Verify random sample against BAR and reference pack.",
      "Confirm box count, product details, expiry, and label/reference details.",
      "Select available assembly room and record planned start.",
      "Complete digital Process 7 confirmation."
    ],
    evidence: ["Room allocation record", "Random sample check", "Box quantity confirmation", "Production Control line clearance"],
    controls: [
      "Room allocation is not available when sample or BAR details mismatch.",
      "Room, owner, date, and time are captured digitally.",
      "Allocated room is visible to Assembly Room users."
    ],
    progress: [52, 44]
  },
  {
    id: "assembly-room",
    code: "Stage 11",
    title: "Assembly Room Operations",
    loginTitle: "Assembly Room Login",
    user: "assembly.room",
    role: "Assembly Room User",
    owner: "Assembly Team",
    status: "active",
    entry: "Allocated assembly room",
    next: "Post-Assembly QC",
    approval: "Assembly completion and reconciliation",
    checks: [
      "Start the batch in the assigned room and record pre-start checks.",
      "Confirm line clearance, labels, leaflets, components, sample, and mock-up.",
      "Record assembly team briefing and batch start time.",
      "Capture IPC checks and photo evidence during assembly.",
      "Complete reconciliation for issued, used, damaged, surplus, and leftover items."
    ],
    evidence: ["Pre-start line clearance", "IPC photo evidence", "Reconciliation record", "Damage or leftover evidence"],
    controls: [
      "Assembly cannot start until pre-start checks are confirmed.",
      "IPC evidence is retained for Pre-QP and QP review.",
      "Reconciliation must be complete before stage handoff."
    ],
    progress: [70, 61]
  },
  {
    id: "post-assembly-qc",
    code: "Stage 12",
    title: "Post Assembly",
    loginTitle: "Production Checking Login",
    user: "postassembly.qc",
    role: "Post-Assembly QC User",
    owner: "QC",
    status: "active",
    entry: "Completed assembly and reconciliation",
    next: "Pre-QP",
    approval: "Post-Assembly QC completion",
    checks: [
      "Segregate completed boxes and documentation.",
      "Select sample quantity based on batch size and check against mock-up.",
      "Verify full quantity, box count, label placement, and pack presentation.",
      "Print and apply quarantine labels after confirmed box/quantity entry.",
      "Move stock to quarantine and update status digitally."
    ],
    evidence: ["Sample pack check", "Box count record", "Quarantine labels", "Post-QC line clearance"],
    controls: [
      "Quarantine labels are not printed until quantity and box count are confirmed.",
      "Incorrect quarantine labels must be voided and reprinted.",
      "Completion makes the batch visible in the Pre-QP queue."
    ],
    progress: [56, 50]
  },
  {
    id: "pre-qp",
    code: "Stage 13",
    title: "Pre-QP",
    loginTitle: "Pre-QP / Release Log Login",
    user: "pre.qp",
    role: "Pre-QP User",
    owner: "Pre-QP",
    status: "active",
    entry: "Completed Post-Assembly QC and quarantined stock",
    next: "QP Release",
    approval: "Pre-QP evidence pack approval",
    checks: [
      "Select batch from Release Log queue by priority or pallet order.",
      "Review full digital batch record from BAR creation through Post-Assembly QC.",
      "Check document presence, completeness, IPC photos, and reconciliation.",
      "Record random sample removal and line clearance.",
      "Create digital release log and submit complete pack to QP."
    ],
    evidence: ["Release log", "Random sample record", "IPC review confirmation", "Pre-QP approval"],
    controls: [
      "Pre-QP cannot submit to QP with missing required evidence.",
      "IPC and reconciliation review are explicit release readiness checks.",
      "Green release log is replaced by digital release log."
    ],
    progress: [82, 77]
  },
  {
    id: "qp-release",
    code: "Stage 14",
    title: "QP Approval / Batch Release",
    loginTitle: "QP Approval Login",
    user: "qp.release",
    role: "QP User",
    owner: "QP",
    status: "complete",
    entry: "Pre-QP approved digital batch pack",
    next: "Process Complete",
    approval: "QP electronic approval",
    checks: [
      "Review complete electronic batch pack, sample, and leftover components.",
      "Check supplier, invoice, declaration, temperature, PCL, and BAR evidence.",
      "Review reconciliation, IPC evidence, QMS status, and release logs.",
      "Record approved quantity and electronic signature.",
      "Confirm release label application and close the BAR process."
    ],
    evidence: ["QP approval", "Batch Summary Log", "QP release log", "Release label confirmation"],
    controls: [
      "QP approval is blocked by unresolved quality issue or missing required record.",
      "Electronic signature captures user, date, time, and approval outcome.",
      "Released batch is locked from further stage editing."
    ],
    progress: [96, 90]
  }
];

let packingListMode = "add";
let packingListSearch = "";
let packingListSelectedPo = "C13719";
let packingListSignedOff = false;
let packingListRecord = null;
let packingLabelPrintRecords = {};
let packingListGenerated = false;
let generatedPackingListSnapshots = {};
function isPackingListLocked() {
  return packingListGenerated === true;
}
let packingListRowsState = null;
let poPackingListSignoff = null;
let packingListAddInitialized = {};
let rpDocumentsSignoff = null;
let rpPackWorkflows = {};
let selectedRpPackPo = null;
let selectedRpApprovalPo = null;
let rpApprovalSignoffs = {};
let rpApprovalAnswers = {};
let rpApprovalComments = {};
let rpApprovalSearch = "";
let rpRejectionComments = {};
let changeOfPackSizeData = {};
let pendingStageId = stages[0].id;
let currentLogin = null;
let isAuthenticated = false;
let signOffRecord = null;
let barCreatedRecord = null;
let currentStageId = null;
let barCreated = false;
let barMovedToNextStage = false;
let generatedBatchNumbers = [];
let bnsFilters = {
  country: "All",
  site: "All",
  category: "All",
  quantity: "",
  status: "Not Printed BAR",
  batch: "",
  mfgLot: "",
  objId: ""
};
let selectedProduct = null;
let labelSelectedProduct = null;
let labelPrintedBatchNumbers = [];
let labelPrintRecords = {};
let printerSection = "menu";
let leafletSelectedProduct = null;
let leafletPrintedBatchNumbers = [];
let leafletPrintRecords = {};
let cartonSelectedProduct = null;
let cartonPrintedBatchNumbers = [];
let cartonPrintRecords = {};
let brailleSelectedProduct = null;
let braillePrintedBatchNumbers = [];
let braillePrintRecords = {};
let printerSearch = "";
let leafletFoldingSelectedProduct = null;
let leafletFoldedBatchNumbers = [];
let leafletFoldingRecords = {};
let preAssemblySelectedProduct = null;
let preAssemblyCheckedBatchNumbers = [];
let preAssemblyRecords = {};
let preAssemblySearch = "";
let productionSelectedProduct = null;
let productionAllocatedBatchNumbers = [];
let productionRecords = {};
let productionSearch = "";
let assemblySelectedProduct = null;
let assembledBatchNumbers = [];
let assemblyRecords = {};
let assemblySearch = "";
let assemblyExtraIpcRows = 0;
let assemblyActiveTab = "materials";
let postAssemblySelectedProduct = null;
let postAssemblyCheckedBatchNumbers = [];
let postAssemblyRecords = {};
let postAssemblySearch = "";
let preQpSelectedProduct = null;
let preQpCheckedBatchNumbers = [];
let preQpRecords = {};
let preQpSearch = "";
let preQpReleaseLogSelection = [];
let qpSelectedProduct = null;
let qpReleasedBatchNumbers = [];
let qpCertifiedBatchNumbers = [];
let qpCertifiedLabelSelection = [];
let qpReleaseRecords = {};
let qpSearch = "";
let qpIdSearch = "";
let qpBatchSearch = "";
let qpStatusSearch = "";
let qpChecklistOpen = false;
let printerAuditTrail = [];
let printPreviewRequest = null;
let pendingSignoffAction = null;

const bnsProducts = [
  {
    status: "Active",
    site: "WHO",
    country: "CZECH REPUBLIC",
    partNo: "CZFLU120ACT",
    product: "Flutiform pressurised inhalation, suspension",
    ecma: "14/555/12-C",
    strength: "250/10mcg",
    packSize: "120 actuations",
    batch: "03A1582",
    expiry: "07/2027",
    quantity: "650",
    imp: "C13506",
    invoice: "15003594",
    description: "Flutiform inhalation",
    warehouse: "R6-B-01",
    pl: "18799/2922",
    productId: "5547",
    foreignName: "Flutiform suspenze k inhalaci v tlakovem obalu",
    unitsPerPack: "1",
    productIntroduced: "20 Jul 2016",
    leafletDate: "12 Jun 2025",
    dateRevised: "05 Nov 2025",
    variationInfo: "",
    supplierName: "DerStar Pharma SK s.r.o.",
    reviewDate: "04/04/2025",
    supplierInvoice: "15003602",
    manufLotNo: "25086A",
    category: "Reboxing",
    batchType: "Composite",
    routeInstruction: "Rebox into 120 actuations",
    routeType: "Reboxing",
    leafletRequired: true,
    leafletQuantity: "650",
    blisterRequired: "No",
    cartonQuantity: "650",
    brailleRequired: false,
    brailleQuantity: "0"
  },
  {
    status: "Active",
    site: "WHO",
    country: "FRANCE",
    partNo: "FRADA0.25TAB12",
    product: "ADARTEL Compr...",
    ecma: "3400939183947",
    strength: "0.25mg",
    packSize: "12",
    batch: "EN8B",
    expiry: "31-10-2025",
    quantity: "140",
    imp: "F4690",
    invoice: "26/FEX/566",
    description: "ADARTEL Film...",
    warehouse: "Q-25-A",
    pl: "18799/2070",
    productId: "5178",
    foreignName: "ADARTEL comprimes pellicules",
    unitsPerPack: "1",
    productIntroduced: "14 Feb 2019",
    leafletDate: "08 Jan 2025",
    dateRevised: "18 Mar 2025",
    variationInfo: "Braille required",
    supplierName: "Pharma Logistics FR",
    reviewDate: "22/04/2025",
    supplierInvoice: "FV612259",
    manufLotNo: "EN8B-25",
    category: "Relabelling",
    batchType: "Consolidated",
    routeInstruction: "Relabel only",
    routeType: "Relabelling",
    leafletRequired: true,
    leafletQuantity: "140",
    blisterRequired: "Yes",
    cartonQuantity: "0",
    brailleRequired: true,
    brailleQuantity: "140"
  },
  {
    status: "Active",
    site: "WHO",
    country: "SPAIN",
    partNo: "ESADA2TAB28",
    product: "ADARTREL com...",
    ecma: "67922",
    strength: "2mg",
    packSize: "28",
    batch: "C22W",
    expiry: "28-02-2025",
    quantity: "80",
    imp: "G4452",
    invoice: "NC24090412",
    description: "Adara cream",
    warehouse: "R8-C-01",
    pl: "18799/3264",
    productId: "5547",
    foreignName: "ADARTREL comprimidos",
    unitsPerPack: "1",
    productIntroduced: "11 Sep 2020",
    leafletDate: "04 Feb 2025",
    dateRevised: "09 Apr 2025",
    variationInfo: "Braille required",
    supplierName: "UAB Dinera",
    reviewDate: "09/09/2025",
    supplierInvoice: "NC24090412",
    manufLotNo: "C22W-02",
    category: "Relabelling",
    batchType: "Consolidated",
    routeInstruction: "Relabel only",
    routeType: "Relabelling",
    leafletRequired: true,
    leafletQuantity: "80",
    blisterRequired: "Yes",
    cartonQuantity: "0",
    brailleRequired: true,
    brailleQuantity: "80"
  }
];

bnsProducts.push(
  {
    status: "Variation",
    site: "WHO",
    country: "FRANCE",
    partNo: "FRAZA10EYE5ML",
    product: "AZARGA Collyre ...",
    ecma: "EU/1/08/482/001",
    strength: "10mg/ml + 5mg/ml",
    packSize: "5ml",
    batch: "3TED1A",
    expiry: "30-04-2025",
    quantity: "50",
    imp: "I20594",
    invoice: "77337",
    description: "AZARGA eye drops",
    warehouse: "IN ASSEMBLY",
    pl: "3685",
    productId: "5346",
    foreignName: "AZARGA collyre en suspension",
    unitsPerPack: "1",
    productIntroduced: "07 Mar 2018",
    leafletDate: "19 May 2025",
    dateRevised: "02 Jun 2025",
    variationInfo: "Variation copy required",
    supplierName: "DerStar Pharma SK s.r.o.",
    reviewDate: "11/05/2025",
    supplierInvoice: "77337",
    manufLotNo: "3TED1A-FR",
    category: "Relabelling",
    batchType: "Composite",
    routeInstruction: "Relabel only",
    routeType: "Relabelling",
    leafletRequired: true,
    leafletQuantity: "50",
    blisterRequired: "Yes",
    cartonQuantity: "0",
    brailleRequired: true,
    brailleQuantity: "50"
  },
  {
    status: "Tentative",
    site: "WHO",
    country: "ITALY",
    partNo: "ITBON70MG4",
    product: "BONASOL Soluzi...",
    ecma: "040622033",
    strength: "70mg",
    packSize: "4",
    batch: "I58352",
    expiry: "30-06-2025",
    quantity: "48",
    imp: "T4572",
    invoice: "35",
    description: "Alendronic acid oral solution",
    warehouse: "IN ASSEMBLY",
    pl: "3031",
    productId: "4522",
    foreignName: "BONASOL soluzione orale",
    unitsPerPack: "1",
    productIntroduced: "26 Oct 2017",
    leafletDate: "17 Apr 2025",
    dateRevised: "21 Apr 2025",
    variationInfo: "",
    supplierName: "UAB Dinera",
    reviewDate: "18/05/2025",
    supplierInvoice: "35",
    manufLotNo: "I58352-IT",
    category: "Reboxing",
    batchType: "Composite",
    routeInstruction: "Rebox into 4 pack",
    routeType: "Reboxing",
    leafletRequired: true,
    leafletQuantity: "48",
    blisterRequired: "No",
    cartonQuantity: "48",
    brailleRequired: false,
    brailleQuantity: "0"
  },
  {
    status: "Active",
    site: "WHO",
    country: "PORTUGAL",
    partNo: "PTBRI90TAB56",
    product: "BRILIQUE",
    ecma: "EU/1/10/655/002",
    strength: "90mg",
    packSize: "56",
    batch: "VHUN",
    expiry: "31-10-2026",
    quantity: "100",
    imp: "T4651",
    invoice: "FF/54537",
    description: "Brilique film-coated tablets",
    warehouse: "IN ASSEMBLY",
    pl: "3999",
    productId: "5468",
    foreignName: "BRILIQUE comprimidos revestidos",
    unitsPerPack: "1",
    productIntroduced: "08 Aug 2016",
    leafletDate: "23 Jan 2025",
    dateRevised: "14 Feb 2025",
    variationInfo: "Cold chain not applicable",
    supplierName: "Pharma Logistics PT",
    reviewDate: "02/05/2025",
    supplierInvoice: "FF/54537",
    manufLotNo: "VHUN-PT",
    category: "Relabelling",
    batchType: "Consolidated",
    routeInstruction: "Relabel only",
    routeType: "Relabelling",
    leafletRequired: true,
    leafletQuantity: "100",
    blisterRequired: "Yes",
    cartonQuantity: "0",
    brailleRequired: true,
    brailleQuantity: "100"
  },
  {
    status: "Active",
    site: "WHO",
    country: "SPAIN",
    partNo: "ESBACNA10N15",
    product: "Bactroban pomada",
    ecma: "58868 (997585.2)",
    strength: "2% w/w",
    packSize: "15g",
    batch: "4U7R",
    expiry: "30-06-2025",
    quantity: "168",
    imp: "Y4322",
    invoice: "F/29628",
    description: "Bactroban ointment",
    warehouse: "IN ASSEMBLY",
    pl: "1411",
    productId: "120",
    foreignName: "Bactroban pomada",
    unitsPerPack: "1",
    productIntroduced: "03 Apr 2017",
    leafletDate: "10 Jan 2025",
    dateRevised: "01 Feb 2025",
    variationInfo: "",
    supplierName: "Spanish Pharma Supply",
    reviewDate: "20/04/2025",
    supplierInvoice: "F/29628",
    manufLotNo: "4U7R-ES",
    category: "Reboxing",
    batchType: "Composite",
    routeInstruction: "Rebox into 15g carton",
    routeType: "Reboxing",
    leafletRequired: true,
    leafletQuantity: "168",
    blisterRequired: "No",
    cartonQuantity: "168",
    brailleRequired: false,
    brailleQuantity: "0"
  },
  {
    status: "Active",
    site: "WHO",
    country: "BULGARIA",
    partNo: "BGBETM50MGT",
    product: "Betmiga",
    ecma: "EU/1/12/809/001",
    strength: "50mg",
    packSize: "30",
    batch: "23G0828",
    expiry: "30-06-2026",
    quantity: "82",
    imp: "Q17917",
    invoice: "1000049019",
    description: "Betmiga prolonged-release tablets",
    warehouse: "IN ASSEMBLY",
    pl: "3851",
    productId: "5302",
    foreignName: "Betmiga tablets",
    unitsPerPack: "1",
    productIntroduced: "16 Jun 2021",
    leafletDate: "08 May 2025",
    dateRevised: "27 May 2025",
    variationInfo: "Braille required",
    supplierName: "Balkan Pharma Supply",
    reviewDate: "28/05/2025",
    supplierInvoice: "1000049019",
    manufLotNo: "23G0828-BG",
    category: "Relabelling",
    batchType: "Consolidated",
    routeInstruction: "Relabel only",
    routeType: "Relabelling",
    leafletRequired: true,
    leafletQuantity: "82",
    blisterRequired: "Yes",
    cartonQuantity: "0",
    brailleRequired: true,
    brailleQuantity: "82"
  }
);

const welcomeWindow = document.querySelector("#welcome-window");
const dashboardWindow = document.querySelector("#dashboard-window");
const moduleWindow = document.querySelector("#module-window");
const loginModal = document.querySelector("#login-modal");
const signoffModal = document.querySelector("#signoff-modal");
const appConfirmModal = document.querySelector("#app-confirm-modal");
const createBarModal = document.querySelector("#create-bar-modal");
const printPreviewModal = document.querySelector("#print-preview-modal");
const printPreviewBody = document.querySelector("#print-preview-body");
const stageStrip = document.querySelector("#stage-strip");
const statusMessage = document.querySelector("#status-message");

function findStage(stageId) {
  if (stageId === "qp-certified") {
    const qpStage = stages.find((stage) => stage.id === "qp-release") || stages[0];
    return {
      ...qpStage,
      id: "qp-certified",
      title: "QP Certified Batches",
      loginTitle: "QP Certified Batches Login",
      entry: "QP approved, rejected, or held batches"
    };
  }
  return stages.find((stage) => stage.id === stageId) || stages[0];
}

function statusLabel(status) {
  if (status === "complete") return "Complete";
  if (status === "hold") return "Hold";
  return "In Progress";
}

function statusClass(status) {
  if (status === "complete") return "done-status";
  if (status === "hold") return "hold-status";
  return "active-status";
}

function renderStageStrip() {
  const topLaunchers = [
    { label: "Machine", icon: "?", inactive: true },
    { label: "PI Label Print", icon: "?", inactive: true },
    { label: "Pre Printed Material (Goods In)", icon: "?", inactive: true },
    { label: "Pre Printed Material (Checker)", icon: "?", inactive: true },
    { label: "Pre Printed Material (Stock Controller)", icon: "?", inactive: true },
    { label: "PPM Audit", icon: "AUD", inactive: true },
    { label: "PPM Locations", icon: "?", inactive: true },
    { label: "PPM Audit History", icon: "?", inactive: true },
    { label: "Regulatory Task", icon: "?", stageId: "regulatory-task" },
    { label: "Regulatory Log", icon: "LOG", inactive: true },
    { label: "Product Add", icon: "+", stageId: "bar-creation" },
    { label: "Product", icon: "?", inactive: true },
    { label: "Packing List", icon: "?", stageId: "packing-list" },
    { label: "Pre QP", icon: "?", stageId: "pre-qp" },
    { label: "Double Check", icon: "?", stageId: "pre-assembly-qc" },
    { label: "Batch Checker", icon: "?", stageId: "batch-checker" },
    { label: "BNS Batch Add", icon: "?", stageId: "bar-creation" },
    { label: "Printer", icon: "?", stageId: "label-printing" }
  ];
  const sideLaunchers = [
    { label: "Users", icon: "??", inactive: true },
    { label: "Leaflet Folding", icon: "?", stageId: "leaflet-folding" },
    { label: "Production Controller", icon: "?", stageId: "room-allocation" },
    { label: "Check IN/OUT", icon: "?", stageId: "assembly-room" },
    { label: "Assembly Room", icon: "?", stageId: "assembly-room" },
    { label: "Production Checking", icon: "?", stageId: "post-assembly-qc" },
    { label: "QP Release Dashboard", icon: "?", stageId: "qp-release" },
    { label: "QP Certified Batches", icon: "?", stageId: "qp-certified" },
    { label: "Released Labels", icon: "?", inactive: true },
    { label: "User Rights", icon: "??", inactive: true },
    { label: "Raw Pack Scanned Summary", icon: "?", inactive: true },
    { label: "Raw Pack Scanning", icon: "?", inactive: true },
    { label: "MISC", icon: "misc", inactive: true },
    { label: "Action Master", icon: "?", inactive: true },
    { label: "Product Recall", icon: "?", inactive: true },
    { label: "Room Log", icon: "?", inactive: true },
    { label: "PLPI Report", icon: "?", inactive: true },
    { label: "Goods In", icon: "X", stageId: "packing-list" },
    { label: "Logout", icon: "?", inactive: true },
    { label: "Exit", icon: "?", inactive: true }
  ];
  const renderLauncher = (item) => `
    <button class="legacy-launcher ${item.inactive ? "inactive" : ""}" type="button" ${item.stageId ? `data-login-stage="${item.stageId}"` : ""}>
      <span class="legacy-launcher-icon">${item.icon}</span>
      <span class="legacy-launcher-label">${item.label}</span>
    </button>
  `;
  stageStrip.innerHTML = `
    <div class="legacy-desktop-shell">
      <div class="legacy-top-launchers">${topLaunchers.map(renderLauncher).join("")}</div>
      <div class="legacy-desktop-workspace"><span>.</span></div>
      <div class="legacy-side-launchers">${sideLaunchers.map(renderLauncher).join("")}</div>
    </div>
  `;
}
function openDashboard() {
  welcomeWindow.classList.add("hidden");
  moduleWindow.classList.add("hidden");
  dashboardWindow.classList.remove("hidden");
  currentStageId = null;
  statusMessage.textContent = "Select a module to log in.";
}

function openLogin(stageId) {
  const stage = findStage(stageId);
  pendingStageId = stage.id;
  document.body.classList.add("login-transition");
  currentStageId = null;
  welcomeWindow.classList.add("hidden");
  dashboardWindow.classList.add("hidden");
  moduleWindow.classList.add("hidden");
  moduleWindow.className = "internal-window module-window hidden";
  document.querySelectorAll(".toolbar-item, .launcher-item, .legacy-launcher").forEach((item) => item.classList.remove("active"));
  document.querySelector("#stage-work-content").innerHTML = "";
  document.querySelector("#module-queue").innerHTML = "";
  document.querySelector("#stage-evidence").innerHTML = "";
  document.querySelector("#phase-controls").innerHTML = "";
  document.querySelector("#login-title").textContent = "Login";
  document.querySelector("#login-user").value = stage.user;
  document.querySelector("#login-password").value = "password";
  loginModal.classList.remove("hidden");
  statusMessage.textContent = stage.id === "bar-creation" ? "Login requested for BNS Batch Add" : `Login requested for ${stage.loginTitle}`;
}

function closeLogin() {
  document.body.classList.remove("login-transition");
  loginModal.classList.add("hidden");
  moduleWindow.classList.add("hidden");
  dashboardWindow.classList.add("hidden");
  welcomeWindow.classList.add("hidden");
  currentStageId = null;
  statusMessage.textContent = "Login cancelled. Select a module to continue.";
}

function openSignoffDialog() {
  signoffModal.classList.remove("hidden");
  statusMessage.textContent = "User sign off confirmation requested";
}

function closeSignoffDialog() {
  signoffModal.classList.add("hidden");
  statusMessage.textContent = "User sign off cancelled";
}

function requestUserSignoff(action, stageName = "this stage") {
  pendingSignoffAction = action;
  let operation = "sign off";
  if (stageName === "RPi Approval") {
    operation = "sign off RPi Task";
  } else if (stageName === "Packing List" || stageName === "generated PO Packing List") {
    operation = "sign off Packing List";
  } else if (stageName === "RPi Pack documents") {
    operation = "sign off RPi Pack documents";
  } else if (stageName === "selected PO Packing Label lines" || stageName === "Packing Label") {
    operation = "Print Packing Label";
  } else if (stageName === "this assembly page") {
    operation = "sign off this assembly page";
  } else if (stageName === "QP Release Log") {
    operation = "sign off QP Release Log";
  } else if (stageName === "Label Printing" || stageName === "Leaflet Printing" || stageName === "Carton Printing" || stageName === "Braille" || stageName === "Braille Printing" || stageName === "Leaflet Folding" || stageName === "Pre Assembly" || stageName === "Production Controller" || stageName === "Production Checking" || stageName === "Pre QP" || stageName === "QP Release") {
    operation = "sign off " + stageName;
  } else {
    operation = "sign off " + stageName;
  }

  const isGeneratedPoSignoff = stageName === "generated PO Packing List";
  document.body.classList.toggle("generated-po-signoff-active", isGeneratedPoSignoff);
  appConfirmModal.classList.toggle("generated-po-signoff-confirm", isGeneratedPoSignoff);
  const isPrint = operation.toLowerCase().startsWith("print");
  const dialogTitle = isPrint ? `${operation} Confirmation` : "Confirm Sign Off";
  const subCopy = isPrint ? "Are you sure to continue with printing?" : "";

  document.querySelector("#app-confirm-title").textContent = dialogTitle;
  document.querySelector("#app-confirm-header").textContent = `Are you sure you want to ${operation}?`;
  document.querySelector("#app-confirm-copy").textContent = subCopy;

  const yesButton = document.querySelector("#app-confirm-yes");
  if (yesButton) {
    if (isPrint) {
      yesButton.textContent = "Yes, Print";
    } else {
      yesButton.textContent = "Yes, Sign Off";
    }
  }

  document.body.appendChild(appConfirmModal);
  appConfirmModal.style.position = "fixed";
  appConfirmModal.style.zIndex = "2147483600";
  const confirmWindow = appConfirmModal.querySelector(".confirm-window");
  if (confirmWindow) {
    confirmWindow.style.position = "relative";
    confirmWindow.style.zIndex = "2147483601";
  }
  appConfirmModal.classList.remove("hidden");
  statusMessage.textContent = "User sign off confirmation requested";
}

function closeAppConfirm() {
  pendingSignoffAction = null;
  document.body.classList.remove("generated-po-signoff-active");
  appConfirmModal.classList.remove("generated-po-signoff-confirm");
  appConfirmModal.classList.add("hidden");
  statusMessage.textContent = "User sign off cancelled";
}

function requestAppConfirmation(action, title, header, copy, yesText) {
  pendingSignoffAction = action;
  document.querySelector("#app-confirm-title").textContent = title;
  document.querySelector("#app-confirm-header").textContent = header;
  document.querySelector("#app-confirm-copy").textContent = copy;
  const yesButton = document.querySelector("#app-confirm-yes");
  if (yesButton) yesButton.textContent = yesText;
  appConfirmModal.classList.remove("hidden");
  statusMessage.textContent = `${title} requested`;
}

function confirmAppSignoff() {
  const action = pendingSignoffAction;
  pendingSignoffAction = null;
  document.body.classList.remove("generated-po-signoff-active");
  appConfirmModal.classList.remove("generated-po-signoff-confirm");
  appConfirmModal.classList.add("hidden");
  if (action) action();
}
function htmlSafe(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[char]);
}

function closeSystemPopup() {
  document.querySelector("#system-popup-modal")?.remove();
}

function showSystemMessage(title, header, copy) {
  closeSystemPopup();
  document.body.insertAdjacentHTML("beforeend", `
    <div class="modal-backdrop" id="system-popup-modal" role="dialog" aria-modal="true" aria-labelledby="system-popup-title">
      <div class="confirm-window app-confirm-window">
        <div class="internal-title">
          <span id="system-popup-title">${htmlSafe(title)}</span>
          <button type="button" class="close-button" data-system-popup-close>X</button>
        </div>
        <div class="confirm-body app-confirm-body">
          <div class="app-confirm-icon">OK</div>
          <div>
            <h2>${htmlSafe(header)}</h2>
            <p>${htmlSafe(copy)}</p>
          </div>
          <div class="confirm-actions">
            <button class="classic-button primary" type="button" data-system-popup-close>OK</button>
          </div>
        </div>
      </div>
    </div>
  `);
  document.querySelectorAll("[data-system-popup-close]").forEach((button) => {
    button.addEventListener("click", closeSystemPopup);
  });
}

function completeRpReject(poNo, comment) {
  if (rpPackWorkflows[poNo]) {
    rpRejectionComments[poNo] = comment;
    rpPackWorkflows[poNo].status = "Rejected by RPi";
    rpPackWorkflows[poNo].rpChecklistOpen = false;
    rpPackWorkflows[poNo].viewedDocs = {};
    rpPackWorkflows[poNo].rpTaskViewedDocs = {};
    rpPackWorkflows[poNo].documents = rpPackWorkflows[poNo].documents.map((doc) => ({ ...doc, uploaded: false, fileName: "", verified: false }));
    selectedRpApprovalPo = null;
    selectedRpPackPo = null;
    packingListMode = "documents";
    currentStageId = "packing-list";
    statusMessage.textContent = `PO ${poNo} rejected by RPi. Comments returned to RPi Pack for re-upload.`;
    renderStage("packing-list");
  }
}

function openRpRejectPopup(poNo) {
  closeSystemPopup();
  document.body.insertAdjacentHTML("beforeend", `
    <div class="modal-backdrop" id="system-popup-modal" role="dialog" aria-modal="true" aria-labelledby="system-popup-title">
      <div class="confirm-window app-confirm-window rp-reject-popup-window">
        <div class="internal-title">
          <span id="system-popup-title">RPi Task Reject</span>
          <button type="button" class="close-button" data-system-popup-close>X</button>
        </div>
        <div class="confirm-body rp-reject-popup-body">
          <h2>Reject PO ${htmlSafe(poNo)}</h2>
          <p>Enter rejection comments to return this PO to RPi Pack for corrected document upload.</p>
          <textarea id="rp-reject-comment-input" rows="5" placeholder="Rejection comments"></textarea>
          <small id="rp-reject-comment-error" class="rp-reject-comment-error"></small>
          <div class="confirm-actions">
            <button class="classic-button" type="button" data-system-popup-close>Cancel</button>
            <button class="classic-button danger" type="button" id="rp-reject-confirm-btn">Reject</button>
          </div>
        </div>
      </div>
    </div>
  `);
  document.querySelectorAll("[data-system-popup-close]").forEach((button) => {
    button.addEventListener("click", closeSystemPopup);
  });
  document.querySelector("#rp-reject-confirm-btn")?.addEventListener("click", () => {
    const input = document.querySelector("#rp-reject-comment-input");
    const error = document.querySelector("#rp-reject-comment-error");
    const comment = input.value.trim();
    if (!comment) {
      error.textContent = "Rejection comments are required.";
      input.focus();
      return;
    }
    closeSystemPopup();
    completeRpReject(poNo, comment);
  });
  setTimeout(() => document.querySelector("#rp-reject-comment-input")?.focus(), 0);
}

function openCreateBarDialog(batchNumber) {
  selectedProduct = bnsProducts.find((product) => product.batch === batchNumber) || bnsProducts[0];
  document.querySelector("#create-bar-title").textContent = "Print BAR Confirmation";
  document.querySelector("#create-bar-header").textContent = "Are you sure you want to Print BAR?";
  document.querySelector("#create-bar-copy").textContent = `Do you want to create BAR for selected Batch_NO ${selectedProduct.batch}?`;
  createBarModal.classList.remove("hidden");
  statusMessage.textContent = "Create BAR confirmation requested";
}

function closeCreateBarDialog() {
  createBarModal.classList.add("hidden");
  statusMessage.textContent = "Create BAR cancelled";
}

function confirmCreateBar() {
  barCreated = true;
  barMovedToNextStage = false;
  signOffRecord = null;
  barCreatedRecord = {
    user: currentLogin ? currentLogin.user : "bar.creation",
    dateTime: new Date().toLocaleString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    })
  };
  createBarModal.classList.add("hidden");
  renderStage("bar-creation");
  statusMessage.textContent = `BAR ${selectedProduct.batch} created. Complete Process 1 checks before user sign off.`;
}

function updateSignoffAvailability() {
  const checks = [...document.querySelectorAll("[data-process-check]")];
  const signoffButton = document.querySelector("#user-signoff-button");
  if (!checks.length || !signoffButton || signOffRecord) return;

  const allChecked = checks.every((check) => check.checked);
  signoffButton.disabled = !allChecked;
  if (allChecked) {
    statusMessage.textContent = "All Process 1 checks are complete. User Sign Off is available.";
  } else {
    statusMessage.textContent = "Complete all Process 1 checks to enable User Sign Off.";
  }
}

function getLabelRequirements(product) {
  return product.routeType === "Reboxing"
    ? [
{ label: "Carton Label", reference: product.ecma, size: product.packSize, quantity: product.quantity },
{ label: "End Of Pack Label", reference: product.ecma, size: product.packSize, quantity: product.quantity },
{ label: "Security Seals", reference: "Seal", size: "Standard", quantity: "2" }
      ]
    : [
{ label: "Blister / Pack Label", reference: product.ecma, size: product.packSize, quantity: product.quantity },
{ label: "Obscure Label", reference: product.ecma, size: "Standard", quantity: product.quantity }
      ];
}

function getLeafletRequirements(product) {
  return [
    { label: "Leaflet", reference: product.ecma, size: `${product.packSize} leaflet`, quantity: product.leafletQuantity }
  ];
}

function getBrailleRequirements(product) {
  return [
    { label: "Braille Label", reference: product.ecma, size: product.packSize, quantity: product.brailleQuantity || product.quantity },
    { label: "Braille Declaration Copy", reference: product.pl, size: "Master copy", quantity: "1" }
  ];
}

function getPrintRecord(type, batchNumber) {
  if (type === "label") return labelPrintRecords[batchNumber] || {};
  if (type === "leaflet") return leafletPrintRecords[batchNumber] || {};
  if (type === "braille") return braillePrintRecords[batchNumber] || {};
  return {};
}

function savePrintRecord(type, batchNumber, record) {
  if (type === "label") labelPrintRecords[batchNumber] = record;
  if (type === "leaflet") leafletPrintRecords[batchNumber] = record;
  if (type === "braille") braillePrintRecords[batchNumber] = record;
}

function getPrintProduct(type, batchNumber) {
  if (type === "label") return labelSelectedProduct || bnsProducts.find((item) => item.batch === batchNumber);
  if (type === "leaflet") return leafletSelectedProduct || bnsProducts.find((item) => item.batch === batchNumber);
  if (type === "braille") return brailleSelectedProduct || bnsProducts.find((item) => item.batch === batchNumber);
  return bnsProducts.find((item) => item.batch === batchNumber);
}

function getPrintRequirements(type, product) {
  if (type === "label") return getLabelRequirements(product);
  if (type === "leaflet") return getLeafletRequirements(product);
  if (type === "braille") return getBrailleRequirements(product);
  return [];
}

function getPrintInputSelector(type) {
  if (type === "label") return "[data-label-print-qty]";
  if (type === "leaflet") return "[data-leaflet-print-qty]";
  if (type === "braille") return "[data-braille-print-qty]";
  return "";
}

function getPrintItemDatasetKey(type) {
  if (type === "label") return "labelName";
  if (type === "leaflet") return "leafletName";
  if (type === "braille") return "brailleName";
  return "";
}

function collectRowExtras(type) {
  const extras = {};
  document.querySelectorAll(`[data-${type}-extra-qty]`).forEach((input) => {
    const item = input.dataset.extraItem;
    const reason = document.querySelector(`[data-${type}-extra-reason][data-extra-item="${item}"]`);
    extras[item] = {
      quantity: input.value || "0",
      reason: reason ? reason.value || "" : ""
    };
  });
  return extras;
}

function rowExtraHasMissingReason(rowExtras = {}) {
  return Object.values(rowExtras).some((extra) => Number(extra.quantity || 0) > 0 && !extra.reason);
}

function getPrintedEvidenceStatus(type, record = {}) {
  const printedItems = record.itemsPrinted || [];
  return printedItems.every((item) => {
    const first = document.querySelector(`[data-${type}-evidence-first][data-evidence-item="${item}"]`);
    const last = document.querySelector(`[data-${type}-evidence-last][data-evidence-item="${item}"]`);
    return Boolean(first && first.files && first.files.length && last && last.files && last.files.length);
  });
}

function isPrintItemDone(record, label) {
  return Boolean(record.itemsPrinted && record.itemsPrinted.includes(label));
}

function hasExtraPrintReason(type, itemLabel) {
  const reason = document.querySelector(`[data-${type}-extra-reason][data-extra-item="${itemLabel}"]`);
  return Boolean(reason && reason.value);
}

function syncTestPrintButtons(type) {
  document.querySelectorAll(`[data-test-preview-print][data-preview-type="${type}"]`).forEach((button) => {
    const itemLabel = button.dataset.previewItem;
    const record = getPrintRecord(type, button.dataset.previewBatch);
    button.disabled = isPrintItemDone(record, itemLabel) || !hasExtraPrintReason(type, itemLabel);
  });
}

function getPreviewPageCount(type) {
  if (type === "leaflet") return 4;
  if (type === "braille") return 1;
  return 2;
}

function openPrintPreview(type, batchNumber, itemLabel, isTestPrint = false) {
  const product = getPrintProduct(type, batchNumber);
  if (!product) return;
  const requirement = getPrintRequirements(type, product).find((item) => item.label === itemLabel);
  if (!requirement) return;
  const input = document.querySelector(`${getPrintInputSelector(type)}[data-${type}-name="${itemLabel}"]`);
  const quantity = input ? input.value || "0" : requirement.quantity;
  const pageCount = getPreviewPageCount(type);
  printPreviewRequest = { type, batchNumber, itemLabel, quantity, isTestPrint };
  document.querySelector("#print-preview-title").textContent = isTestPrint ? "Test Print Preview" : "Print Preview";
  printPreviewBody.innerHTML = `
    <div class="preview-toolbar">
      <div>
<strong>${itemLabel}</strong>
<span>${product.product} | ${product.batch} | Qty ${quantity}</span>
      </div>
      <label>Printer
<select id="preview-printer">
  <option>PLPI Label Printer 01</option>
  <option>PLPI Leaflet Printer 02</option>
  <option>PLPI Braille Printer 03</option>
  <option>PDF Preview</option>
</select>
      </label>
      <button class="classic-button primary" type="button" id="preview-print-button">${isTestPrint ? "Test Print" : "Print"}</button>
    </div>
    <div class="preview-page-count">Pages: ${pageCount}</div>
    <div class="preview-pages">
      ${Array.from({ length: pageCount })
.map(
  (_, index) => `
    <section class="preview-page preview-${type}">
      <div class="preview-page-header">${itemLabel} | Page ${index + 1} of ${pageCount}</div>
      <div class="preview-art">
<strong>${product.product}</strong>
<span>${product.strength} | ${product.packSize}</span>
<span>B&S Batch Number: ${product.batch}</span>
<span>Expiry: ${product.expiry}</span>
<i></i>
      </div>
    </section>
  `
)
.join("")}
    </div>
  `;
  printPreviewModal.classList.remove("hidden");
  statusMessage.textContent = `Preview opened for ${itemLabel}.`;
}

function closePrintPreview() {
  const shouldRefreshRpTask = currentStageId === "rp-pack" && activePreviewPo && rpPackWorkflows[activePreviewPo]?.rpTaskViewedDocs?.["generated-packing-list"] === true;
  const shouldRefreshRpPackDocs = currentStageId === "packing-list" && packingListMode === "documents" && activePreviewPo && rpPackWorkflows[activePreviewPo]?.viewedDocs?.["generated-packing-list"] === true;
  printPreviewRequest = null;
  document.querySelector("#print-preview-title").textContent = "Print Preview";
  printPreviewModal.classList.add("hidden");
  if (shouldRefreshRpTask) {
    renderStage("rp-pack");
    setTimeout(updateRpApprovalAvailability, 0);
  } else if (shouldRefreshRpPackDocs) {
    renderStage("packing-list");
    setTimeout(updateRpDocumentsAvailability, 0);
  }
}

function confirmPreviewPrint() {
  if (!printPreviewRequest) return;
  if (printPreviewRequest.type === "preqp-release-log") {
    const batches = printPreviewRequest.batches || [];
    const count = batches.length;
    const qpId = assignQpReleaseLogId(batches);
    closePrintPreview();
    preQpReleaseLogSelection = [];
    renderStage("pre-qp");
    statusMessage.textContent = `QP Release Log ${qpId} printed for ${count} product${count === 1 ? "" : "s"}. Data moved to QP Release.`;
    return;
  }
  const { type, batchNumber, itemLabel, quantity, isTestPrint } = printPreviewRequest;
  const product = getPrintProduct(type, batchNumber);
  if (!product) return;
  if (isTestPrint) {
    auditPrinterAction(`${itemLabel} Test Printed`, product, `Test quantity printed: ${quantity}; printer: ${document.querySelector("#preview-printer") ? document.querySelector("#preview-printer").value : "Default"}.`);
    closePrintPreview();
    renderStage("label-printing");
    statusMessage.textContent = `Test print completed for ${itemLabel}. Final Print is still required to close the line.`;
    return;
  }
  const requirements = getPrintRequirements(type, product);
  const selector = getPrintInputSelector(type);
  const datasetKey = getPrintItemDatasetKey(type);
  const quantities = [...document.querySelectorAll(selector)].map((input) => ({
    label: input.dataset[datasetKey],
    quantity: input.value || "0"
  }));
  if (!quantities.some((item) => item.label === itemLabel)) {
    quantities.push({ label: itemLabel, quantity });
  }
  const existing = getPrintRecord(type, batchNumber);
  const itemsPrinted = Array.from(new Set([...(existing.itemsPrinted || []), itemLabel]));
  const printedQuantity = quantities.reduce(
    (total, item) => (itemsPrinted.includes(item.label) ? total + Number(item.quantity || 0) : total),
    0
  );
  const rowExtras = collectRowExtras(type);
  const allPrinted = requirements.every((item) => itemsPrinted.includes(item.label));
  const record = {
    ...existing,
    printed: allPrinted,
    printedQuantity,
    quantities,
    itemsPrinted,
    rowExtras,
    printedAt: new Date().toLocaleString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    })
  };
  savePrintRecord(type, batchNumber, record);
  auditPrinterAction(`${itemLabel} Printed`, product, `Quantity printed: ${quantity}; printer: ${document.querySelector("#preview-printer") ? document.querySelector("#preview-printer").value : "Default"}.`);
  closePrintPreview();
  renderStage("label-printing");
  statusMessage.textContent = allPrinted
    ? `${itemLabel} printed. All ${type} items printed; sign off.`
    : `${itemLabel} printed. Continue printing remaining ${type} items.`;
}

function updateLabelCompletionAvailability() {
  const completeButton = document.querySelector("#label-complete-button");
  if (!completeButton || !labelSelectedProduct) return;

  const record = labelPrintRecords[labelSelectedProduct.batch] || {};
  const rowExtras = collectRowExtras("label");
  const hasEvidence = true;
  const hasMissingExtraReason = rowExtraHasMissingReason(rowExtras);
  completeButton.disabled = !(record.printed && hasEvidence && !hasMissingExtraReason);

  if (!record.printed) {
    statusMessage.textContent = "Print each label row before user sign off.";
  } else if (hasMissingExtraReason) {
    statusMessage.textContent = "Select a reason for every extra label quantity.";
  } else {
    statusMessage.textContent = "Labels printed. User Sign Off is available.";
  }
}

function updateLeafletCompletionAvailability() {
  const submitButton = document.querySelector("#leaflet-complete-button");
  if (!submitButton || !leafletSelectedProduct) return;

  const record = leafletPrintRecords[leafletSelectedProduct.batch] || {};
  const rowExtras = collectRowExtras("leaflet");
  const hasEvidence = true;
  const hasMissingExtraReason = rowExtraHasMissingReason(rowExtras);
  submitButton.disabled = !(record.printed && hasEvidence && !hasMissingExtraReason);

  if (!record.printed) {
    statusMessage.textContent = "Print each leaflet row before user sign off.";
  } else if (hasMissingExtraReason) {
    statusMessage.textContent = "Select a reason for every extra leaflet quantity.";
  } else {
    statusMessage.textContent = "Leaflets printed. User Sign Off is available.";
  }
}

function updateCartonCompletionAvailability() {
  const submitButton = document.querySelector("#carton-complete-button");
  const extraQty = document.querySelector("#extra-carton-qty");
  const extraReason = document.querySelector("#extra-carton-reason");
  if (!submitButton || !cartonSelectedProduct) return;

  const record = cartonPrintRecords[cartonSelectedProduct.batch] || {};
  const hasEvidence = true;
  const hasExtraQty = Number(extraQty && extraQty.value ? extraQty.value : 0) > 0;
  const hasExtraReason = Boolean(extraReason && extraReason.value);
  const requirements = [
    { label: "Approved Carton" },
    { label: "Peel Out Carton" }
  ];
  const allCartonRowsConfirmed = record.printed || requirements.every((item) => isPrintItemDone(record, item.label));
  submitButton.disabled = !(allCartonRowsConfirmed && hasEvidence && (!hasExtraQty || hasExtraReason));

  if (!allCartonRowsConfirmed) {
    statusMessage.textContent = "Confirm Carton Quantity before user sign off.";
  } else if (hasExtraQty && !hasExtraReason) {
    statusMessage.textContent = "Select a reason for extra cartons.";
  } else {
    statusMessage.textContent = "Cartons confirmed. User Sign Off is available.";
  }
}

function updateBrailleCompletionAvailability() {
  const submitButton = document.querySelector("#braille-complete-button");
  if (!submitButton || !brailleSelectedProduct) return;

  const record = braillePrintRecords[brailleSelectedProduct.batch] || {};
  const rowExtras = collectRowExtras("braille");
  const hasEvidence = true;
  const hasMissingExtraReason = rowExtraHasMissingReason(rowExtras);
  submitButton.disabled = !(record.printed && hasEvidence && !hasMissingExtraReason);

  if (!record.printed) {
    statusMessage.textContent = "Print each braille row before user sign off.";
  } else if (hasMissingExtraReason) {
    statusMessage.textContent = "Select a reason for every extra braille quantity.";
  } else {
    statusMessage.textContent = "Braille labels printed. User Sign Off is available.";
  }
}

function updateLeafletFoldingAvailability() {
  const submitButton = document.querySelector("#leaflet-folding-complete-button");
  const quantity = document.querySelector("#leaflet-folding-quantity");
  const lineClearance = document.querySelector("#leaflet-folding-line-clearance");
  if (!submitButton || !leafletFoldingSelectedProduct) return;

  const hasQuantity = Boolean(quantity && Number(quantity.value) > 0);
  const lineClearanceComplete = Boolean(lineClearance && lineClearance.checked);
  submitButton.disabled = !(hasQuantity && lineClearanceComplete);

  if (!hasQuantity) {
    statusMessage.textContent = "Enter Leaflet Folding quantity before sign off.";
  } else if (!lineClearanceComplete) {
    statusMessage.textContent = "Confirm the Leaflet Folding count before sign off.";
  } else {
    statusMessage.textContent = "Leaflet Folding count confirmed. User Sign Off is available.";
  }
}

function completeLabelPrinting() {
  if (!labelSelectedProduct) return;
  const batchNumber = labelSelectedProduct.batch;
  const record = labelPrintRecords[batchNumber] || {};
  const rowExtras = collectRowExtras("label");
  labelPrintRecords[batchNumber] = { ...record, rowExtras };
  const now = getAssemblyAuditTimestamp();
  if (!labelPrintedBatchNumbers.includes(batchNumber)) {
    labelPrintedBatchNumbers.push(batchNumber);
  }
  auditPrinterAction("Label Printing Submitted", labelSelectedProduct, `Quantity printed: ${record.printedQuantity || labelSelectedProduct.quantity}; extras: ${JSON.stringify(rowExtras)}.`);
  const workflowState = document.querySelector("#label-workflow-state");
  if (workflowState) {
    workflowState.innerHTML = `Signed off by <strong>${currentLogin ? currentLogin.user : "label.print"}</strong> at <strong>${now}</strong>. Batch <strong>${batchNumber}</strong> moved to ${labelSelectedProduct.leafletRequired ? "Leaflet Printing" : "next applicable stage"}.`;
  }
  statusMessage.textContent = `Batch ${batchNumber} moved to ${labelSelectedProduct.leafletRequired ? "Leaflet Printing" : "next applicable stage"} after print sign off.`;
  const movesToLeaflet = labelSelectedProduct.leafletRequired;
  window.setTimeout(() => {
    labelSelectedProduct = null;
    printerSection = "label-list";
    renderStage("label-printing");
    statusMessage.textContent = movesToLeaflet
      ? `Batch ${batchNumber} moved to Leaflet Printing and is removed from Label Printing list.`
      : `Batch ${batchNumber} removed from Label Printing list.`;
  }, 1200);
}

function printLabels(batchNumber) {
  const product = bnsProducts.find((item) => item.batch === batchNumber);
  if (!product) return;
  const quantityInputs = [...document.querySelectorAll("[data-label-print-qty]")];
  const quantities = quantityInputs.map((input) => ({
    label: input.dataset.labelName,
    quantity: input.value || "0"
  }));
  const printedQuantity = quantities.reduce((total, item) => total + Number(item.quantity || 0), 0);
  const extraQty = document.querySelector("#extra-label-qty");
  const extraReason = document.querySelector("#extra-label-reason");
  labelSelectedProduct = product;
  labelPrintRecords[batchNumber] = {
    printed: true,
    printedQuantity: printedQuantity || product.quantity,
    quantities,
    extraQuantity: extraQty ? extraQty.value || "0" : "0",
    extraReason: extraReason ? extraReason.value || "N/A" : "N/A",
    printedAt: new Date().toLocaleString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    })
  };
  auditPrinterAction("Labels Printed", product, `Quantity printed: ${printedQuantity || product.quantity}; extra quantity: ${extraQty ? extraQty.value || "0" : "0"}; reason: ${extraReason ? extraReason.value || "N/A" : "N/A"}.`);
  renderStage("label-printing");
  statusMessage.textContent = `Labels printed for batch ${batchNumber}. Ready for sign off.`;
}

function printLeaflets(batchNumber) {
  const product = bnsProducts.find((item) => item.batch === batchNumber);
  if (!product) return;
  const quantityInputs = [...document.querySelectorAll("[data-leaflet-print-qty]")];
  const quantities = quantityInputs.map((input) => ({
    label: input.dataset.leafletName,
    quantity: input.value || "0"
  }));
  const printedQuantity = quantities.reduce((total, item) => total + Number(item.quantity || 0), 0);
  const extraQty = document.querySelector("#extra-leaflet-qty");
  const extraReason = document.querySelector("#extra-leaflet-reason");
  leafletSelectedProduct = product;
  leafletPrintRecords[batchNumber] = {
    printed: true,
    printedQuantity: printedQuantity || product.leafletQuantity,
    quantities,
    extraQuantity: extraQty ? extraQty.value || "0" : "0",
    extraReason: extraReason ? extraReason.value || "N/A" : "N/A",
    printedAt: new Date().toLocaleString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    })
  };
  auditPrinterAction("Leaflets Printed", product, `Quantity printed: ${printedQuantity || product.leafletQuantity}; extra quantity: ${extraQty ? extraQty.value || "0" : "0"}; reason: ${extraReason ? extraReason.value || "N/A" : "N/A"}.`);
  renderStage("label-printing");
  statusMessage.textContent = `Leaflets printed for batch ${batchNumber}. Ready for sign off.`;
}

function completeLeafletPrinting() {
  if (!leafletSelectedProduct) return;
  const batchNumber = leafletSelectedProduct.batch;
  const record = leafletPrintRecords[batchNumber] || {};
  const rowExtras = collectRowExtras("leaflet");
  leafletPrintRecords[batchNumber] = { ...record, rowExtras };
  if (!leafletPrintedBatchNumbers.includes(batchNumber)) {
    leafletPrintedBatchNumbers.push(batchNumber);
  }
  auditPrinterAction("Leaflet Printing Submitted", leafletSelectedProduct, `Quantity printed: ${record.printedQuantity || leafletSelectedProduct.leafletQuantity}; extras: ${JSON.stringify(rowExtras)}.`);
  const nextPrintStage = leafletSelectedProduct.routeType === "Reboxing"
    ? "Carton Printing"
    : leafletSelectedProduct.brailleRequired
      ? "Braille Printing"
      : "next applicable stage";
  statusMessage.textContent = `Batch ${batchNumber} moved to ${nextPrintStage}.`;
  window.setTimeout(() => {
    leafletSelectedProduct = null;
    printerSection = "label-list";
    renderStage("label-printing");
    statusMessage.textContent = `Batch ${batchNumber} removed from Leaflet Printing and moved to ${nextPrintStage}.`;
  }, 1200);
}

function printCartons(batchNumber) {
  const product = bnsProducts.find((item) => item.batch === batchNumber);
  if (!product) return;
  const quantityInputs = [...document.querySelectorAll("[data-carton-print-qty]")];
  const quantities = quantityInputs.map((input) => ({
    label: input.dataset.cartonName,
    quantity: input.value || "0"
  }));
  const printedQuantity = quantities.reduce((total, item) => total + Number(item.quantity || 0), 0);
  const extraQty = document.querySelector("#extra-carton-qty");
  const extraReason = document.querySelector("#extra-carton-reason");
  cartonSelectedProduct = product;
  cartonPrintRecords[batchNumber] = {
    printed: true,
    printedQuantity: printedQuantity || product.cartonQuantity || product.quantity,
    quantities,
    extraQuantity: extraQty ? extraQty.value || "0" : "0",
    extraReason: extraReason ? extraReason.value || "N/A" : "N/A",
    printedAt: new Date().toLocaleString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    })
  };
  auditPrinterAction("Carton Quantity Confirmed", product, `Quantity confirmed: ${printedQuantity || product.cartonQuantity || product.quantity}; extra quantity: ${extraQty ? extraQty.value || "0" : "0"}; reason: ${extraReason ? extraReason.value || "N/A" : "N/A"}.`);
  renderStage("label-printing");
  statusMessage.textContent = `Carton quantity confirmed for batch ${batchNumber}. Ready for sign off.`;
}

function completeCartonPrinting() {
  if (!cartonSelectedProduct) return;
  const batchNumber = cartonSelectedProduct.batch;
  const extraQty = document.querySelector("#extra-carton-qty");
  const extraReason = document.querySelector("#extra-carton-reason");
  const record = cartonPrintRecords[batchNumber] || {};
  if (!cartonPrintedBatchNumbers.includes(batchNumber)) {
    cartonPrintedBatchNumbers.push(batchNumber);
  }
  auditPrinterAction("Carton Printing Submitted", cartonSelectedProduct, `Quantity confirmed: ${record.printedQuantity || cartonSelectedProduct.cartonQuantity || cartonSelectedProduct.quantity}; extra quantity: ${extraQty ? extraQty.value || "0" : "0"}; reason: ${extraReason ? extraReason.value || "N/A" : "N/A"}.`);
  statusMessage.textContent = `Batch ${batchNumber} moved to next applicable stage.`;
  window.setTimeout(() => {
    cartonSelectedProduct = null;
    printerSection = "label-list";
    renderStage("label-printing");
    statusMessage.textContent = `Batch ${batchNumber} removed from Carton Printing and moved to next applicable stage.`;
  }, 1200);
}

function printBraille(batchNumber) {
  const product = bnsProducts.find((item) => item.batch === batchNumber);
  if (!product) return;
  const quantityInputs = [...document.querySelectorAll("[data-braille-print-qty]")];
  const quantities = quantityInputs.map((input) => ({
    label: input.dataset.brailleName,
    quantity: input.value || "0"
  }));
  const printedQuantity = quantities.reduce((total, item) => total + Number(item.quantity || 0), 0);
  const extraQty = document.querySelector("#extra-braille-qty");
  const extraReason = document.querySelector("#extra-braille-reason");
  brailleSelectedProduct = product;
  braillePrintRecords[batchNumber] = {
    printed: true,
    printedQuantity: printedQuantity || product.brailleQuantity || product.quantity,
    quantities,
    extraQuantity: extraQty ? extraQty.value || "0" : "0",
    extraReason: extraReason ? extraReason.value || "N/A" : "N/A",
    printedAt: new Date().toLocaleString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    })
  };
  auditPrinterAction("Braille Printed", product, `Quantity printed: ${printedQuantity || product.brailleQuantity || product.quantity}; extra quantity: ${extraQty ? extraQty.value || "0" : "0"}; reason: ${extraReason ? extraReason.value || "N/A" : "N/A"}.`);
  renderStage("label-printing");
  statusMessage.textContent = `Braille printed for batch ${batchNumber}. Ready for sign off.`;
}

function completeBraillePrinting() {
  if (!brailleSelectedProduct) return;
  const batchNumber = brailleSelectedProduct.batch;
  const record = braillePrintRecords[batchNumber] || {};
  const rowExtras = collectRowExtras("braille");
  braillePrintRecords[batchNumber] = { ...record, rowExtras };
  if (!braillePrintedBatchNumbers.includes(batchNumber)) {
    braillePrintedBatchNumbers.push(batchNumber);
  }
  auditPrinterAction("Braille Printing Submitted", brailleSelectedProduct, `Quantity printed: ${record.printedQuantity || brailleSelectedProduct.brailleQuantity || brailleSelectedProduct.quantity}; extras: ${JSON.stringify(rowExtras)}.`);
  statusMessage.textContent = `Batch ${batchNumber} moved to next applicable stage.`;
  window.setTimeout(() => {
    brailleSelectedProduct = null;
    printerSection = "label-list";
    renderStage("label-printing");
    statusMessage.textContent = `Batch ${batchNumber} removed from Braille Printing and moved to next applicable stage.`;
  }, 1200);
}

function completeLeafletFolding() {
  if (!leafletFoldingSelectedProduct) return;
  const batchNumber = leafletFoldingSelectedProduct.batch;
  const now = getAssemblyAuditTimestamp();
  leafletFoldingRecords[batchNumber] = {
    user: currentLogin ? currentLogin.user : "leaflet.fold",
    dateTime: now,
    quantity: document.querySelector("#leaflet-folding-quantity") ? document.querySelector("#leaflet-folding-quantity").value : leafletFoldingSelectedProduct.leafletQuantity,
    countConfirmed: true
  };
  if (!leafletFoldedBatchNumbers.includes(batchNumber)) {
    leafletFoldedBatchNumbers.push(batchNumber);
  }
  statusMessage.textContent = `Batch ${batchNumber} moved to Pre Assembly after Leaflet Folding sign off.`;
  window.setTimeout(() => {
    leafletFoldingSelectedProduct = null;
    renderStage("leaflet-folding");
    statusMessage.textContent = `Batch ${batchNumber} removed from Leaflet Folding list.`;
  }, 1200);
}

function confirmSignoff() {
  const now = new Date();
  const user = currentLogin ? currentLogin.user : "bar.creation";
  signOffRecord = {
    user,
    dateTime: now.toLocaleString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    })
  };

  appConfirmModal.classList.add("hidden");

  barMovedToNextStage = true;
  const batchNumber = selectedProduct ? selectedProduct.batch : "03A1582";
  if (!generatedBatchNumbers.includes(batchNumber)) {
    generatedBatchNumbers.push(batchNumber);
  }
  const workflowState = document.querySelector("#bar-workflow-state");
  const signoffButton = document.querySelector("#user-signoff-button");
  if (workflowState) {
    workflowState.classList.remove("hidden");
    workflowState.innerHTML = `Signed off by <strong>${signOffRecord.user}</strong> at <strong>${signOffRecord.dateTime}</strong>. Batch <strong>${batchNumber}</strong> moved to Printer - Label Printing list view.`;
  }
  if (signoffButton) {
    signoffButton.disabled = true;
    signoffButton.textContent = "Signed Off";
  }

  statusMessage.textContent = `${batchNumber} moved to Printer - Label Printing after sign off by ${signOffRecord.user}`;
  window.setTimeout(() => {
    barCreated = false;
    barCreatedRecord = null;
    renderStage("bar-creation");
    statusMessage.textContent = `Batch ${batchNumber} has moved to Printer - Label Printing and is removed from BNS Batch Add.`;
  }, 1200);
}

function submitLogin() {
  const stage = findStage(pendingStageId);
  currentLogin = {
    user: document.querySelector("#login-user").value,
    role: stage.role,
    stageId: stage.id
  };
  isAuthenticated = true;
  if (stage.id === "label-printing") {
    printerSection = "menu";
    labelSelectedProduct = null;
    leafletSelectedProduct = null;
    cartonSelectedProduct = null;
    brailleSelectedProduct = null;
  }
  document.body.classList.remove("pre-login");
  document.body.classList.remove("login-transition");
  loginModal.classList.add("hidden");
  renderStage(stage.id);
}

function loadLeafletFoldingDemo() {
  const stage = findStage("leaflet-folding");
  const product = bnsProducts.find((item) => item.batch === "03A1582") || bnsProducts[0];
  const batchNumber = product.batch;

  currentLogin = {
    user: stage.user,
    role: stage.role,
    stageId: stage.id
  };
  isAuthenticated = true;
  selectedProduct = product;
  leafletFoldingSelectedProduct = null;

  if (!generatedBatchNumbers.includes(batchNumber)) generatedBatchNumbers.push(batchNumber);
  if (!labelPrintedBatchNumbers.includes(batchNumber)) labelPrintedBatchNumbers.push(batchNumber);
  if (!leafletPrintedBatchNumbers.includes(batchNumber)) leafletPrintedBatchNumbers.push(batchNumber);

  labelPrintRecords[batchNumber] = labelPrintRecords[batchNumber] || {
    printed: true,
    printedBy: "printer.user",
    dateTime: "17 Jun 2026, 10:35:41",
    itemsPrinted: {
      "Carton Label": true,
      "End Of Pack Label": true,
      "Security Seals": true
    }
  };
  leafletPrintRecords[batchNumber] = leafletPrintRecords[batchNumber] || {
    printed: true,
    printedBy: "printer.user",
    dateTime: "17 Jun 2026, 12:18:04",
    itemsPrinted: {
      Leaflet: true
    }
  };

  document.body.classList.remove("pre-login");
  loginModal.classList.add("hidden");
  renderStage("leaflet-folding");
  statusMessage.textContent = `${batchNumber} is ready in Leaflet Folding demo mode.`;
}

function loadPreAssemblyDemo() {
  const stage = findStage("pre-assembly-qc");
  const product = bnsProducts.find((item) => item.batch === "03A1582") || bnsProducts[0];
  const batchNumber = product.batch;

  currentLogin = {
    user: stage.user,
    role: stage.role,
    stageId: stage.id
  };
  isAuthenticated = true;
  document.body.classList.remove("pre-login");
  loginModal.classList.add("hidden");
  if (!generatedBatchNumbers.includes(batchNumber)) generatedBatchNumbers.push(batchNumber);
  if (!labelPrintedBatchNumbers.includes(batchNumber)) labelPrintedBatchNumbers.push(batchNumber);
  if (!leafletPrintedBatchNumbers.includes(batchNumber)) leafletPrintedBatchNumbers.push(batchNumber);
  if (!leafletFoldedBatchNumbers.includes(batchNumber)) leafletFoldedBatchNumbers.push(batchNumber);
  preAssemblySelectedProduct = null;
  renderStage("pre-assembly-qc");
  statusMessage.textContent = `${batchNumber} is ready in Pre Assembly demo mode.`;
}

function preloadToProduction(batchNumber = "03A1582") {
  const product = bnsProducts.find((item) => item.batch === batchNumber) || bnsProducts[0];
  const resolvedBatch = product.batch;
  if (!generatedBatchNumbers.includes(resolvedBatch)) generatedBatchNumbers.push(resolvedBatch);
  if (!labelPrintedBatchNumbers.includes(resolvedBatch)) labelPrintedBatchNumbers.push(resolvedBatch);
  if (!leafletPrintedBatchNumbers.includes(resolvedBatch)) leafletPrintedBatchNumbers.push(resolvedBatch);
  if (!leafletFoldedBatchNumbers.includes(resolvedBatch)) leafletFoldedBatchNumbers.push(resolvedBatch);
  if (!preAssemblyCheckedBatchNumbers.includes(resolvedBatch)) preAssemblyCheckedBatchNumbers.push(resolvedBatch);
  return product;
}

function loadProductionDemo() {
  const stage = findStage("room-allocation");
  const product = preloadToProduction();
  currentLogin = {
    user: stage.user,
    role: stage.role,
    stageId: stage.id
  };
  isAuthenticated = true;
  document.body.classList.remove("pre-login");
  loginModal.classList.add("hidden");
  productionSelectedProduct = null;
  renderStage("room-allocation");
  statusMessage.textContent = `${product.batch} is ready in Production Controller demo mode.`;
}

function loadAssemblyDemo() {
  const stage = findStage("assembly-room");
  const product = preloadToProduction();
  if (!productionAllocatedBatchNumbers.includes(product.batch)) productionAllocatedBatchNumbers.push(product.batch);
  productionRecords[product.batch] = productionRecords[product.batch] || {
    user: "production.control",
    dateTime: "22 Jun 2026, 11:10:00",
    boxCount: "2",
    roomNo: "Room 2"
  };
  currentLogin = {
    user: stage.user,
    role: stage.role,
    stageId: stage.id
  };
  isAuthenticated = true;
  document.body.classList.remove("pre-login");
  loginModal.classList.add("hidden");
  assemblySelectedProduct = null;
  renderStage("assembly-room");
  statusMessage.textContent = `${product.batch} is ready in Assembly Room demo mode.`;
}

function loadPostAssemblyDemo() {
  const stage = findStage("post-assembly-qc");
  const product = preloadToProduction();
  if (!productionAllocatedBatchNumbers.includes(product.batch)) productionAllocatedBatchNumbers.push(product.batch);
  if (!assembledBatchNumbers.includes(product.batch)) assembledBatchNumbers.push(product.batch);
  assemblyRecords[product.batch] = assemblyRecords[product.batch] || {
    user: "assembly.room",
    dateTime: "22 Jun 2026, 15:15:00",
    boxCount: "5",
    usedLabels: product.quantity,
    signedTabs: {
      materials: { user: "assembly.room", dateTime: "22 Jun 2026, 14:55:00" },
      samples: { user: "assembly.room", dateTime: "22 Jun 2026, 15:00:00" },
      ipc: { user: "assembly.room", dateTime: "22 Jun 2026, 15:08:00" },
      recon: { user: "assembly.room", dateTime: "22 Jun 2026, 15:15:00" }
    }
  };
  currentLogin = {
    user: stage.user,
    role: stage.role,
    stageId: stage.id
  };
  isAuthenticated = true;
  document.body.classList.remove("pre-login");
  loginModal.classList.add("hidden");
  postAssemblySelectedProduct = null;
  renderStage("post-assembly-qc");
  statusMessage.textContent = `${product.batch} is ready in Production Checking demo mode.`;
}

function loadPreQpDemo() {
  const stage = findStage("pre-qp");
  const product = preloadToProduction();
  if (!productionAllocatedBatchNumbers.includes(product.batch)) productionAllocatedBatchNumbers.push(product.batch);
  if (!assembledBatchNumbers.includes(product.batch)) assembledBatchNumbers.push(product.batch);
  if (!postAssemblyCheckedBatchNumbers.includes(product.batch)) postAssemblyCheckedBatchNumbers.push(product.batch);
  postAssemblyRecords[product.batch] = postAssemblyRecords[product.batch] || {
    user: "postassembly.qc",
    dateTime: "22 Jun 2026, 16:10:00",
    boxCount: "7",
    totalQty: product.quantity,
    packsChecked: "27",
    quarantinePrinted: true
  };
  currentLogin = {
    user: stage.user,
    role: stage.role,
    stageId: stage.id
  };
  isAuthenticated = true;
  document.body.classList.remove("pre-login");
  loginModal.classList.add("hidden");
  preQpSelectedProduct = null;
  renderStage("pre-qp");
  statusMessage.textContent = `${product.batch} is ready in Pre QP demo mode.`;
}

function loadQpReleaseDemo() {
  const stage = findStage("qp-release");
  const product = preloadToProduction();
  if (!productionAllocatedBatchNumbers.includes(product.batch)) productionAllocatedBatchNumbers.push(product.batch);
  if (!assembledBatchNumbers.includes(product.batch)) assembledBatchNumbers.push(product.batch);
  if (!postAssemblyCheckedBatchNumbers.includes(product.batch)) postAssemblyCheckedBatchNumbers.push(product.batch);
  if (!preQpCheckedBatchNumbers.includes(product.batch)) preQpCheckedBatchNumbers.push(product.batch);
  postAssemblyRecords[product.batch] = postAssemblyRecords[product.batch] || {
    user: "postassembly.qc",
    dateTime: "22 Jun 2026, 16:10:00",
    boxCount: "7",
    totalQty: product.quantity,
    packsChecked: "27",
    quarantinePrinted: true
  };
  preQpRecords[product.batch] = preQpRecords[product.batch] || {
    user: "pre.qp",
    dateTime: "22 Jun 2026, 16:45:00",
    sampleBox: "01",
    docs: ["Yes", "Yes", "No", "Yes", "No", "No"],
    materialChecked: true,
    comments: "Pre-QP review complete. Digital release log generated.",
    logGenerated: true
  };
  currentLogin = {
    user: stage.user,
    role: stage.role,
    stageId: stage.id
  };
  isAuthenticated = true;
  document.body.classList.remove("pre-login");
  loginModal.classList.add("hidden");
  qpSelectedProduct = null;
  renderStage("qp-release");
  statusMessage.textContent = `${product.batch} is ready in QP Release demo mode.`;
}

function startWireframe() {
  renderStageStrip();
  const demoMode = new URLSearchParams(window.location.search).get("demo") || new URLSearchParams(window.location.hash.replace(/^#/, "?")).get("demo");

  if (demoMode === "packing-list") {
    const stage = findStage("packing-list");
    currentLogin = { user: stage.user, role: stage.role, stageId: stage.id };
    isAuthenticated = true;
    document.body.classList.remove("pre-login");
    loginModal.classList.add("hidden");
    renderStage("packing-list");
    statusMessage.textContent = "Packing List demo mode opened.";
    return;
  }
  if (demoMode === "leaflet-folding") {
    loadLeafletFoldingDemo();
    return;
  }

  if (demoMode === "pre-assembly") {
    loadPreAssemblyDemo();
    return;
  }

  if (demoMode === "production") {
    loadProductionDemo();
    return;
  }

  if (demoMode === "assembly") {
    loadAssemblyDemo();
    return;
  }

  if (demoMode === "post-assembly") {
    loadPostAssemblyDemo();
    return;
  }

  if (demoMode === "pre-qp") {
    loadPreQpDemo();
    return;
  }

  if (demoMode === "qp-release") {
    loadQpReleaseDemo();
    return;
  }

  openDashboard();
}

function renderHandoff(stage) {
  return `
    <aside class="handoff-box">
      <div class="panel-title">Handoff</div>
      <dl>
<dt>Entry source</dt>
<dd>${stage.entry}</dd>
<dt>Next module</dt>
<dd>${stage.next}</dd>
<dt>Required approval</dt>
<dd>${stage.approval}</dd>
      </dl>
      <button class="classic-button primary full" type="button">Submit Handoff</button>
      <button class="classic-button full" type="button">Save Draft</button>
    </aside>
  `;
}

function renderGenericStageWork(stage) {
  return `
    <div class="work-grid">
      <section>
<div class="panel-title">Digital Checklist</div>
<div class="checklist">
  ${stage.checks
    .map(
      (check, index) => `
<div class="check-row">
  <span class="check-box">${index < 2 ? "OK" : ""}</span>
  <div>
    <strong>${check}</strong>
    <p>${index < 2 ? "Completed in current draft." : "Ready for operator completion."}</p>
  </div>
  <span class="status ${index < 2 ? "done-status" : "active-status"}">${index < 2 ? "Done" : "Open"}</span>
</div>
      `
    )
    .join("")}
</div>
      </section>
      ${renderHandoff(stage)}
    </div>
  `;
}

function getMfgLotNo(item) {
  if (!item) return "";
  return item.mfgLotNo || item.manufLotNo || item.manufacturingLot || item.mfgLot || item.manufacturerBatchNo || item.batchNo || "";
}

function matchesBatchOrMfgLot(item, searchValue) {
  const search = String(searchValue || "").trim().toLowerCase();
  if (!search) return true;
  return [item.batch, item.batchNo, item.product, item.description, getMfgLotNo(item)]
    .some((value) => String(value || "").toLowerCase().includes(search));
}

function exactBatchOrMfgLotMatch(item, searchValue) {
  const search = String(searchValue || "").trim().toLowerCase();
  if (!search) return false;
  return [item.batch, item.batchNo, getMfgLotNo(item)]
    .some((value) => String(value || "").trim().toLowerCase() === search);
}

function getFilteredBnsProducts() {
  return bnsProducts
    .filter((product) =>
      bnsFilters.status === "Printed BAR"
        ? generatedBatchNumbers.includes(product.batch)
        : !generatedBatchNumbers.includes(product.batch)
    )
    .filter((product) => bnsFilters.country === "All" || product.country === bnsFilters.country)
    .filter((product) => bnsFilters.site === "All" || product.site === bnsFilters.site)
    .filter((product) => bnsFilters.category === "All" || product.category === bnsFilters.category)
    .filter((product) => !bnsFilters.quantity || String(product.quantity).includes(bnsFilters.quantity.trim()))
    .filter((product) => !bnsFilters.objId || [product.objId, product.piObjId].some((value) => String(value || "").toLowerCase().includes(bnsFilters.objId.trim().toLowerCase())))
    .filter((product) => !bnsFilters.mfgLot || String(getMfgLotNo(product) || "").toLowerCase().includes(bnsFilters.mfgLot.trim().toLowerCase()))
    .filter((product) => matchesBatchOrMfgLot(product, bnsFilters.batch));
}

function getDefaultPackingListRows() {
  return [
    { orderNo: "C13719", lineNo: "1", partNo: "ESADA05TABS84", description: "Adartrel 0.5mg Tabs 84", batchNo: "", expiryDate: "", qty: "50", boxes: "0", suppName: "EUROSERV, S.A.", suppCode: "EURO10_G", comments: "", createdBy: "Satish Kalbande", createdDate: "22-06-2026", foreignName: "ADARTREL comprimes pellicules", strength: "0.5mg", packSize: "28", country: "SPAIN", ecma: "67921 (654...)", contract: "WHO", barcode: "0", validBarcode: "0" },
    { orderNo: "C13719", lineNo: "10", partNo: "ESLUMEYE30", description: "Lumigan 0.01% Eye drops 3ml", batchNo: "426752", expiryDate: "30-09-2027", qty: "300", boxes: "1", suppName: "EUROSERV, S.A.", suppCode: "EURO10_G", comments: "", createdBy: "Satish Kalbande", createdDate: "22-06-2026", foreignName: "Lumigan", strength: "0.1mg/ml", packSize: "1 x 3ml", country: "SPAIN", ecma: "EU/1/02/205...", contract: "WHO", barcode: "0", validBarcode: "0" },
    { orderNo: "C13719", lineNo: "11", partNo: "ESMAS500TAB", description: "Mastical 500mg Tabs 90", batchNo: "12522242", expiryDate: "31-03-2028", qty: "280", boxes: "7", suppName: "EUROSERV, S.A.", suppCode: "EURO10_G", comments: "", createdBy: "Satish Kalbande", createdDate: "22-06-2026", foreignName: "MASTICAL comp.", strength: "500mg", packSize: "90", country: "SPAIN", ecma: "58828 (655...)", contract: "WHO", barcode: "0", validBarcode: "0" },
    { orderNo: "C13719", lineNo: "12", partNo: "ESOMA1000", description: "Omacor 1000mg Capsules 28", batchNo: "Z002", expiryDate: "30-09-2028", qty: "500", boxes: "6", suppName: "EUROSERV, S.A.", suppCode: "EURO10_G", comments: "", createdBy: "Satish Kalbande", createdDate: "22-06-2026", foreignName: "Omacor cap.", strength: "1000mg", packSize: "28", country: "SPAIN", ecma: "65476 (873...)", contract: "WHO", barcode: "0", validBarcode: "0" },
    { orderNo: "C13719", lineNo: "2", partNo: "ESBACNA15G", description: "Bactroban Ointment 15G", batchNo: "TL2B", expiryDate: "31-10-2027", qty: "200", boxes: "1", suppName: "EUROSERV, S.A.", suppCode: "EURO10_G", comments: "", createdBy: "Satish Kalbande", createdDate: "22-06-2026", foreignName: "Bactroban pomada", strength: "2% w/w", packSize: "15g", country: "SPAIN", ecma: "58868 (997...)", contract: "WHO", barcode: "0", validBarcode: "0" }
  ];
}

function canGeneratePackingList(poNo) {
  const rows = getPackingListRows().filter(r => r.orderNo === poNo);
  if (rows.length === 0) return false;
  // Ignore empty draft lines with no batches or expiries
  const activeRows = rows.filter(row => row.batchNo && row.expiryDate && row.qty && row.qty !== "0");
  if (activeRows.length === 0) return false;
  return activeRows.every(row => {
    const key = getPackingLineKey(row);
    return packingLabelPrintRecords[key] !== undefined;
  });
}

function getRpTaskViewedDocs(po) {
  if (!po.rpTaskViewedDocs) {
    po.rpTaskViewedDocs = {};
  }
  return po.rpTaskViewedDocs;
}

function areAllRpDocumentsVerified(poNo) {
  const po = rpPackWorkflows[poNo];
  if (!po) return false;
  const viewedDocs = getRpTaskViewedDocs(po);
  const sourceDocIds = getPackingRequiredDocuments().map((doc) => doc.id);
  const docsViewedByRp = sourceDocIds.every((docId) => viewedDocs[docId] === true);
  const isPackingListViewedByRp = viewedDocs["generated-packing-list"] === true;
  return docsViewedByRp && isPackingListViewedByRp;
}

let activePreviewDoc = null;
let activePreviewPo = null;

function openDocumentPreview(poNo, docId) {
  activePreviewPo = poNo;
  activePreviewDoc = docId;
  
  const workflow = rpPackWorkflows[poNo];
  if (!workflow) return;
  const doc = workflow.documents.find(d => d.id === docId);
  if (!doc) return;
  const isRpTaskPreview = currentStageId === "rp-pack";
  const isRpPackPreview = currentStageId === "packing-list" && packingListMode === "documents";
  const rpTaskViewedDocs = isRpTaskPreview ? getRpTaskViewedDocs(workflow) : null;
  if (isRpTaskPreview) {
    rpTaskViewedDocs[docId] = true;
  }
  if (isRpPackPreview) {
    workflow.viewedDocs = workflow.viewedDocs || {};
    workflow.viewedDocs[docId] = true;
    doc.verified = true;
  }
  const documentAlreadyVerified = isRpTaskPreview || isRpPackPreview ? true : doc.verified === true;
  
  let previewContent = "";
  if (docId === "supplier-invoice") {
    previewContent = `
      <div style="border: 2px solid #334155; padding: 20px; font-family: Courier, monospace; background: #fffdf6; border-radius: 4px;">
        <h2 style="text-align: center; margin-top: 0; color: #1e293b;">SUPPLIER INVOICE</h2>
        <div style="display: flex; justify-content: space-between; border-bottom: 2px solid #334155; padding-bottom: 10px; margin-bottom: 15px; font-size: 11px;">
          <div>
            <strong>Invoice To:</strong> B&S Healthcare<br>
            <strong>Invoice No:</strong> INV-9874102<br>
            <strong>Date:</strong> 24-06-2026
          </div>
          <div style="text-align: right;">
            <strong>Supplier:</strong> Euroserv S.A.<br>
            <strong>Country:</strong> SPAIN<br>
            <strong>P.O. Ref:</strong> ${poNo}
          </div>
        </div>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 11px;">
          <thead>
            <tr style="border-bottom: 1px solid #334155;">
              <th style="text-align: left; padding: 5px;">Item</th>
              <th style="text-align: center; padding: 5px;">Qty</th>
              <th style="text-align: right; padding: 5px;">Unit Price</th>
              <th style="text-align: right; padding: 5px;">Total</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="padding: 5px;">Alphagan eye drops 0.2% 5ml</td>
              <td style="text-align: center; padding: 5px;">220</td>
              <td style="text-align: right; padding: 5px;">GBP 4.50</td>
              <td style="text-align: right; padding: 5px;">GBP 990.00</td>
            </tr>
            <tr>
              <td style="padding: 5px;">Brilique film-coated tablets 90mg</td>
              <td style="text-align: center; padding: 5px;">360</td>
              <td style="text-align: right; padding: 5px;">GBP 12.00</td>
              <td style="text-align: right; padding: 5px;">GBP 4,320.00</td>
            </tr>
          </tbody>
        </table>
        <div style="text-align: right; font-weight: bold; border-top: 2px solid #334155; padding-top: 8px; font-size: 12px;">
          GRAND TOTAL: GBP 5,310.00
        </div>
      </div>
    `;
  } else if (docId === "po") {
    previewContent = `
      <div style="border: 2px solid #1e3a8a; padding: 20px; font-family: sans-serif; background: #ffffff; border-radius: 4px;">
        <h2 style="color: #1e3a8a; margin-top: 0; text-align: center; border-bottom: 3px solid #1e3a8a; padding-bottom: 5px;">PURCHASE ORDER</h2>
        <div style="display: flex; justify-content: space-between; margin-bottom: 15px; font-size: 11px;">
          <div>
            <strong>B&S Healthcare</strong><br>
            100 Sovereign Road, London<br>
            <strong>PO Number:</strong> ${poNo}<br>
            <strong>Date:</strong> 23-06-2026
          </div>
          <div style="text-align: right;">
            <strong>Supplier Ref:</strong> EURO10_G<br>
            <strong>Ship Via:</strong> Authorized Transporter
          </div>
        </div>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 11px;">
          <thead style="background: #f1f5f9;">
            <tr>
              <th style="border: 1px solid #cbd5e1; padding: 8px;">Part No</th>
              <th style="border: 1px solid #cbd5e1; padding: 8px;">Description</th>
              <th style="border: 1px solid #cbd5e1; padding: 8px; text-align: center;">Qty Ordered</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="border: 1px solid #cbd5e1; padding: 8px;">ESALP02EYE5</td>
              <td style="border: 1px solid #cbd5e1; padding: 8px;">Alphagan eye drops 0.2% 5ml</td>
              <td style="border: 1px solid #cbd5e1; padding: 8px; text-align: center;">220</td>
            </tr>
            <tr>
              <td style="border: 1px solid #cbd5e1; padding: 8px;">PTBRI90TAB56</td>
              <td style="border: 1px solid #cbd5e1; padding: 8px;">Brilique film-coated tablets 90mg</td>
              <td style="border: 1px solid #cbd5e1; padding: 8px; text-align: center;">360</td>
            </tr>
          </tbody>
        </table>
      </div>
    `;
  } else if (docId === "supplier-packing-list") {
    previewContent = `
      <div style="border: 2px solid #059669; padding: 20px; font-family: sans-serif; background: #ffffff; border-radius: 4px;">
        <h2 style="color: #059669; margin-top: 0; text-align: center; border-bottom: 2px solid #059669; padding-bottom: 5px;">SUPPLIER PACKING LIST</h2>
        <div style="display: flex; justify-content: space-between; margin-bottom: 15px; font-size: 11px;">
          <div>
            <strong>Sender:</strong> Euroserv S.A.<br>
            <strong>PO Ref:</strong> ${poNo}
          </div>
          <div style="text-align: right;">
            <strong>Packages:</strong> 5 boxes<br>
            <strong>Gross Wt:</strong> 12.5 kg
          </div>
        </div>
        <table style="width: 100%; border-collapse: collapse; font-size: 11px;">
          <thead style="background: #ecfdf5;">
            <tr>
              <th style="border: 1px solid #d1fae5; padding: 6px;">Box No</th>
              <th style="border: 1px solid #d1fae5; padding: 6px;">Description</th>
              <th style="border: 1px solid #d1fae5; padding: 6px; text-align: center;">Qty</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="border: 1px solid #d1fae5; padding: 6px; text-align: center;">Box 1-2</td>
              <td style="border: 1px solid #d1fae5; padding: 6px;">Alphagan eye drops 0.2% 5ml</td>
              <td style="border: 1px solid #d1fae5; padding: 6px; text-align: center;">220</td>
            </tr>
            <tr>
              <td style="border: 1px solid #d1fae5; padding: 6px; text-align: center;">Box 3-5</td>
              <td style="border: 1px solid #d1fae5; padding: 6px;">Brilique film-coated tablets 90mg</td>
              <td style="border: 1px solid #d1fae5; padding: 6px; text-align: center;">360</td>
            </tr>
          </tbody>
        </table>
      </div>
    `;
  } else if (docId === "supplier-declaration") {
    previewContent = `
      <div style="border: 2px solid #7c3aed; padding: 20px; font-family: serif; background: #faf5ff; border-radius: 4px;">
        <h2 style="color: #7c3aed; text-align: center; margin-top: 0; font-size: 18px;">SUPPLIER COMPLIANCE DECLARATION</h2>
        <p style="text-align: justify; line-height: 1.5; font-size: 12px;">
          We hereby declare and certify that all the goods supplied under PO reference <strong>${poNo}</strong> comply fully with Article 51 of Directive 2001/83/EC and Falsified Medicines Directive 2011/62/EU. We confirm that the stock has been sourced from approved suppliers in accordance with regulatory guidelines.
        </p>
        <div style="margin-top: 20px; display: flex; justify-content: space-between; font-size: 11px;">
          <div>
            <strong>Authorized Signatory:</strong><br>
            Dr. Alejandro Ruiz<br>
            Quality Director, Euroserv S.A.
          </div>
          <div style="text-align: right;">
            <strong>Date:</strong> 24-06-2026
          </div>
        </div>
      </div>
    `;
  } else if (docId === "temperature-record") {
    previewContent = `
      <div style="border: 2px solid #db2777; padding: 20px; font-family: sans-serif; background: #ffffff; border-radius: 4px;">
        <h2 style="color: #db2777; text-align: center; margin-top: 0; border-bottom: 2px solid #db2777; padding-bottom: 5px;">TRANSIT TEMPERATURE LOG</h2>
        <div style="margin-bottom: 15px; font-size: 11px;">
          <strong>PO No:</strong> ${poNo} | <strong>Logger ID:</strong> TL-4091<br>
          <strong>Range:</strong> +2.0C to +8.0C (Cold Chain System)
        </div>
        <div style="background: #fdf2f8; border: 1px solid #fbcfe8; padding: 15px; border-radius: 4px; text-align: center;">
          <p style="font-weight: bold; color: #be185d; margin: 0 0 10px; font-size: 11px;">Temperature Profile Chart</p>
          <div style="height: 100px; display: flex; align-items: flex-end; justify-content: space-between; border-left: 2px solid #ccc; border-bottom: 2px solid #ccc; padding: 10px 5px 0;">
            <div style="height: 60%; width: 10%; background: #be185d; border-radius: 2px 2px 0 0;"></div>
            <div style="height: 55%; width: 10%; background: #be185d; border-radius: 2px 2px 0 0;"></div>
            <div style="height: 65%; width: 10%; background: #be185d; border-radius: 2px 2px 0 0;"></div>
            <div style="height: 58%; width: 10%; background: #be185d; border-radius: 2px 2px 0 0;"></div>
            <div style="height: 62%; width: 10%; background: #be185d; border-radius: 2px 2px 0 0;"></div>
            <div style="height: 57%; width: 10%; background: #be185d; border-radius: 2px 2px 0 0;"></div>
            <div style="height: 63%; width: 10%; background: #be185d; border-radius: 2px 2px 0 0;"></div>
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 8px; color: #666; margin-top: 4px; padding-left: 10px;">
            <span>Day 1</span><span>Day 2</span><span>Day 3</span><span>Day 4</span><span>Day 5</span><span>Day 6</span><span>Day 7</span>
          </div>
        </div>
        <p style="font-size: 11px; color: green; font-weight: bold; text-align: center; margin-top: 10px; margin-bottom: 0;">OK - Temperature parameters kept within 2.0C - 8.0C.</p>
      </div>
    `;
  } else {
    previewContent = `
      <div style="border: 2px solid #475569; padding: 25px; font-family: sans-serif; background: #ffffff; border-radius: 4px;">
        <h2 style="color: #475569; text-align: center; margin-top: 0; text-transform: uppercase; font-size: 16px;">${doc.name}</h2>
        <p style="margin-bottom: 15px; font-size: 11px;"><strong>PO Reference No:</strong> ${poNo}</p>
        <div style="border: 1px dashed #94a3b8; padding: 40px; text-align: center; color: #64748b; background: #f8fafc; border-radius: 4px; font-size: 12px;">
          Mock digital representation of ${doc.name} for PO ${poNo}. All data matched and verified.
        </div>
      </div>
    `;
  }

  let previewOverlay = document.querySelector("#doc-preview-modal");
  if (!previewOverlay) {
    previewOverlay = document.createElement("div");
    previewOverlay.id = "doc-preview-modal";
    previewOverlay.style = "position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(0,0,0,0.5); z-index: 10000; display: flex; align-items: center; justify-content: center;";
    document.body.appendChild(previewOverlay);
  }
  
  previewOverlay.innerHTML = `
    <div style="background: white; border-radius: 8px; width: 600px; max-width: 90vw; padding: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); display: flex; flex-direction: column; gap: 15px; font-family: Tahoma, sans-serif;">
      <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #cbd5e1; padding-bottom: 8px;">
        <h3 style="margin: 0; color: #1f3a5f; font-size: 14px;">Document Preview - ${doc.name}</h3>
        <button id="doc-preview-close" style="background: none; border: none; font-size: 20px; cursor: pointer; font-weight: bold; color: #64748b;">&times;</button>
      </div>
      
      <div style="max-height: 400px; overflow-y: auto; padding: 5px;">
        ${previewContent}
      </div>
      
      <div style="display: flex; justify-content: flex-end; gap: 10px; border-top: 1px solid #cbd5e1; padding-top: 12px;">
        ${documentAlreadyVerified ? `<span style="color: #065f46; font-weight: bold; align-self: center; font-size: 12px; margin-right: auto;">Viewed</span>` : `<span style="color: #065f46; font-weight: bold; align-self: center; font-size: 12px; margin-right: auto;">Viewed</span>`}
        <button id="doc-preview-download" style="background: #2563eb; color: white; border: none; padding: 8px 16px; border-radius: 4px; font-weight: bold; cursor: pointer; font-size: 11px;">Download</button>
        <button id="doc-preview-cancel" style="background: #64748b; color: white; border: none; padding: 8px 16px; border-radius: 4px; font-weight: bold; cursor: pointer; font-size: 11px;">Close</button>
      </div>
    </div>
  `;
  
  document.querySelector("#doc-preview-close").addEventListener("click", closeDocumentPreview);
  document.querySelector("#doc-preview-cancel").addEventListener("click", closeDocumentPreview);
  document.querySelector("#doc-preview-download").addEventListener("click", () => { statusMessage.textContent = `Download started for ${doc.name}.`; });
  
}

function closeDocumentPreview() {
  const previewOverlay = document.querySelector("#doc-preview-modal");
  const stageToRender = currentStageId;
  if (previewOverlay) {
    previewOverlay.remove();
  }
  activePreviewDoc = null;
  activePreviewPo = null;
  if (stageToRender === "rp-pack") {
    renderStage("rp-pack");
    setTimeout(updateRpApprovalAvailability, 0);
  } else if (stageToRender === "packing-list" && packingListMode === "documents") {
    renderStage("packing-list");
    setTimeout(updateRpDocumentsAvailability, 0);
  }
}

function renderRpApprovalExactPdfModal(poNo, answers, signatureObj) {
  const po = rpPackWorkflows[poNo] || {};
  const firstRow = getPackingListRows().find(r => r.orderNo === poNo) || {};
  
  const supplierName = firstRow.suppName || "Euroserv S.A.";
  const supplierCountry = firstRow.country || "SPAIN";
  const invoiceNo = "INV-9874102";
  
  const getYN = (val) => {
    if (val === "Y" || val === true) return `<strong>YES</strong> <span style="color:#aaa;">/ NO</span>`;
    if (val === "N" || val === false) return `<span style="color:#aaa;">YES /</span> <strong>NO</strong>`;
    return `<span style="color:#aaa;">YES / NO</span>`;
  };
  
  const getYNNA = (val) => {
    if (val === "Y") return `<strong>YES</strong> <span style="color:#aaa;">/ NO / NA</span>`;
    if (val === "N") return `<span style="color:#aaa;">YES /</span> <strong>NO</strong> <span style="color:#aaa;">/ NA</span>`;
    if (val === "NA") return `<span style="color:#aaa;">YES / NO /</span> <strong>NA</strong>`;
    return `<span style="color:#aaa;">YES / NO / NA</span>`;
  };

  const getFEStatus = (val) => {
    if (val === "Y" || val === "Active") return `<strong>Active</strong> <span style="color:#aaa;">/ Inactive</span>`;
    if (val === "N" || val === "Inactive") return `<span style="color:#aaa;">Active /</span> <strong>Inactive</strong>`;
    return `<span style="color:#aaa;">Active / Inactive</span>`;
  };

  const sigHtml = signatureObj ? `
    <div style="border: 1px dashed green; background: #f0fdf4; padding: 6px; border-radius: 4px; display: inline-block;">
      <span style="color: #15803d; font-weight: bold; font-size: 11px;">Digitally Signed by ${signatureObj.user}</span><br>
      <span style="color: #15803d; font-size: 9px;">on ${signatureObj.dateTime}</span>
    </div>
  ` : `
    <button id="rp-pdf-sign-btn" class="classic-button primary" style="padding: 6px 12px; font-weight: bold; background: #1e3a8a; border-radius: 4px; cursor: pointer; font-size: 11px;">Click to Sign</button>
  `;

  return `
    <div id="rp-pdf-modal-overlay" style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(0,0,0,0.6); z-index: 20000; display: flex; align-items: center; justify-content: center; overflow-y: auto; padding: 20px;">
      <div style="background: white; border-radius: 8px; width: 800px; max-width: 95vw; padding: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.25); display: flex; flex-direction: column; gap: 15px; position: relative; font-family: Tahoma, sans-serif;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #cbd5e1; padding-bottom: 8px;">
          <h3 style="margin: 0; color: #1e3a8a; font-size: 14px;">RPi Checks Form F/PLPI/0088/001/v4 - Preview</h3>
          <button id="rp-pdf-close" style="background: none; border: none; font-size: 24px; cursor: pointer; font-weight: bold; color: #64748b;">&times;</button>
        </div>
        
        <div style="max-height: 70vh; overflow-y: auto; background: #f1f5f9; padding: 20px; border-radius: 6px;">
          <!-- A4 Sheet Container -->
          <div style="background: white; border: 1px solid #94a3b8; width: 700px; margin: 0 auto; padding: 35px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); font-family: Calibri, sans-serif; font-size: 11pt; color: #000000; line-height: 1.3; text-align: left;">
            
            <!-- Logo & Title -->
            <div style="margin-bottom: 20px;">
              <div style="font-weight: bold; font-size: 14pt; color: #1e3a8a; font-style: italic;">B&S Healthcare</div>
              <div style="font-weight: bold; font-size: 12pt; color: #1e3a8a; border-bottom: 2px solid #000000; padding-bottom: 4px;">
                RPi Checks on Raw Imported Stock prior to Re-Labelling<br>
                (Under Regulation 45AA)
              </div>
            </div>
            
            <!-- Header Table -->
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 10pt;">
              <tr>
                <td style="border: 1px solid #000000; padding: 6px; width: 45%; font-weight: bold;">Supplier Name / Country</td>
                <td style="border: 1px solid #000000; padding: 6px;">${supplierName} / ${supplierCountry}</td>
              </tr>
              <tr>
                <td style="border: 1px solid #000000; padding: 6px; font-weight: bold;">BNS's Purchase Order Number</td>
                <td style="border: 1px solid #000000; padding: 6px;">${poNo}</td>
              </tr>
              <tr>
                <td style="border: 1px solid #000000; padding: 6px; font-weight: bold;">Supplier's Invoice Number</td>
                <td style="border: 1px solid #000000; padding: 6px;">${invoiceNo}</td>
              </tr>
            </table>

            <!-- Section: Custom Details Check -->
            <div style="background: #1e3a8a; color: white; font-weight: bold; text-align: center; padding: 4px 0; font-size: 11pt; margin-top: 15px;">
              Custom Details Check
            </div>
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 10pt;">
              <tr>
                <td style="border: 1px solid #000000; padding: 6px; width: 80%;">EORI Verification</td>
                <td style="border: 1px solid #000000; padding: 6px; text-align: center; font-weight: bold; width: 20%;">${getYN(answers.eori)}</td>
              </tr>
              <tr>
                <td style="border: 1px solid #000000; padding: 6px;">Commodity Code Verification</td>
                <td style="border: 1px solid #000000; padding: 6px; text-align: center; font-weight: bold;">${getYN(answers.commodity)}</td>
              </tr>
            </table>

            <!-- Section: Supplier Compliance Check -->
            <div style="background: #1e3a8a; color: white; font-weight: bold; text-align: center; padding: 4px 0; font-size: 11pt; margin-top: 15px;">
              Supplier Compliance Check
            </div>
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 10pt;">
              <tr>
                <td style="border: 1px solid #000000; padding: 6px; width: 45%; font-weight: bold;" rowspan="2">Supplier Status in FE</td>
                <td style="border: 1px solid #000000; padding: 6px; text-align: center; font-weight: bold; width: 55%;">${getFEStatus(answers["fe-status"] === "Y" ? "Active" : "Inactive")}</td>
              </tr>
              <tr>
                <td style="border: 1px solid #000000; padding: 6px; font-size: 9pt;">
                  <strong>Give Reason if Inactive:</strong><br>
                  <span style="color: #334155; font-style: italic;">${answers["inactive-reason"] || "N/A"}</span>
                </td>
              </tr>
              <tr>
                <td style="border: 1px solid #000000; padding: 6px; font-weight: bold;">Is the collection address matches with the WDA?</td>
                <td style="border: 1px solid #000000; padding: 6px; text-align: center; font-weight: bold;">${getYN(answers["wda-match"])}</td>
              </tr>
            </table>

            <!-- Section: Temperature Compliance During Transit -->
            <div style="background: #1e3a8a; color: white; font-weight: bold; text-align: center; padding: 4px 0; font-size: 11pt; margin-top: 15px;">
              Temperature Compliance During Transit
            </div>
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 10pt;">
              <tr>
                <td style="border: 1px solid #000000; padding: 6px; width: 80%;">Stock Transported by Authorised Transporter?</td>
                <td style="border: 1px solid #000000; padding: 6px; text-align: center; font-weight: bold; width: 20%;">${getYN(answers.transporter)}</td>
              </tr>
              <tr>
                <td style="border: 1px solid #000000; padding: 6px;">Temperature records in transit checked and within parameters</td>
                <td style="border: 1px solid #000000; padding: 6px; text-align: center; font-weight: bold;">${getYN(answers["temp-transit"])}</td>
              </tr>
              <tr>
                <td style="border: 1px solid #000000; padding: 6px;">Temperature Records at Storage Site (if any) checked and within parameters</td>
                <td style="border: 1px solid #000000; padding: 6px; text-align: center; font-weight: bold;">${getYNNA(answers["temp-storage"])}</td>
              </tr>
            </table>

            <!-- Section: Compliance check in line with Article 51 of Directive 2001/83/EC -->
            <div style="background: #1e3a8a; color: white; font-weight: bold; text-align: center; padding: 4px 0; font-size: 10.5pt; margin-top: 15px;">
              Compliance check in line with Article 51 of Directive 2001/83/EC
            </div>
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 10pt;">
              <tr>
                <td style="border: 1px solid #000000; padding: 6px; width: 80%;">Supplier declaration that all Goods on the delivery note comply with Article 51 of Directive 2001/83/EC and sourced from approved suppliers</td>
                <td style="border: 1px solid #000000; padding: 6px; text-align: center; font-weight: bold; width: 20%;">${getYN(answers["art51-decl"])}</td>
              </tr>
              <tr>
                <td style="border: 1px solid #000000; padding: 6px;">Does the declaration contain compliance with FMD</td>
                <td style="border: 1px solid #000000; padding: 6px; text-align: center; font-weight: bold;">${getYN(answers["fmd-compliance"])}</td>
              </tr>
              <tr>
                <td style="border: 1px solid #000000; padding: 6px;">Does the declaration states that all FMD applicable products has been Decommissioned in accordance with Falsified Medicines Directive 2011/62/EU</td>
                <td style="border: 1px solid #000000; padding: 6px; text-align: center; font-weight: bold;">${getYN(answers["fmd-decom"])}</td>
              </tr>
              <tr>
                <td style="border: 1px solid #000000; padding: 6px;">Italian and Greek packs checked for presence of Bollino/Vignate stickers</td>
                <td style="border: 1px solid #000000; padding: 6px; text-align: center; font-weight: bold;">${getYNNA(answers.bollino)}</td>
              </tr>
            </table>

            <!-- Section: Conclusion -->
            <div style="background: #1e3a8a; color: white; font-weight: bold; text-align: center; padding: 4px 0; font-size: 11pt; margin-top: 15px;">
              Conclusion
            </div>
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 10pt;">
              <tr>
                <td style="border: 1px solid #000000; padding: 6px;" colspan="2">
                  <strong>RPi Comments:</strong><br>
                  <span style="color: #334155; font-style: italic;">${rpApprovalComments[poNo] || "No comments."}</span>
                </td>
              </tr>
              <tr>
                <td style="border: 1px solid #000000; padding: 6px; width: 80%; font-weight: bold;">RPi Checks completed and stock is suitable for processing</td>
                <td style="border: 1px solid #000000; padding: 6px; text-align: center; font-weight: bold; width: 20%;">${getYN(answers["stock-suitable"])}</td>
              </tr>
              <tr>
                <td style="border: 1px solid #000000; padding: 6px; font-weight: bold;">Any Deviation to be raised?</td>
                <td style="border: 1px solid #000000; padding: 6px; text-align: center; font-weight: bold;">${getYN(answers.deviation)}</td>
              </tr>
              <tr style="height: 60px;">
                <td style="border: 1px solid #000000; padding: 6px; font-weight: bold;">Signature (RPi or Delegate Deputy)</td>
                <td style="border: 1px solid #000000; padding: 6px; text-align: center; vertical-align: middle;">
                  ${sigHtml}
                </td>
              </tr>
            </table>

            <!-- Footer Details -->
            <div style="margin-top: 25px; display: flex; justify-content: space-between; font-size: 9pt; color: #555; border-top: 1px solid #ccc; padding-top: 8px;">
              <div>
                Parent SOP SOP/PLPI/0088<br>
                Effective Date: 02Jan2025
              </div>
              <div style="text-align: center;">
                Form Number F/PLPI/0088/001/v4<br>
                Review Date: 31Dec2026
              </div>
              <div style="text-align: right;">
                Page 1 of 1
              </div>
            </div>
            
          </div>
        </div>
        
        <div style="display: flex; justify-content: flex-end; gap: 10px; border-top: 1px solid #cbd5e1; padding-top: 12px;">
          <button id="rp-pdf-cancel" style="background: #64748b; color: white; border: none; padding: 8px 16px; border-radius: 4px; font-weight: bold; cursor: pointer; font-size: 11px;">Close Preview</button>
        </div>
      </div>
    </div>
  `;
}
function getLivePackingListRows() {
  return [
    { orderNo: "C13810", lineNo: "1", partNo: "ESALP02EYE5", description: "Alphagan eye drops 0.2% 5ml", batchNo: "LVT001", mfgLotNo: "MFG-ALP-2401", expiryDate: "31-08-2027", qty: "220", boxes: "2", suppName: "Euroserv S.A.", suppCode: "EURO10_G", comments: "Live test row", createdBy: "goods.in", createdDate: "24-06-2026", foreignName: "Alphagan collyre", strength: "0.2%", packSize: "5ml", country: "SPAIN", ecma: "64120", contract: "WHO", barcode: "1", validBarcode: "1" },
    { orderNo: "C13810", lineNo: "2", partNo: "PTBRI90TAB56", description: "Brilique film-coated tablets 90mg", batchNo: "LVT002", mfgLotNo: "MFG-BRI-2402", expiryDate: "30-09-2028", qty: "360", boxes: "3", suppName: "Pharma Logistics PT", suppCode: "PHARMA_PT", comments: "Live test row", createdBy: "goods.in", createdDate: "24-06-2026", foreignName: "BRILIQUE comprimidos", strength: "90mg", packSize: "56", country: "PORTUGAL", ecma: "EU/1/10/655/002", contract: "WHO", barcode: "1", validBarcode: "1" },
    { orderNo: "C13810", lineNo: "3", partNo: "ESFOS100-6", description: "Foster Nexthaler 100/6mcg", batchNo: "LVT003", mfgLotNo: "MFG-FOS-2403", expiryDate: "31-10-2027", qty: "480", boxes: "4", suppName: "Spanish Pharma Supply", suppCode: "SPAIN_SUP", comments: "PCL already generated", createdBy: "goods.in", createdDate: "24-06-2026", foreignName: "FOSTER NEXTHALER", strength: "100/6 microgram", packSize: "120 doses", country: "SPAIN", ecma: "76713", contract: "WHO", barcode: "1", validBarcode: "1" },
    { orderNo: "C13810", lineNo: "4", partNo: "ESOMA1000", description: "Omacor 1000mg Capsules 28", batchNo: "LVT004", mfgLotNo: "MFG-OMA-2404", expiryDate: "30-09-2028", qty: "520", boxes: "5", suppName: "Euroserv S.A.", suppCode: "EURO10_G", comments: "Live test row", createdBy: "goods.in", createdDate: "24-06-2026", foreignName: "Omacor cap.", strength: "1000mg", packSize: "28", country: "SPAIN", ecma: "65476", contract: "WHO", barcode: "1", validBarcode: "1" },
    { orderNo: "C13811", lineNo: "1", partNo: "CZFLU120ACT", description: "Flutiform pressurised inhalation", batchNo: "LVT005", mfgLotNo: "MFG-FLU-2405", expiryDate: "31-07-2027", qty: "650", boxes: "6", suppName: "DerStar Pharma SK s.r.o.", suppCode: "DERSTAR", comments: "Reboxing batch", createdBy: "goods.in", createdDate: "24-06-2026", foreignName: "Flutiform suspenze", strength: "250/10mcg", packSize: "120 actuations", country: "CZECH REPUBLIC", ecma: "14/555/12-C", contract: "WHO", barcode: "1", validBarcode: "1" },
    { orderNo: "C13811", lineNo: "2", partNo: "FRADA025TAB12", description: "Adartel tablets 0.25mg", batchNo: "LVT006", mfgLotNo: "MFG-ADA-2406", expiryDate: "31-10-2027", qty: "180", boxes: "2", suppName: "Pharma Logistics FR", suppCode: "PHARMA_FR", comments: "Braille required", createdBy: "goods.in", createdDate: "24-06-2026", foreignName: "ADARTEL comprimes pellicules", strength: "0.25mg", packSize: "12", country: "FRANCE", ecma: "3400939183947", contract: "WHO", barcode: "1", validBarcode: "1" }
  ];
}
function getPackingListRows() {
  if (!packingListRowsState) {
    packingListRowsState = getDefaultPackingListRows().concat(getLivePackingListRows()).map((row, index) => ({ ...row, rowId: `pl-${index + 1}` }));
  }
  return packingListRowsState;
}
function getPackingLineKey(row) {
  return row.rowId || `${row.orderNo}-${row.lineNo}-${row.partNo}-${row.batchNo || "pending"}`;
}

function getSelectedPackingLineKeys() {
  const checked = [...document.querySelectorAll("[data-packing-row-select]:checked")].map((input) => input.dataset.packingRowSelect);
  if (checked.length) return checked;
  const firstRow = getFilteredPackingListRows()[0];
  return firstRow ? [getPackingLineKey(firstRow)] : [];
}

function updatePackingRowValue(rowKey, field, value) {
  if (isPackingListLocked()) {
    statusMessage.textContent = "Packing List is generated and locked. Editing is disabled.";
    return;
  }
  const row = getPackingListRows().find((item) => getPackingLineKey(item) === rowKey);
  if (!row) return;
  row[field] = value;
}

function splitPackingLine(rowKey) {
  if (isPackingListLocked()) {
    statusMessage.textContent = "Packing List is generated and locked. Split line is disabled.";
    return;
  }
  const rows = getPackingListRows();
  const index = rows.findIndex((row) => getPackingLineKey(row) === rowKey);
  if (index < 0) return;
  const row = rows[index];
  const originalQty = Number(row.qty || 0);
  const splitQty = Math.floor(originalQty / 2);
  const remainingQty = originalQty - splitQty;
  row.qty = String(remainingQty);
  const newRow = { ...row, rowId: `${row.rowId || rowKey}-split-${Date.now()}`, lineNo: `${row.lineNo}A`, qty: String(splitQty), comments: "Split line" };
  rows.splice(index + 1, 0, newRow);
  statusMessage.textContent = `Line ${row.lineNo} split. Quantities can now be edited.`;
  renderStage("packing-list");
}

function deleteSelectedPackingLines(actionLabel = "deleted") {
  if (isPackingListLocked()) {
    statusMessage.textContent = "Packing List is generated and locked. Delete is disabled.";
    return;
  }
  const selected = getSelectedPackingLineKeys();
  packingListRowsState = getPackingListRows().filter((row) => !selected.includes(getPackingLineKey(row)));
  selected.forEach((key) => delete packingLabelPrintRecords[key]);
  statusMessage.textContent = `${selected.length} packing list line(s) ${actionLabel}.`;
  renderStage("packing-list");
}

function printSelectedPoPackingLabels() {
  const selected = getSelectedPackingLineKeys();
  const now = new Date().toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" });
  selected.forEach((key) => {
    packingLabelPrintRecords[key] = { user: currentLogin ? currentLogin.user : "goods.in", dateTime: now, poLabel: true };
  });
  statusMessage.textContent = `PO packing label printed for ${selected.length} selected line(s).`;
  renderStage("packing-list");
}
function getFilteredPackingListRows() {
  const search = String(packingListSearch || "").trim().toLowerCase();
  return getPackingListRows().filter((row) => {
    if (!row.orderNo || !row.partNo || !row.description) return false;
    // Remove empty template rows from the View Packing List grid
    if (!row.batchNo || !row.expiryDate || !row.qty || row.qty === "" || row.qty === "0") return false;
    
    if (!search) return true;
    return [row.orderNo, row.lineNo, row.partNo, row.description, row.batchNo, getMfgLotNo(row), row.suppName, row.suppCode, row.foreignName, row.ecma]
      .some((value) => String(value || "").toLowerCase().includes(search));
  });
}
function getVisiblePackingListRowsSnapshot() {
  const tableRows = [...document.querySelectorAll(".packing-list-table tbody tr")];
  if (!tableRows.length) return null;
  return tableRows.map((tableRow) => {
    const keySource = tableRow.querySelector("[data-packing-row-key]") || tableRow.querySelector("[data-packing-row-select]");
    const rowKey = keySource ? (keySource.dataset.packingRowKey || keySource.dataset.packingRowSelect) : "";
    const sourceRow = getPackingListRows().find((row) => getPackingLineKey(row) === rowKey);
    if (!sourceRow) return null;
    const snapshot = { ...sourceRow };
    tableRow.querySelectorAll("[data-packing-row-input]").forEach((input) => {
      snapshot[input.dataset.packingRowInput] = input.value;
    });
    tableRow.querySelectorAll("[data-packing-row-checkbox]").forEach((input) => {
      snapshot[input.dataset.packingRowCheckbox] = input.checked;
    });
    return snapshot;
  }).filter(Boolean);
}

function getGeneratedPackingRows(poNo) {
  return generatedPackingListSnapshots[poNo] || null;
}
function getPackingRequiredDocuments() {
  return [
    { id: "supplier-invoice", name: "Supplier Invoice" },
    { id: "po", name: "PO" },
    { id: "supplier-packing-list", name: "Supplier Packing List" },
    { id: "supplier-declaration", name: "Supplier Declaration" },
    { id: "temperature-record", name: "Temperature Record" },
    { id: "goods-receiving-checklist", name: "Goods Receiving Checklist" },
    { id: "delivery-details", name: "Delivery Details" }
  ];
}
function createPackingWorkflow(poNo) {
  return {
    poNo,
    status: "Pending Uploads",
    signoff: null,
    documents: getPackingRequiredDocuments().map((doc) => ({ ...doc, required: true, uploaded: false, fileName: "", verified: false }))
  };
}
function getPackingLineUserComment(row) {
  return row.userComments || "";
}

function ensureRpExampleWorkflows() {
  const poNos = [...new Set(getPackingListRows().filter((row) => row.orderNo).map((row) => row.orderNo))];
  poNos.slice(0, 6).forEach((poNo, index) => {
    if (!rpPackWorkflows[poNo]) {
      rpPackWorkflows[poNo] = createPackingWorkflow(poNo);
    }
    const po = rpPackWorkflows[poNo];
    const rows = getPackingListRows().filter((row) => row.orderNo === poNo);
    if (po.status !== "Rejected by RPi") {
      po.documents = po.documents.map((doc) => ({
        ...doc,
        uploaded: true,
        fileName: doc.fileName || `${poNo}_${doc.name.replace(/\s+/g, "_")}.pdf`
      }));
    }
    if (!po.signoff) {
      po.signoff = { user: "goods.in", dateTime: `02 Jul 2026, ${String(9 + index).padStart(2, "0")}:15:00` };
    }
    if (!po.status || po.status === "Pending Uploads" || po.status === "RPi Checklist Open") po.status = "Signed Off";
    po.supplier = rows[0]?.suppName || po.supplier || "Supplier pending";
    packingListGenerated = true;
  });
}

function getRpTaskFilteredPoKeys() {
  ensureRpExampleWorkflows();
  const search = String(rpApprovalSearch || "").trim().toLowerCase();
  return Object.keys(rpPackWorkflows).filter((poKey) => {
    const po = rpPackWorkflows[poKey];
    const rows = getPackingListRows().filter((row) => row.orderNo === poKey);
    const readyForRp = (po.status === "Signed Off" || po.signoff) && po.status !== "Rejected by RPi" && po.status !== "RPi Approved" && !rpApprovalSignoffs[poKey];
    if (!readyForRp) return false;
    if (!search) return true;
    return [poKey, po.status, po.supplier, rpRejectionComments[poKey], ...rows.flatMap((row) => [row.suppName, row.description, row.batchNo, getMfgLotNo(row)])]
      .some((value) => String(value || "").toLowerCase().includes(search));
  });
}
function getPackingDocCounts(po) {
  const docs = po && po.documents ? po.documents.filter((doc) => getPackingRequiredDocuments().some((required) => required.id === doc.id)) : [];
  return { uploaded: docs.filter((doc) => doc.uploaded).length, verified: docs.filter((doc) => doc.verified).length, total: getPackingRequiredDocuments().length };
}
function getPoSupplierDetails(poNo) {
  const row = getPackingListRows().find((item) => item.orderNo === poNo) || {};
  return { supplierCode: row.suppCode || "", supplierName: row.suppName || "" };
}function renderPackingListWork(stage) {
  const currentPoNo = packingListSearch || packingListSelectedPo || "C13719";
  const generatedRows = packingListMode === "view" ? getGeneratedPackingRows(currentPoNo) : null;
  const rows = generatedRows || getFilteredPackingListRows();
  const totalQty = rows.reduce((sum, row) => sum + Number(row.qty || 0), 0);
  return `
    <div class="packing-list-layout">
      <section class="packing-list-window">
<div class="sub-window-title">Packing List</div>
<div class="packing-tabs">
  <button class="${packingListMode === "add" ? "active" : ""}" type="button" data-packing-tab="add">Add Packing List</button>
  <button class="${packingListMode === "view" ? "active" : ""}" type="button" data-packing-tab="view">View Packing List</button>
  <button class="${packingListMode === "documents" ? "active" : ""}" type="button" data-packing-tab="documents">RPi Documents</button>
</div>
${packingListMode === "add" ? renderPackingListAdd(stage) : packingListMode === "view" ? renderPackingListView(stage, rows, totalQty) : renderPackingRpDocuments(stage)}
      </section>
    </div>
  `;
}

function renderPackingListAdd(stage) {
  const poNo = packingListSelectedPo || "";
  const workflow = rpPackWorkflows[poNo];
  const counts = getPackingDocCounts(workflow);
  const requiredDocs = getPackingRequiredDocuments();

  const uploadHtml = poNo && workflow ? `
    <fieldset class="packing-invoice-panel add-doc-upload-panel">
      <legend>Supplier Documents <span>${counts.uploaded}/${counts.total} uploaded</span></legend>
      <div class="packing-doc-upload-grid">
        ${requiredDocs.map((required, index) => {
          const doc = workflow.documents.find((item) => item.id === required.id) || required;
          const uploaded = Boolean(doc.uploaded);
          return `
            <label class="packing-doc-upload ${uploaded ? "uploaded" : ""}">
              <strong>${index + 1}. ${required.name}</strong>
              <span>${uploaded ? (doc.fileName || "Uploaded") : "No file chosen"}</span>
              <input type="file" data-pl-add-file="${required.id}" data-pl-add-po="${poNo}">
            </label>
          `;
        }).join("")}
      </div>
    </fieldset>
  ` : "";

  return `
    <div class="packing-list-panel add-packing-panel reference-add-panel">
      <div class="packing-add-search-row packing-add-reference-search">
        <label class="classic-search-label">PO No: <input class="classic-search-input" id="pl-add-po-input" value="${poNo}" placeholder="Enter PO no"></label>
        <label class="classic-search-label">Supplier Code: <input class="classic-search-input" value="" placeholder="Enter supplier code"></label>
        <label class="classic-search-label">Supplier Name: <input class="classic-search-input" value="" placeholder="Enter supplier name"></label>
        <button class="classic-search-button" type="button" id="pl-add-search-btn">Search</button>
        <button class="classic-button packing-clear-button" type="button" id="pl-add-clear-btn">Clear</button>
      </div>
      <div class="packing-grid-shell tall reference-grid-shell">
        <div class="packing-empty-grid reference-empty-grid" style="height: 100%; min-height: 360px; display: flex; align-items: center; justify-content: center; background: #b3b3b3; border: 1px solid #222; color: transparent;">
          <span aria-hidden="true">Blank packing list entry area</span>
        </div>
      </div>
      <div class="packing-add-bottom reference-add-bottom">
        <div class="packing-actions-stack">
          <button class="classic-button primary" type="button" id="pl-add-save-btn">Save</button>
          <button class="classic-button" type="button" id="pl-add-remove-btn">Remove Line</button>
          <button class="classic-button primary" type="button" id="pl-add-generate-btn" ${!canGeneratePackingList(poNo) ? "disabled" : ""}>Print Packing List</button>
        </div>
        ${uploadHtml}
      </div>
    </div>
  `;
}

function renderPackingListView(stage, rows, totalQty) {
  const isLocked = isPackingListLocked();
  const lockAttr = isLocked ? "disabled" : "";
  const readonlyAttr = isLocked ? "readonly" : "";
  const lockNotice = "";
  return `
    <div class="packing-list-panel view-packing-panel">
      <div class="packing-view-search-row">
<label class="classic-search-label">P.O. No : <input class="classic-search-input" data-packing-search value="${packingListSearch || "C13719"}" placeholder="Enter PO no"></label>
<button class="classic-button" type="button" data-packing-search-button>Search</button>
      </div>
      <div class="packing-grid-shell tall">
<table class="classic-table product-grid packing-list-table wide-packing-table">
  <thead>
    <tr>
      <th></th><th></th><th>Print Packing Label</th><th class="twod-col">Presence of 2D</th><th class="compact-col">ORDER_NO</th><th>LINE_NO</th><th>PART_NO</th><th>DESCRIPTION</th><th>BATCH_NO</th><th class="mfg-lot-col">MFG_LOT_NO</th><th>EXPIRY_DATE</th><th class="edit-col">QTY</th><th class="edit-col">BOXES</th><th>VERIFY & PRINT</th><th>COMMENTS</th><th>SUPP_NAME</th><th>SUPP_CODE</th><th>LOG</th><th>CREATED_BY</th><th>CREATED_DATE</th><th>FOREIGN_NAME</th><th>STRENGTH</th><th>PACK_SIZE</th><th>COUNTRY</th><th>ECMA</th><th>CONTRACT</th><th>BARCODE</th><th>VALIDBARCODE</th>
    </tr>
  </thead>
  <tbody>${rows.map((row, index) => {
    const key = getPackingLineKey(row);
    const printRecord = packingLabelPrintRecords[key];
    return `
      <tr class="${index === 0 ? "selected-row" : ""} ${printRecord ? "packing-label-printed" : ""}">
<td><button class="split-line-button" type="button" title="${isLocked ? "Packing List generated - split disabled" : "Double click to split line"}" data-split-packing-line="${key}" ${lockAttr}>&gt;</button></td>
<td><input type="checkbox" data-packing-row-select="${key}" ${index === 0 ? "checked" : ""} ${lockAttr}></td>
<td><button class="packing-label-button" type="button" data-print-packing-label="${key}" ${lockAttr}>${printRecord ? `Printed ${printRecord.user}` : "Print Packing Label"}</button></td>
<td class="twod-col"><input type="checkbox" data-packing-row-checkbox="presenceOf2D" data-packing-row-key="${key}" ${row.presenceOf2D ? "checked" : ""} ${lockAttr}></td>
<td class="compact-col">${row.orderNo}</td><td>${row.lineNo}</td><td>${row.partNo}</td><td>${row.description}</td><td>${row.batchNo}</td><td class="mfg-lot-col">${getMfgLotNo(row) || "-"}</td><td>${row.expiryDate}</td>
<td><input class="grid-edit-input" data-packing-row-input="qty" data-packing-row-key="${key}" value="${row.qty}" ${readonlyAttr}></td>
<td><input class="grid-edit-input" data-packing-row-input="boxes" data-packing-row-key="${key}" value="${row.boxes}" ${readonlyAttr}></td>
<td>
  ${printRecord ? `
    <span style="color: #065f46; font-weight: bold; font-size: 11px;">Verified</span>
  ` : `
    <button class="classic-button row-verify-button" type="button" data-pl-verify-print="${key}" ${lockAttr} style="font-size: 10px; padding: 2px 6px; background-color: #1e3a8a; color: white;">Verify</button>
  `}
</td>
<td><input class="grid-edit-input packing-comment-input" data-packing-row-input="userComments" data-packing-row-key="${key}" value="${getPackingLineUserComment(row)}" placeholder="Comments" ${readonlyAttr}></td><td>${row.suppName}</td><td>${row.suppCode}</td><td>${printRecord ? `Label printed by ${printRecord.user} at ${printRecord.dateTime}` : row.comments}</td><td>${row.createdBy}</td><td>${row.createdDate}</td><td>${row.foreignName}</td><td>${row.strength}</td><td>${row.packSize}</td><td>${row.country}</td><td>${row.ecma}</td><td>${row.contract}</td><td>${row.barcode}</td><td>${row.validBarcode}</td>
      </tr>`;
  }).join("")}</tbody>
</table>
      </div>
      <div class="packing-view-actions">
<button class="classic-button" type="button" data-generate-packing-list ${!isLocked && !canGeneratePackingList(packingListSearch || "C13719") ? "disabled" : ""}>${isLocked ? "View Generated PO Packing List" : "Generate PO Packing List"}</button>
<button class="classic-button" type="button" data-print-selected-po-labels ${lockAttr}>Print PO Packing Label</button>
<button class="classic-button danger" type="button" data-delete-packing-lines ${lockAttr}>Delete</button>
<button class="classic-button primary" type="button" data-packing-save ${lockAttr}>Save</button>
<button class="classic-button" type="button" data-remove-packing-lines ${lockAttr}>Remove Line</button>
${lockNotice}${poPackingListSignoff ? `<span class="packing-action-status">PO Packing List signed by ${poPackingListSignoff.user} ${poPackingListSignoff.dateTime}</span>` : ""}
      </div>
      <div class="double-check-counts"><span>Total Lines : <strong>${rows.length}</strong></span><span>Total Quantity : <strong>${totalQty}</strong></span><span>Printed Labels : <strong>${Object.keys(packingLabelPrintRecords).length}</strong></span></div>
    </div>
  `;
}

function renderPackingRpDocuments(stage) {
  if (Object.keys(rpPackWorkflows).length === 0) {
    rpPackWorkflows["C13719"] = createPackingWorkflow("C13719");
  }

  const poKeys = Object.keys(rpPackWorkflows).filter((poKey) => rpPackWorkflows[poKey]?.status !== "RPi Approved" && !rpApprovalSignoffs[poKey]);
  if (!selectedRpPackPo) {
    const poListHtml = poKeys.map((poKey) => {
      const po = rpPackWorkflows[poKey];
      const counts = getPackingDocCounts(po);
      const rows = getPackingListRows().filter((row) => row.orderNo === poKey);
      const statusClass = po.status === "Rejected by RPi" ? "rejected-status" : po.status === "Signed Off" ? "done-status" : counts.uploaded === counts.total ? "active-status" : "pending-status";
      return `
        <button class="rp-po-card rp-doc-po-card ${po.status === "Rejected by RPi" ? "rejected" : ""}" type="button" data-rp-select-po="${poKey}">
          <strong>${poKey}</strong>
          <span class="status ${statusClass}">${counts.uploaded}/${counts.total} documents uploaded</span>
          <small>${rows.length} packing list line${rows.length === 1 ? "" : "s"}</small>
          <small>${po.status}</small>
        </button>
      `;
    }).join("");
    return `
      <div class="packing-list-panel rp-documents-panel rp-documents-list-first">
        <div class="rp-documents-header">
          <div>
            <h3>RPi Documents - Active PO List</h3>
          </div>
        </div>
        <div class="rp-doc-po-grid">${poListHtml || `<div class="rp-empty-state"><p>No packing list POs created yet.</p></div>`}</div>
      </div>
    `;
  }

  const activePo = rpPackWorkflows[selectedRpPackPo];
  if (!activePo) {
    selectedRpPackPo = null;
    return renderPackingRpDocuments(stage);
  }
  const requiredDocs = getPackingRequiredDocuments();
  const counts = getPackingDocCounts(activePo);
  const rows = getPackingListRows().filter((row) => row.orderNo === activePo.poNo);
  const allUploaded = counts.uploaded === counts.total;
  const allDocsVerified = requiredDocs.every((required) => {
    const doc = activePo.documents.find((item) => item.id === required.id);
    return doc && doc.uploaded && doc.verified === true;
  });

  const docTilesHtml = requiredDocs.map((required, index) => {
    const doc = activePo.documents.find((item) => item.id === required.id) || required;
    const uploaded = Boolean(doc.uploaded);
    const verified = Boolean(doc.verified);
    
    let statusClass = "missing";
    let statusText = "No File";
    if (uploaded) {
      statusClass = verified ? "verified" : "pending";
      statusText = verified ? "Verified" : "Pending View";
    }

    return `
      <div class="rp-doc-tile">
        <span class="rp-tile-index">${String(index + 1).padStart(2, "0")}</span>
        <div class="rp-tile-header">
          <div class="rp-tile-title">${required.name}</div>
          <div class="rp-tile-subtitle">${uploaded ? (doc.fileName || "Uploaded File") : "Upload Required"}</div>
        </div>
        <div class="rp-tile-status">
          <span class="rp-tile-badge ${statusClass}">${statusText}</span>
        </div>
        <div class="rp-tile-action">
          ${uploaded ? `
            <button class="classic-button link-button" type="button" data-pl-preview-doc="${doc.id}" data-pl-preview-po="${activePo.poNo}" style="font-size: 11px; padding: 4px 8px; width: 100%;">Preview</button>
          ` : `
            <input type="file" data-pl-add-file="${required.id}" data-pl-add-po="${activePo.poNo}" style="font-size: 10px; width: 100%;">
          `}
        </div>
      </div>
    `;
  }).join("");

  const isPackingListVerified = activePo.viewedDocs && activePo.viewedDocs["generated-packing-list"] === true;
  let plStatusClass = packingListGenerated ? (isPackingListVerified ? "verified" : "pending") : "missing";
  let plStatusText = packingListGenerated ? (isPackingListVerified ? "Verified" : "Pending View") : "Not Generated";
  
  const packingListTileHtml = `
    <div class="rp-doc-tile" style="background-color: #fffbeb; border-color: #fcd34d;">
      <span class="rp-tile-index">08</span>
      <div class="rp-tile-header">
        <div class="rp-tile-title" style="color: #92400e;">Generated PO Packing List</div>
        <div class="rp-tile-subtitle">Generated by PLPI</div>
      </div>
      <div class="rp-tile-status">
        <span class="rp-tile-badge ${plStatusClass}">${plStatusText}</span>
      </div>
      <div class="rp-tile-action">
        ${packingListGenerated ? `
          <button class="classic-button link-button" type="button" data-pl-preview-generated-packing-list data-rp-view-generated-packing-list data-pl-preview-po="${activePo.poNo}" style="font-size: 11px; padding: 4px 8px; width: 100%; background-color: #d97706; color: white;">Preview</button>
        ` : `
          <span class="disabled-text" style="font-size: 11px; color: #92400e; text-align: center; width: 100%; display: block; font-weight: bold;">N/A</span>
        `}
      </div>
    </div>
  `;

  return `
    <div class="packing-list-panel rp-documents-panel">
      <div class="rp-documents-header">
        <button class="classic-button" type="button" data-rp-docs-back>Back to PO List</button>
        <div>
          <h3>RPi Documents Dashboard - PO ${activePo.poNo}</h3>
          <p>${counts.uploaded}/${counts.total} documents uploaded. All 8 documents must be uploaded & verified before sign off.</p>
        </div>
        <span class="viewed-badge ${activePo.status === "Signed Off" ? "viewed" : "pending"}">${activePo.status}</span>
      </div>
      <div class="rp-doc-tiles-grid">
        ${docTilesHtml}
        ${packingListTileHtml}
      </div>
      <div class="signature-grid rp-doc-signoff-row">
        <label>Goods-In Operator <input value="${currentLogin ? currentLogin.user : stage.user}" readonly></label>
        <label>Date / Time <input value="${activePo.signoff ? activePo.signoff.dateTime : "Pending verification of all 8 files"}" readonly></label>
        <div class="signoff-action process-signoff-action">
          <button class="classic-button primary" type="button" id="rp-documents-signoff-button" ${allUploaded && isPackingListVerified && activePo.status !== "Signed Off" ? "" : "disabled"}>User Sign Off</button>
        </div>
      </div>
    </div>
  `;
}
function updateRpDocumentsAvailability() {
  const button = document.querySelector("#rp-documents-signoff-button");
  if (!button) return;
  const po = rpPackWorkflows[selectedRpPackPo];
  if (!po || po.status === "Signed Off") {
    button.disabled = true;
    return;
  }
  const counts = getPackingDocCounts(po);
  const isPackingListVerified = po.viewedDocs && po.viewedDocs["generated-packing-list"] === true;
  button.disabled = counts.uploaded !== counts.total || !isPackingListVerified;
  button.title = button.disabled ? "Upload all required documents and verify the generated PO Packing List." : "Ready for RPi Pack user sign off";
}

function completeRpDocumentsSignoff() {
  const now = getAssemblyAuditTimestamp();
  const po = rpPackWorkflows[selectedRpPackPo];
  if (po) {
    po.status = "Signed Off";
    po.signoff = { user: currentLogin ? currentLogin.user : "goods.in", dateTime: now };
    statusMessage.textContent = `RPi Pack documents uploaded and signed off for PO ${selectedRpPackPo}.`;
  }
  selectedRpApprovalPo = null;
  selectedRpPackPo = null;
  packingListMode = "documents";
  renderStage("packing-list");
}

// State variables for Batch Checker module
let batchCheckerSearch = "";
let selectedBatchCheckerRowKey = null;
let batchCheckerSelectedPo = "";
let batchCheckerDashboardOpen = false;
let batchCheckerChecklistOpen = false;
let batchCheckerDetailChecks = {};
let batchCheckerFilters = { product: "", site: "", po: "", status: "", mfgLot: "" };
let batchCheckerCheckedRows = {}; // index -> checked boolean
let batchCheckerVerifiedRows = {}; // index -> { checker: 'name', date: 'date' }
let batchCheckerPrintedLabelRows = {}; // rowKey -> { user, dateTime, type }
let batchCheckerPclGeneratedRows = {}; // rowKey -> { user, dateTime }
let selectedBatchCheckerRowIndexForPopup = null; // row being updated with Mfg
let selectedBatchCheckerRowIndexForSplit = null; // row being split
let batchCheckerMfgList = [
  { name: "Boehringer Ingelheim Ellas ...", address: "5th km Paiania - Markopoulo, Koropi Attiki, 194 00, Greece" },
  { name: "Boehringer Ingelheim Phar...", address: "Binger Strasse 173, D-55216 Ingelheim am Rhein, Germany" },
  { name: "Dragenopharm Apotheker...", address: "Dragenopharm Apotheker Puschl GmbH, Germany" }
];

let batchCheckerDb = [
  {
    orderNo: "C13777",
    foreignName: "AirFluSal Forspiro in...",
    strength: "50 microgra...",
    packSize: "60 doses",
    ecma: "23170",
    batchNo: "PX8416",
    expiryDate: "31-10-2027",
    qty: "300",
    boxes: "3",
    manufacturer: "Boehringer Ingelheim Ellas ...",
    foreignLicense: "Sandoz Gm...",
    partNo: "PLAIR50/50...",
    imp: "C13777",
    printType: "",
    invoice: "2904",
    invoiceDate: "22-06-2026",
    supplier: "Abimed 3 Ltd",
    reviewDate: "13/02/2026",
    country: "BULGARIA",
    originCountry: "POLAND",
    actionCount: "10",
    description: "AirFluSal Forspiro",
    prodStatus: "Active",
    status: "",
    warehouse: "Q-25-A",
    product: "AirFluSal Forspiro",
    productId: "6020",
    mfgId: "101",
    contractSign: "",
    contractStatus: "",
    category: "",
    comments: "Mock-up do...",
    mockup: "Product Mockup",
    scans: "Raw Pack Scans",
    objId: "AAARu9ABy...",
    piObjId: "AAARu9ABy...",
    packingId: "326360",
    invoiceFile: "F:\\PI GOOD...",
    site: "WHO",
    coldChain: "No",
    controlDr: "No",
    foreignLeaflet: "04/2022"
  },
  {
    orderNo: "C13777",
    foreignName: "Spiriva caps...",
    strength: "18 microgram",
    packSize: "30 capsule...",
    ecma: "9766/2017/02",
    batchNo: "503474",
    expiryDate: "30-06-2027",
    qty: "47",
    boxes: "1",
    manufacturer: "Boehringer Ingelheim Phar...",
    foreignLicense: "Boehringer ...",
    partNo: "ROSPI18MC...",
    imp: "C13777",
    printType: "",
    invoice: "2904",
    invoiceDate: "22-06-2026",
    supplier: "Abimed 3 Ltd",
    reviewDate: "13/02/2026",
    country: "BULGARIA",
    originCountry: "ROMANIA",
    actionCount: "18",
    description: "Spiriva Inha...",
    prodStatus: "Active",
    status: "",
    warehouse: "",
    product: "Spiriva inhalation p...",
    productId: "4144",
    mfgId: "102",
    contractSign: "",
    contractStatus: "3",
    category: "",
    comments: "Line update...",
    mockup: "Product Mockup",
    scans: "Raw Pack Scans",
    objId: "AAARu9ABy...",
    piObjId: "",
    packingId: "326369",
    invoiceFile: "F:\\PI GOOD...",
    site: "WHO",
    coldChain: "No",
    controlDr: "No",
    foreignLeaflet: "05/2023"
  },
  {
    orderNo: "C13777",
    foreignName: "Jentadueto",
    strength: "2.5 mg/1,0...",
    packSize: "60 tablets",
    ecma: "EU/1/12/780/020-BG",
    batchNo: "479510",
    expiryDate: "30-11-2028",
    qty: "256",
    boxes: "0",
    manufacturer: "Boehringer Ingelheim Phar...",
    foreignLicense: "Boehringer ...",
    partNo: "BGJEN2.5/1...",
    imp: "C13777",
    printType: "",
    invoice: "2904",
    invoiceDate: "22-06-2026",
    supplier: "Abimed 3 Ltd",
    reviewDate: "13/02/2026",
    country: "BULGARIA",
    originCountry: "BULGARIA",
    actionCount: "15",
    description: "",
    prodStatus: "Active",
    status: "",
    warehouse: "",
    product: "Jentadueto film-coa...",
    productId: "4977",
    mfgId: "103",
    contractSign: "",
    contractStatus: "",
    category: "",
    comments: "Bulk PIL Var...",
    mockup: "Product Mockup",
    scans: "Raw Pack Scans",
    objId: "AAARu9ABy...",
    piObjId: "",
    packingId: "0",
    invoiceFile: "F:\\PI GOOD...",
    site: "WHO",
    coldChain: "No",
    controlDr: "No",
    foreignLeaflet: "03/2023"
  },
  {
    orderNo: "C13777",
    foreignName: "EXFORGE",
    strength: "10mg/160mg",
    packSize: "28",
    ecma: "EU/1/06/370/019-BG",
    batchNo: "TPVF6",
    expiryDate: "31-10-2028",
    qty: "79",
    boxes: "1",
    manufacturer: "Novartis Farma S.p.A.",
    foreignLicense: "Novartis Eu...",
    partNo: "BGEXF1016...",
    imp: "C13777",
    printType: "",
    invoice: "2904",
    invoiceDate: "22-06-2026",
    supplier: "Abimed 3 Ltd",
    reviewDate: "13/02/2026",
    country: "BULGARIA",
    originCountry: "BULGARIA",
    actionCount: "9",
    description: "Exforge 10/...",
    prodStatus: "Active",
    status: "",
    warehouse: "Q-25-A",
    product: "Exforge film-coated...",
    productId: "5313",
    mfgId: "301",
    contractSign: "",
    contractStatus: "",
    category: "",
    comments: "Foreign leaf...",
    mockup: "Product Mockup",
    scans: "Raw Pack Scans",
    objId: "AAARu9ABy...",
    piObjId: "AAARu9ABy...",
    packingId: "326363",
    invoiceFile: "F:\\PI GOOD...",
    site: "WHO",
    coldChain: "Yes",
    controlDr: "No",
    foreignLeaflet: "02/2025"
  }
];

function getBatchCheckerRowKey(row) {
  return row ? `${row.orderNo}_${row.batchNo}` : "";
}

function isBatchCheckerLabelPrinted(row) {
  if (!row) return false;
  const rowKey = getBatchCheckerRowKey(row);
  return Boolean(batchCheckerPrintedLabelRows[rowKey]);
}

function markBatchCheckerLabelPrinted(row, type = "Box Label") {
  if (!row) return null;
  const now = getAssemblyAuditTimestamp();
  const record = { user: currentLogin ? currentLogin.user : "batch.checker", dateTime: now, type };
  batchCheckerPrintedLabelRows[getBatchCheckerRowKey(row)] = record;
  row.labelPrinted = true;
  row.labelPrintedAt = now;
  return record;
}

function filterBatchCheckerRows(rows) {
  const productSearch = String(batchCheckerFilters.product || "").trim().toLowerCase();
  const siteSearch = String(batchCheckerFilters.site || "").trim().toLowerCase();
  const poSearch = String(batchCheckerFilters.po || "").trim().toLowerCase();
  const statusSearch = String(batchCheckerFilters.status || "").trim().toLowerCase();
  const mfgLotSearch = String(batchCheckerFilters.mfgLot || "").trim().toLowerCase();
  return rows.filter((row) => {
    const rowKey = getBatchCheckerRowKey(row);
    const currentStatus = batchCheckerPclGeneratedRows[rowKey] ? "PCL Generated" : (batchCheckerVerifiedRows[rowKey] ? "Verified" : (row.printType === "Printed - PCL" ? "PCL Generated" : (row.status || "Awaiting Batch Check")));
    return (!productSearch || String(row.product || row.description || row.foreignName || "").toLowerCase().includes(productSearch)) &&
      (!siteSearch || String(row.site || "").toLowerCase().includes(siteSearch)) &&
      (!poSearch || String(row.orderNo || "").toLowerCase().includes(poSearch)) &&
      (!statusSearch || currentStatus.toLowerCase().includes(statusSearch)) &&
      (!mfgLotSearch || String(getMfgLotNo(row) || "").toLowerCase().includes(mfgLotSearch));
  });
}
function getBatchCheckerRows() {

  const filtered = batchCheckerDb.filter(row => !batchCheckerSelectedPo || row.orderNo === batchCheckerSelectedPo);
  if (filtered.length > 0) return filterBatchCheckerRows(filtered);
  
  const plRows = getPackingListRows().filter(r => r.orderNo === batchCheckerSelectedPo);
  if (plRows.length > 0) {
    const mapped = plRows.map(row => ({
      orderNo: row.orderNo,
      foreignName: row.foreignName || row.description,
      strength: row.strength || "10mg",
      packSize: row.packSize || "28",
      ecma: row.ecma || "EU/1/10/655/002",
      batchNo: row.batchNo || "VHUN",
      mfgLotNo: getMfgLotNo(row),
      manufLotNo: getMfgLotNo(row),
      expiryDate: row.expiryDate || "31-10-2026",
      qty: row.qty || "100",
      boxes: row.boxes || "1",
      manufacturer: "",
      foreignLicense: row.suppName || "Pharma Supplier",
      partNo: row.partNo || "PTBRI90TAB56",
      imp: row.orderNo,
      printType: "",
      invoice: row.comments || "2904",
      invoiceDate: "22-06-2026",
      supplier: row.suppName || "Pharma Supplier",
      reviewDate: "13/02/2026",
      country: row.country || "BULGARIA",
      originCountry: row.country || "POLAND",
      actionCount: "10",
      description: row.description,
      prodStatus: "Active",
      status: "",
      warehouse: "",
      product: row.description,
      productId: row.productId || "5468",
      mfgId: "0",
      contractSign: "",
      contractStatus: "",
      category: "Relabelling",
      comments: row.comments || "",
      mockup: "Product Mockup",
      scans: "Raw Pack Scans",
      objId: "AAARu9ABy...",
      piObjId: "",
      packingId: "326360",
      invoiceFile: "F:\\PI GOOD...",
      site: "WHO",
      coldChain: "No",
      controlDr: "No",
      foreignLeaflet: "04/2022"
    }));
    batchCheckerDb.push(...mapped);
    return filterBatchCheckerRows(mapped);
  }
  return filterBatchCheckerRows([]);
}

function seedLiveTestingData() {
  const liveProducts = [
    { batch: "LVT001", manufLotNo: "MFG-ALP-2401", product: "Alphagan eye drops", partNo: "ESALP02EYE5", country: "SPAIN", strength: "0.2%", packSize: "5ml", quantity: "220", expiry: "31-08-2027", routeType: "Relabelling", category: "Relabelling", brailleRequired: true, cartonQuantity: "0", brailleQuantity: "220", leafletQuantity: "220", imp: "C13810", invoice: "INV-78210", ecma: "64120", pl: "18799/4011", productId: "7101", warehouse: "Q-26-A", supplierName: "Euroserv S.A.", foreignName: "Alphagan collyre", description: "Alphagan eye drops", batchType: "Consolidated" },
    { batch: "LVT002", manufLotNo: "MFG-BRI-2402", product: "Brilique film-coated tablets", partNo: "PTBRI90TAB56", country: "PORTUGAL", strength: "90mg", packSize: "56", quantity: "360", expiry: "30-09-2028", routeType: "Relabelling", category: "Relabelling", brailleRequired: true, cartonQuantity: "0", brailleQuantity: "360", leafletQuantity: "360", imp: "C13810", invoice: "INV-78210", ecma: "EU/1/10/655/002", pl: "18799/3999", productId: "7102", warehouse: "Q-26-B", supplierName: "Pharma Logistics PT", foreignName: "BRILIQUE comprimidos", description: "Brilique tablets", batchType: "Consolidated" },
    { batch: "LVT003", manufLotNo: "MFG-FOS-2403", product: "Foster Nexthaler", partNo: "ESFOS100-6", country: "SPAIN", strength: "100/6 microgram", packSize: "120 doses", quantity: "480", expiry: "31-10-2027", routeType: "Relabelling", category: "Relabelling", brailleRequired: true, cartonQuantity: "0", brailleQuantity: "480", leafletQuantity: "480", imp: "C13811", invoice: "INV-78211", ecma: "76713", pl: "18799/4050", productId: "7103", warehouse: "R8-A-02", supplierName: "Spanish Pharma Supply", foreignName: "FOSTER NEXTHALER", description: "Foster inhaler", batchType: "Composite" },
    { batch: "LVT004", manufLotNo: "MFG-OMA-2404", product: "Omacor capsules", partNo: "ESOMA1000", country: "SPAIN", strength: "1000mg", packSize: "28", quantity: "520", expiry: "30-09-2028", routeType: "Relabelling", category: "Relabelling", brailleRequired: false, cartonQuantity: "0", brailleQuantity: "0", leafletQuantity: "520", imp: "C13811", invoice: "INV-78211", ecma: "65476", pl: "18799/4115", productId: "7104", warehouse: "R8-A-03", supplierName: "Euroserv S.A.", foreignName: "Omacor cap.", description: "Omacor capsules", batchType: "Composite" },
    { batch: "LVT005", manufLotNo: "MFG-FLU-2405", product: "Flutiform inhalation", partNo: "CZFLU120ACT", country: "CZECH REPUBLIC", strength: "250/10mcg", packSize: "120 actuations", quantity: "650", expiry: "31-07-2027", routeType: "Reboxing", category: "Reboxing", brailleRequired: false, cartonQuantity: "650", brailleQuantity: "0", leafletQuantity: "650", imp: "C13812", invoice: "INV-78212", ecma: "14/555/12-C", pl: "18799/2922", productId: "7105", warehouse: "R6-B-04", supplierName: "DerStar Pharma SK s.r.o.", foreignName: "Flutiform suspenze", description: "Flutiform inhalation", batchType: "Composite" },
    { batch: "LVT006", manufLotNo: "MFG-ADA-2406", product: "Adartel tablets", partNo: "FRADA025TAB12", country: "FRANCE", strength: "0.25mg", packSize: "12", quantity: "180", expiry: "31-10-2027", routeType: "Relabelling", category: "Relabelling", brailleRequired: true, cartonQuantity: "0", brailleQuantity: "180", leafletQuantity: "180", imp: "C13812", invoice: "INV-78212", ecma: "3400939183947", pl: "18799/2070", productId: "7106", warehouse: "Q-25-C", supplierName: "Pharma Logistics FR", foreignName: "ADARTEL comprimes pellicules", description: "Adartel tablets", batchType: "Consolidated" },
    { batch: "LVT007", manufLotNo: "MFG-AZA-2407", product: "Azarga eye drops", partNo: "FRAZA10EYE5ML", country: "FRANCE", strength: "10mg/ml + 5mg/ml", packSize: "5ml", quantity: "75", expiry: "30-04-2027", routeType: "Relabelling", category: "Relabelling", brailleRequired: true, cartonQuantity: "0", brailleQuantity: "75", leafletQuantity: "75", imp: "C13813", invoice: "INV-78213", ecma: "EU/1/08/482/001", pl: "18799/3685", productId: "7107", warehouse: "Q-27-A", supplierName: "DerStar Pharma SK s.r.o.", foreignName: "AZARGA collyre", description: "Azarga eye drops", batchType: "Composite" },
    { batch: "LVT008", manufLotNo: "MFG-BON-2408", product: "Bonasol oral solution", partNo: "ITBON70MG4", country: "ITALY", strength: "70mg", packSize: "4", quantity: "96", expiry: "30-06-2027", routeType: "Reboxing", category: "Reboxing", brailleRequired: false, cartonQuantity: "96", brailleQuantity: "0", leafletQuantity: "96", imp: "C13813", invoice: "INV-78213", ecma: "040622033", pl: "18799/3031", productId: "7108", warehouse: "Q-27-B", supplierName: "UAB Dinera", foreignName: "BONASOL soluzione orale", description: "Bonasol oral solution", batchType: "Composite" },
    { batch: "LVT009", manufLotNo: "MFG-BAC-2409", product: "Bactroban ointment", partNo: "ESBACNA15G", country: "SPAIN", strength: "2% w/w", packSize: "15g", quantity: "240", expiry: "31-10-2027", routeType: "Reboxing", category: "Reboxing", brailleRequired: false, cartonQuantity: "240", brailleQuantity: "0", leafletQuantity: "240", imp: "C13814", invoice: "INV-78214", ecma: "58868", pl: "18799/1411", productId: "7109", warehouse: "R8-C-03", supplierName: "Spanish Pharma Supply", foreignName: "Bactroban pomada", description: "Bactroban ointment", batchType: "Composite" },
    { batch: "LVT010", manufLotNo: "MFG-EXF-2410", product: "Exforge tablets", partNo: "BGEXF1016", country: "BULGARIA", strength: "10mg/160mg", packSize: "28", quantity: "144", expiry: "31-10-2028", routeType: "Relabelling", category: "Relabelling", brailleRequired: true, cartonQuantity: "0", brailleQuantity: "144", leafletQuantity: "144", imp: "C13814", invoice: "INV-78214", ecma: "EU/1/06/370/019-BG", pl: "18799/5313", productId: "7110", warehouse: "Q-25-D", supplierName: "Abimed 3 Ltd", foreignName: "EXFORGE", description: "Exforge tablets", batchType: "Consolidated" },
    { batch: "LVT011", manufLotNo: "MFG-SPI-2411", product: "Spiriva inhalation capsules", partNo: "ROSPI18MC", country: "ROMANIA", strength: "18 microgram", packSize: "30 capsules", quantity: "210", expiry: "30-06-2027", routeType: "Relabelling", category: "Relabelling", brailleRequired: true, cartonQuantity: "0", brailleQuantity: "210", leafletQuantity: "210", imp: "C13815", invoice: "INV-78215", ecma: "9766/2017/02", pl: "18799/4144", productId: "7111", warehouse: "Q-28-A", supplierName: "Abimed 3 Ltd", foreignName: "Spiriva caps", description: "Spiriva inhalation capsules", batchType: "Consolidated" },
    { batch: "LVT012", manufLotNo: "MFG-JEN-2412", product: "Jentadueto tablets", partNo: "BGJEN251", country: "BULGARIA", strength: "2.5mg/1000mg", packSize: "60", quantity: "300", expiry: "30-11-2028", routeType: "Relabelling", category: "Relabelling", brailleRequired: true, cartonQuantity: "0", brailleQuantity: "300", leafletQuantity: "300", imp: "C13815", invoice: "INV-78215", ecma: "EU/1/12/780/020-BG", pl: "18799/4977", productId: "7112", warehouse: "Q-28-B", supplierName: "Abimed 3 Ltd", foreignName: "Jentadueto", description: "Jentadueto tablets", batchType: "Consolidated" },
    { batch: "LVT013", manufLotNo: "MFG-LAT-2413", product: "Latuda tablets", partNo: "ESLAT74MG", country: "SPAIN", strength: "74mg", packSize: "28 x 1", quantity: "132", expiry: "30-06-2030", routeType: "Relabelling", category: "Relabelling", brailleRequired: true, cartonQuantity: "0", brailleQuantity: "132", leafletQuantity: "132", imp: "C13816", invoice: "INV-78216", ecma: "EU/1/14/91", pl: "18799/5021", productId: "7113", warehouse: "Q-29-A", supplierName: "Euroserv S.A.", foreignName: "LATUDA comprimidos", description: "Latuda tablets", batchType: "Consolidated" },
    { batch: "LVT014", manufLotNo: "MFG-LUM-2414", product: "Lumigan eye drops", partNo: "ESLUMEYE30", country: "SPAIN", strength: "0.1mg/ml", packSize: "1 x 3ml", quantity: "390", expiry: "30-09-2027", routeType: "Relabelling", category: "Relabelling", brailleRequired: false, cartonQuantity: "0", brailleQuantity: "0", leafletQuantity: "390", imp: "C13816", invoice: "INV-78216", ecma: "EU/1/02/205", pl: "18799/5128", productId: "7114", warehouse: "Q-29-B", supplierName: "Euroserv S.A.", foreignName: "Lumigan", description: "Lumigan eye drops", batchType: "Composite" },
    { batch: "LVT015", manufLotNo: "MFG-MAS-2415", product: "Mastical tablets", partNo: "ESMAS500TAB", country: "SPAIN", strength: "500mg", packSize: "90", quantity: "280", expiry: "31-03-2028", routeType: "Relabelling", category: "Relabelling", brailleRequired: true, cartonQuantity: "0", brailleQuantity: "280", leafletQuantity: "280", imp: "C13817", invoice: "INV-78217", ecma: "58828", pl: "18799/5220", productId: "7115", warehouse: "Q-30-A", supplierName: "Euroserv S.A.", foreignName: "MASTICAL comp.", description: "Mastical tablets", batchType: "Consolidated" },
    { batch: "LVT016", manufLotNo: "MFG-SOL-2416", product: "Soludronate oral solution", partNo: "ESSOL70ML", country: "SPAIN", strength: "70mg", packSize: "4 x 100ml", quantity: "88", expiry: "31-12-2027", routeType: "Reboxing", category: "Reboxing", brailleRequired: false, cartonQuantity: "88", brailleQuantity: "0", leafletQuantity: "88", imp: "C13817", invoice: "INV-78217", ecma: "73232", pl: "18799/5330", productId: "7116", warehouse: "Q-30-B", supplierName: "Euroserv S.A.", foreignName: "Soludronate", description: "Soludronate oral solution", batchType: "Composite" },
    { batch: "LVT017", manufLotNo: "MFG-CLO-2417", product: "Clovate cream", partNo: "ESCLOCREA30", country: "SPAIN", strength: "0.05% w/w", packSize: "30g", quantity: "620", expiry: "31-03-2028", routeType: "Reboxing", category: "Reboxing", brailleRequired: false, cartonQuantity: "620", brailleQuantity: "0", leafletQuantity: "620", imp: "C13818", invoice: "INV-78218", ecma: "55746", pl: "18799/5441", productId: "7117", warehouse: "Q-31-A", supplierName: "Euroserv S.A.", foreignName: "Clovate cream", description: "Clovate cream", batchType: "Composite" },
    { batch: "LVT018", manufLotNo: "MFG-GIN-2418", product: "Gine Canesmed cream", partNo: "ESGINCAN20", country: "SPAIN", strength: "20g", packSize: "20g", quantity: "900", expiry: "31-01-2030", routeType: "Reboxing", category: "Reboxing", brailleRequired: false, cartonQuantity: "900", brailleQuantity: "0", leafletQuantity: "900", imp: "C13818", invoice: "INV-78218", ecma: "62220", pl: "18799/5510", productId: "7118", warehouse: "Q-31-B", supplierName: "Euroserv S.A.", foreignName: "Gine Canesmed", description: "Gine Canesmed cream", batchType: "Composite" },
    { batch: "LVT019", manufLotNo: "MFG-TAM-2419", product: "Tamsulosin capsules", partNo: "NLTAM400CAP", country: "NETHERLANDS", strength: "400 microgram", packSize: "30", quantity: "360", expiry: "30-04-2029", routeType: "Relabelling", category: "Relabelling", brailleRequired: true, cartonQuantity: "0", brailleQuantity: "360", leafletQuantity: "360", imp: "C13819", invoice: "INV-78219", ecma: "RVG 32919", pl: "18799/5620", productId: "7119", warehouse: "Q-32-A", supplierName: "Dutch Pharma Logistics", foreignName: "Tamsulosine capsules", description: "Tamsulosin capsules", batchType: "Consolidated" },
    { batch: "LVT020", manufLotNo: "MFG-VEN-2420", product: "Ventolin inhaler", partNo: "IEVEN100INH", country: "IRELAND", strength: "100 microgram", packSize: "200 doses", quantity: "540", expiry: "31-05-2029", routeType: "Reboxing", category: "Reboxing", brailleRequired: false, cartonQuantity: "540", brailleQuantity: "0", leafletQuantity: "540", imp: "C13819", invoice: "INV-78219", ecma: "PA 1077/071/001", pl: "18799/5750", productId: "7120", warehouse: "Q-32-B", supplierName: "Irish Pharma Supply", foreignName: "Ventolin Evohaler", description: "Ventolin inhaler", batchType: "Composite" }
  ].map((product) => ({
    status: product.status || "Active",
    site: "WHO",
    unitsPerPack: "1",
    productIntroduced: "12 Jan 2024",
    leafletDate: "02 Jan 2026",
    dateRevised: "12 Jun 2026",
    variationInfo: product.brailleRequired ? "Braille required" : "",
    reviewDate: "15/06/2026",
    supplierInvoice: product.invoice,
    leafletRequired: true,
    routeInstruction: product.routeType === "Reboxing" ? "Rebox and apply UK labels" : "Relabel approved stock",
    ...product
  }));

  liveProducts.forEach((product) => {
    if (!bnsProducts.some((existing) => existing.batch === product.batch)) bnsProducts.push(product);
  });

  const addMany = (target, values) => values.forEach((value) => {
    if (!target.includes(value)) target.push(value);
  });

  addMany(generatedBatchNumbers, ["LVT001", "LVT002", "LVT003", "LVT004", "LVT005", "LVT006", "LVT007", "LVT008", "LVT009", "LVT010", "LVT011", "LVT012", "LVT013", "LVT014", "LVT015", "LVT016", "LVT017", "LVT018", "LVT019", "LVT020"]);
  addMany(labelPrintedBatchNumbers, ["LVT003", "LVT004", "LVT005", "LVT006", "LVT007", "LVT008", "LVT009", "LVT010", "LVT011", "LVT012", "LVT013", "LVT014", "LVT015", "LVT016", "LVT017", "LVT018", "LVT019", "LVT020"]);
  addMany(leafletPrintedBatchNumbers, ["LVT005", "LVT006", "LVT007", "LVT008", "LVT009", "LVT010", "LVT011", "LVT012", "LVT013", "LVT014", "LVT015", "LVT016", "LVT017", "LVT018", "LVT019", "LVT020"]);
  addMany(cartonPrintedBatchNumbers, ["LVT008", "LVT009", "LVT016", "LVT017", "LVT018", "LVT020"]);
  addMany(braillePrintedBatchNumbers, ["LVT010", "LVT011", "LVT012", "LVT013", "LVT015", "LVT019"]);
  addMany(leafletFoldedBatchNumbers, ["LVT009", "LVT010", "LVT011", "LVT012", "LVT013", "LVT014", "LVT015", "LVT016", "LVT017", "LVT018", "LVT019", "LVT020"]);
  addMany(preAssemblyCheckedBatchNumbers, ["LVT012", "LVT013", "LVT014", "LVT015", "LVT016", "LVT017", "LVT018", "LVT019", "LVT020"]);
  addMany(productionAllocatedBatchNumbers, ["LVT014", "LVT015", "LVT016", "LVT017", "LVT018", "LVT019", "LVT020"]);
  addMany(assembledBatchNumbers, ["LVT016", "LVT017", "LVT018", "LVT019", "LVT020"]);
  addMany(postAssemblyCheckedBatchNumbers, ["LVT017", "LVT018", "LVT019", "LVT020"]);
  addMany(preQpCheckedBatchNumbers, ["LVT018", "LVT019", "LVT020"]);

  ["LVT014", "LVT015", "LVT016", "LVT017", "LVT018", "LVT019", "LVT020"].forEach((batch, index) => {
    productionRecords[batch] = productionRecords[batch] || { user: "production.control", dateTime: `24 Jun 2026, 0${9 + index}:15:00`, boxCount: String(2 + index), roomNo: `Room ${2 + (index % 3)}` };
  });
  ["LVT016", "LVT017", "LVT018", "LVT019", "LVT020"].forEach((batch, index) => {
    const product = bnsProducts.find((item) => item.batch === batch);
    assemblyRecords[batch] = assemblyRecords[batch] || { user: "assembly.room", dateTime: `24 Jun 2026, 1${index}:30:00`, boxCount: "4", usedLabels: product ? product.quantity : "100", startRecord: { user: "assembly.room", dateTime: "24 Jun 2026, 09:15:00" }, finishRecord: { user: "assembly.room", dateTime: "24 Jun 2026, 12:45:00" }, startTime: "24 Jun 2026, 09:15:00", finishTime: "24 Jun 2026, 12:45:00", signedTabs: { materials: { user: "assembly.room", dateTime: "24 Jun 2026, 09:30:00" }, samples: { user: "assembly.room", dateTime: "24 Jun 2026, 10:20:00" }, ipc: { user: "assembly.room", dateTime: "24 Jun 2026, 11:10:00" }, reconciliation: { user: "assembly.room", dateTime: "24 Jun 2026, 12:45:00" } } };
  });
  ["LVT017", "LVT018", "LVT019", "LVT020"].forEach((batch, index) => {
    const product = bnsProducts.find((item) => item.batch === batch);
    postAssemblyRecords[batch] = postAssemblyRecords[batch] || { user: "postassembly.qc", dateTime: `24 Jun 2026, ${14 + index}:20:00`, boxCount: String(Math.max(1, Math.ceil(Number(product ? product.quantity : 100) / 100))), totalQty: product ? product.quantity : "100", packsChecked: String(26 + index), quarantinePrinted: true, packChecksConfirmed: true, comments: "Demo record ready for Pre-QP." };
  });
  ["LVT018", "LVT019", "LVT020"].forEach((batch, index) => {
    const product = bnsProducts.find((item) => item.batch === batch);
    preQpRecords[batch] = preQpRecords[batch] || { sampleBox: "01", docs: ["Yes", "Yes", "Yes", "Yes", "Yes", "Yes"], materialChecked: true, comments: index === 0 ? "Release log printed; waiting QP decision." : "Release log printed and QP decision recorded.", user: "pre.qp", dateTime: `24 Jun 2026, 16:${10 + index * 8}:00`, logGenerated: true };
    qpReleaseRecords[batch] = qpReleaseRecords[batch] || { qpId: `QP-2026-00${5 + index}`, qpReady: true, qpLogGeneratedAt: `24 Jun 2026, 16:${35 + index * 7}:00`, releaseLog: product ? getQpReleaseLogDefaults(product) : {} };
  });
  qpReleaseRecords.LVT019 = { ...(qpReleaseRecords.LVT019 || {}), decision: "Approve", approved: true, decisionBy: "qp.release", decisionDateTime: "24 Jun 2026, 17:25:00" };
  qpReleaseRecords.LVT020 = { ...(qpReleaseRecords.LVT020 || {}), decision: "Hold", decisionBy: "qp.release", decisionDateTime: "24 Jun 2026, 17:40:00" };
  addMany(qpCertifiedBatchNumbers, ["LVT019", "LVT020"]);

  const liveBatchCheckerRows = liveProducts.slice(0, 8).map((product, index) => ({
    orderNo: index < 4 ? "C13810" : "C13811",
    foreignName: product.foreignName,
    strength: product.strength,
    packSize: product.packSize,
    ecma: product.ecma,
    batchNo: product.batch,
    mfgLotNo: product.manufLotNo,
    expiryDate: product.expiry,
    qty: product.quantity,
    boxes: String(Math.max(1, Math.ceil(Number(product.quantity || 0) / 120))),
    manufacturer: index % 2 ? "Novartis Farma S.p.A." : "Boehringer Ingelheim Pharma GmbH",
    foreignLicense: product.supplierName,
    partNo: product.partNo,
    imp: product.imp,
    printType: index === 2 ? "Printed - PCL" : "",
    invoice: product.invoice,
    invoiceDate: "24-06-2026",
    supplier: product.supplierName,
    reviewDate: "15/06/2026",
    country: product.country,
    originCountry: product.country,
    actionCount: String(8 + index),
    description: product.description,
    prodStatus: "Active",
    status: index === 2 ? "Printer" : "",
    warehouse: product.warehouse,
    product: product.product,
    productId: product.productId,
    mfgId: String(400 + index),
    contractSign: "Yes",
    contractStatus: "Active",
    category: product.category,
    comments: "Live test data",
    mockup: "Product Mockup",
    scans: "Raw Pack Scans",
    objId: `LVT-OBJ-${index + 1}`,
    piObjId: `LVT-PI-${index + 1}`,
    packingId: `LVT-PACK-${index + 1}`,
    invoiceFile: "F:\\PI GOOD...",
    site: "WHO",
    coldChain: index === 3 ? "Yes" : "No",
    controlDr: "No",
    foreignLeaflet: "06/2026"
  }));
  liveBatchCheckerRows.forEach((row) => {
    if (!batchCheckerDb.some((existing) => existing.orderNo === row.orderNo && existing.batchNo === row.batchNo)) batchCheckerDb.push(row);
  });
}

seedLiveTestingData();
function getRpApprovedPoKeysForBatchChecker() {
  const approved = Object.keys(rpPackWorkflows).filter((poNo) => rpApprovalSignoffs[poNo] || rpPackWorkflows[poNo]?.status === "RPi Approved");
  const seededPoKeys = [...new Set(batchCheckerDb.map((row) => row.orderNo).filter(Boolean))];
  return [...new Set([...approved, ...seededPoKeys])];
}

function getBatchCheckerRowsForPo(poNo) {
  const previousPo = batchCheckerSelectedPo;
  batchCheckerSelectedPo = poNo;
  const rows = getBatchCheckerRows();
  batchCheckerSelectedPo = previousPo;
  return rows;
}

function getBatchCheckerPoSummary(poNo) {
  const rows = getBatchCheckerRowsForPo(poNo);
  const signed = rows.filter((row) => batchCheckerPclGeneratedRows[getBatchCheckerRowKey(row)] || row.printType === "Printed - PCL").length;
  const verified = rows.filter((row) => batchCheckerVerifiedRows[getBatchCheckerRowKey(row)]).length;
  const lots = [...new Set(rows.map((row) => getMfgLotNo(row)).filter(Boolean))];
  const batches = [...new Set(rows.map((row) => row.batchNo || row.batch || "").filter(Boolean))];
  const totalQty = rows.reduce((sum, row) => sum + Number(row.qty || row.quantity || 0), 0);
  const totalBoxes = rows.reduce((sum, row) => sum + Number(row.boxes || row.goodsInBoxes || 0), 0);
  return { rows, signed, verified, lots, batches, totalQty, totalBoxes };
}

function getBatchCheckerVerificationItems(row) {
  const mfg = batchCheckerMfgList.find((item) => item.name === row.manufacturer);
  const mfgAddress = mfg ? mfg.address : (row.manufacturer || "Not selected");
  return [
    { key: "product", label: "Product name", value: row.product || row.description || row.foreignName || "-" },
    { key: "strengthPack", label: "Strength and Pack Size", value: `${row.strength || "-"} / ${row.packSize || "-"}` },
    { key: "ecma", label: "ECMA", value: row.ecma || "-" },
    { key: "sourceCountry", label: "Source Country", value: row.country || "-" },
    { key: "originCountry", label: "Country of origin", value: row.originCountry || row.country || "-" },
    { key: "invoice", label: "Invoice no.", value: row.invoice || "-" },
    { key: "rawScan", label: "Raw Product Scan", value: row.productId || row.objId || "Available" },
    { key: "batch", label: "Batch No.", value: row.batchNo || "-" },
    { key: "mfgLot", label: "MFG Lot No", value: getMfgLotNo(row) || "-" },
    { key: "expiry", label: "Expiry", value: row.expiryDate || "-" },
    { key: "quantity", label: "Quantity Received", value: row.qty || "-" },
    { key: "boxes", label: "Number of boxes in the Batch", value: row.boxes || "-" },
    { key: "manufacturer", label: "Manufacturer", value: row.manufacturer || "Not selected" },
    { key: "manufacturerAddress", label: "Manufacturer Address", value: mfgAddress },
    { key: "foreignEcma", label: "Foreign ECMA Holder", value: row.foreignLicense || row.supplier || "-" },
    { key: "leafletDate", label: "Foreign leaflet date", value: row.foreignLeaflet || "-" }
  ];
}

function getBatchCheckerLineChecks(row) {
  const rowKey = getBatchCheckerRowKey(row);
  const requiredLength = getBatchCheckerVerificationItems(row).length;
  if (!batchCheckerDetailChecks[rowKey]) {
    batchCheckerDetailChecks[rowKey] = Array(requiredLength).fill(false);
  }
  while (batchCheckerDetailChecks[rowKey].length < requiredLength) {
    batchCheckerDetailChecks[rowKey].push(false);
  }
  if (batchCheckerDetailChecks[rowKey].length > requiredLength) {
    batchCheckerDetailChecks[rowKey] = batchCheckerDetailChecks[rowKey].slice(0, requiredLength);
  }
  return batchCheckerDetailChecks[rowKey];
}

function areBatchCheckerLineChecksComplete(row) {
  return getBatchCheckerLineChecks(row).every(Boolean);
}

function getBatchCheckerStatusText(row) {
  const rowKey = getBatchCheckerRowKey(row);
  if (batchCheckerPclGeneratedRows[rowKey] || row.printType === "Printed - PCL") return "PCL Generated";
  if (batchCheckerVerifiedRows[rowKey]) return "Ready for PCL";
  return "Awaiting Batch Check";
}

function renderBatchCheckerFilters() {
  return `
    <div class="batchchecker-reference-toolbar batchchecker-one-line-filter">
      <label>Supplier : <input value=""></label>
      <label>Invoice No : <input data-batchchecker-filter="po" value="${batchCheckerFilters.po}"></label>
      <label>Contract Supp : <input value=""></label>
      <label class="compact-filter-field">IMP : <input value="${batchCheckerSelectedPo || ""}" readonly></label>
      <label class="compact-filter-field">Batch No : <input data-batchchecker-filter="mfgLot" value="${batchCheckerFilters.mfgLot}"></label>
      <label>Product : <input data-batchchecker-filter="product" value="${batchCheckerFilters.product}"></label>
      <button class="classic-button small" type="button" data-batchchecker-search-btn>Search</button>
    </div>
  `;
}
function renderBatchCheckerWork(stage) {
  const approvedPoKeys = getRpApprovedPoKeysForBatchChecker();
  const activePoKeys = approvedPoKeys.filter((poNo) => {
    const summary = getBatchCheckerPoSummary(poNo);
    return summary.rows.length > 0;
  });

  if (!batchCheckerDashboardOpen) {
    const poRows = activePoKeys.map((poNo) => {
      const po = rpPackWorkflows[poNo] || { poNo };
      const summary = getBatchCheckerPoSummary(poNo);
      const status = summary.signed === summary.rows.length && summary.rows.length ? "All PCL Generated" : summary.verified ? `${summary.verified}/${summary.rows.length} Verified` : "Awaiting Batch Check";
      return `
        <tr class="clickable-row" data-batchchecker-open-po="${poNo}">
          <td><strong>${poNo}</strong></td>
          <td>${po.supplier || summary.rows[0]?.supplier || "Supplier from PO"}</td>
          <td>${summary.rows.length}</td>
          <td class="batchchecker-summary-list">${summary.batches.length ? summary.batches.join(", ") : "Pending"}</td>
          <td class="batchchecker-summary-list">${summary.lots.length ? summary.lots.join(", ") : "Pending"}</td>
          <td>${summary.totalQty}</td>
          <td>${summary.totalBoxes}</td>
          <td>${status}</td>
          <td><button class="classic-button small" type="button" data-batchchecker-open-po="${poNo}">Open PO</button></td>
        </tr>
      `;
    }).join("");

    return `
      <div class="batchchecker-live-layout">
        <div class="batchchecker-live-header">
          <div>
            <h3>Batch Checker - RPi Approved PO List</h3>
            
          </div>
        </div>
        ${renderBatchCheckerFilters()}
        <div class="batchchecker-list-wrap">
          <table class="batchchecker-po-list">
            <thead><tr><th>PO</th><th>Supplier</th><th>Lines</th><th>BNS Batch No</th><th>MFG Lot No</th><th>Quantity</th><th>Boxes</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>${poRows || `<tr><td colspan="9" class="batchchecker-empty-state">No RPi approved POs are available yet. Complete RPi Task verification and sign off first.</td></tr>`}</tbody>
          </table>
        </div>
      </div>
    `;
  }

  const rows = getBatchCheckerRows();
  const totalQty = rows.reduce((sum, row) => sum + Number(row.qty || 0), 0);
  const selectedRow = selectedBatchCheckerRowKey !== null ? rows[selectedBatchCheckerRowKey] : null;

  if (selectedRow && batchCheckerChecklistOpen) {
    const row = selectedRow;
    const rowKey = getBatchCheckerRowKey(row);
    const checks = getBatchCheckerLineChecks(row);
    const labelRecord = batchCheckerPrintedLabelRows[rowKey];
    const verificationRows = [
      ["Product / description", row.product || row.description, row.description || row.product],
      ["Strength", row.strength, row.strength],
      ["Pack size", row.packSize, row.packSize],
      ["ECMA", row.ecma, row.ecma],
      ["Batch number", row.batchNo, row.batchNo],
      ["MFG lot number", getMfgLotNo(row) || "Pending", getMfgLotNo(row) || "Pending"],
      ["Quantity and boxes", `${row.qty} units / ${row.boxes} boxes`, `${row.qty} units / ${row.boxes} boxes`],
      ["Expiry and country", `${row.expiryDate} / ${row.country}`, `${row.expiryDate} / ${row.country}`]
    ];
    const allChecked = checks.every(Boolean);
    const canGeneratePcl = Boolean(allChecked && batchCheckerVerifiedRows[rowKey] && labelRecord);

    return `
      <div class="batchchecker-live-layout">
        <div class="batchchecker-live-header">
          <button class="classic-button" type="button" data-batchchecker-back-dashboard>Back to PO Dashboard</button>
          <div><h3>Checklist</h3><p>${row.orderNo} / ${row.product || row.description} / ${getMfgLotNo(row) || "MFG lot pending"}</p></div>
        </div>
        <div class="batchchecker-compare-grid">
          <div><strong>Supplier Packing List</strong><span>${row.supplier}</span><span>${row.product || row.description}</span><span>${row.strength} / ${row.packSize}</span><span>Qty ${row.qty}, Boxes ${row.boxes}</span></div>
          <div><strong>Checklist Data</strong><span>${row.orderNo}</span><span>${row.batchNo}</span><span>${getMfgLotNo(row) || "MFG lot pending"}</span><span>${row.expiryDate} / ${row.country}</span></div>
        </div>
        <div class="batchchecker-check-table-wrap">
          <table class="classic-table batchchecker-check-table">
            <thead><tr><th>Verification</th><th>Supplier data</th><th>System data</th><th>Checked</th></tr></thead>
            <tbody>${verificationRows.map((item, index) => `
              <tr>
                <td>${item[0]}</td>
                <td>${item[1] || "-"}</td>
                <td>${item[2] || "-"}</td>
                <td><input type="checkbox" data-batchchecker-verify-check="${index}" ${checks[index] ? "checked" : ""}></td>
              </tr>
            `).join("")}</tbody>
          </table>
        </div>
        <div class="batchchecker-detail-actions">
          <span>${labelRecord ? `Line clearance and label printed by ${labelRecord.user} at ${labelRecord.dateTime}` : "Tick every verification item, then Print PCL and Print Label."}</span>
          <button class="classic-button primary" type="button" id="batchchecker-detail-print-label" ${allChecked && !labelRecord ? "" : "disabled"}>Print Label</button>
          <button class="classic-button primary" type="button" id="batchchecker-generate-pcl" ${canGeneratePcl ? "" : "disabled"}>Print PCL</button>
        </div>
      </div>
    `;
  }

  const signed = rows.filter((row) => batchCheckerPclGeneratedRows[getBatchCheckerRowKey(row)] || row.printType === "Printed - PCL").length;
  const verified = rows.filter((row) => batchCheckerVerifiedRows[getBatchCheckerRowKey(row)]).length;
  const selectedKey = selectedRow ? getBatchCheckerRowKey(selectedRow) : "";
  const selectedVerified = selectedRow && batchCheckerVerifiedRows[selectedKey];
  const tableRowsHtml = rows.map((row, index) => {
    const rowKey = getBatchCheckerRowKey(row);
    const isPclGenerated = Boolean(batchCheckerPclGeneratedRows[rowKey] || row.printType === "Printed - PCL");
    const selected = selectedBatchCheckerRowKey === index && !isPclGenerated;
    const scanRef = row.productId || row.objId || index;
    const readonlyAttr = isPclGenerated ? "disabled" : "";
    return `
      <tr class="${selected ? "selected-row" : ""} ${isPclGenerated ? "pcl-generated-readonly-row" : ""}" data-batchchecker-row-index="${index}">
        <td class="batchchecker-select-cell"><button class="batchchecker-row-arrow" type="button" data-batchchecker-split="${index}" title="Edit quantity, expiry, and MFG lot" ${readonlyAttr}>&#9656;</button><input type="checkbox" data-batchchecker-row-select="${index}" ${selected ? "checked" : ""} ${readonlyAttr}></td>
        <td>${row.orderNo}</td>
        <td>${row.printType || ""}</td>
        <td>${row.invoice || ""}</td>
        <td>${row.invoiceDate || ""}</td>
        <td>${row.supplier || row.foreignLicense || ""}</td>
        <td>${row.reviewDate || ""}</td>
        <td>${row.country || ""}</td>
        <td>${row.originCountry || row.country || ""}</td>
        <td>${row.actionCount || ""}</td>
        <td>${row.partNo || ""}</td>
        <td>${row.batchChecker || row.checker || ""}</td>
        <td>${row.batchCheckDate || (batchCheckerVerifiedRows[rowKey] ? batchCheckerVerifiedRows[rowKey].date : "")}</td>
        <td>${row.description || row.product || row.foreignName || ""}</td>
        <td>${row.prodStatus || ""}</td>
        <td>${isPclGenerated ? "PCL Generated" : (row.status || getBatchCheckerStatusText(row))}</td>
        <td>${row.warehouse || ""}</td>
        <td>${row.product || row.description || row.foreignName || ""}</td>
        <td>${row.productId || ""}</td>
        <td>${row.mfgId || ""}</td>
        <td>${row.contractSign || ""}</td>
        <td>${row.contractStatus || ""}</td>
        <td>${row.category || ""}</td>
        <td>${row.comments || ""}</td>
        <td><button class="classic-button small" type="button" data-batchchecker-view-mockup="${scanRef}">Product Mockup</button></td>
        <td><button class="classic-button small" type="button" data-batchchecker-view-scan="${scanRef}">Raw Pack Scans</button></td>
        <td><button class="classic-button small" type="button" data-batchchecker-view-supplier-declaration="${index}">Supplier Declaration</button></td>
        <td><button class="classic-button small" type="button" data-batchchecker-view-temperature-record="${index}">Temperature Record</button></td>
        <td>${row.objId || ""}</td>
        <td>${row.piObjId || ""}</td>
        <td>${row.packingId || ""}</td>
        <td>${row.invoiceFile || ""}</td>
        <td>${row.site || ""}</td>
        <td>${row.coldChain || ""}</td>
        <td>${row.controlDr || ""}</td>
        <td>${row.foreignLeaflet || ""}</td>
        <td>${row.batchNo || ""}</td>
        <td><input class="batchchecker-grid-input small" data-batchchecker-row-edit="mfgLotNo" data-batchchecker-row-index="${index}" value="${getMfgLotNo(row)}" ${readonlyAttr}></td>
        <td><input class="batchchecker-grid-input small" data-batchchecker-row-edit="expiryDate" data-batchchecker-row-index="${index}" value="${row.expiryDate || ""}" ${readonlyAttr}></td>
        <td><input class="batchchecker-grid-input qty" data-batchchecker-row-edit="qty" data-batchchecker-row-index="${index}" value="${row.qty || ""}" ${readonlyAttr}></td>
        <td>${row.boxes || ""}</td>
        <td class="manufacturer-cell ${row.manufacturer ? "" : "missing-manufacturer"} ${isPclGenerated ? "readonly-cell" : ""}" ${isPclGenerated ? "" : `data-batchchecker-mfg-click="${index}"`}>${row.manufacturer || (isPclGenerated ? "Not selected" : "Select manufacturer")}</td>
        <td>${row.ecma || ""}</td>
        <td>${row.strength || ""}</td>
        <td>${row.packSize || ""}</td>
        <td>${row.imp || row.orderNo || ""}</td>
      </tr>
    `;
  }).join("");

  return `
    <div class="batchchecker-live-layout">
      <div class="batchchecker-live-header">
        <button class="classic-button" type="button" data-batchchecker-back-list>Back to Approved PO List</button>
        <div><h3>PO Dashboard - ${batchCheckerSelectedPo}</h3></div>
      </div>

      <div class="batchchecker-check-table-wrap detailed-list">
        <table class="classic-table batchchecker-dashboard-table batchchecker-product-list">
          <thead><tr><th>Select</th><th>PO</th><th>PRINT_TYPE</th><th>INVOICENO</th><th>INVOICEDATE</th><th>SUPPLIER</th><th>REVIEWDATE</th><th>COUNTRY</th><th>ORIGINCOUNTRY</th><th>ACTION_COUNT</th><th>IFS_PART_NO</th><th>BATCH_CHECKER</th><th>BATCH_CHECK_DATE</th><th>DESCRIPTION</th><th>PROD_STATUS</th><th>STATUS</th><th>WAREHOUSE</th><th>PRODUCT</th><th>PRODUCT_ID</th><th>MFG_ID</th><th>CONTRACT_SIGN</th><th>CONTRACT_STATUS</th><th>CATEGORY</th><th>COMMENTS</th><th>Product Mockup</th><th>Raw Pack Scans</th><th>Supplier Declaration</th><th>Temperature Record</th><th>OBJID</th><th>PIOBJID</th><th>PACKING_ID</th><th>INVOICE_FILE</th><th>SITE</th><th>Cold Chain</th><th>CONTROL_DR</th><th>FOREIGN_LEAFLET</th><th>BATCHNO</th><th>MFG Lot No</th><th>EXPIRATION</th><th>QUANTITY</th><th>GOODS_IN_BOXES</th><th>Manufacturer</th><th>ECMA</th><th>STRENGTH</th><th>PACKSIZE</th><th>IMP</th></tr></thead>
          <tbody>${tableRowsHtml || `<tr><td colspan="46" class="batchchecker-empty-cell">No product lines match the filters.</td></tr>`}</tbody>
        </table>
      </div>
      <div class="batchchecker-selected-actions">
        <span>${selectedRow ? `Selected: ${selectedRow.product || selectedRow.description || selectedRow.batchNo}` : "Select one product line to continue."}</span>
        <button class="classic-button primary" type="button" id="batchchecker-btn-check" ${selectedRow ? "" : "disabled"}>Batch Check</button>
        <button class="classic-button primary" type="button" id="batchchecker-generate-pcl" ${selectedVerified ? "" : "disabled"}>Print PCL</button>
        <button class="classic-button" type="button" id="batchchecker-print-box" ${selectedRow ? "" : "disabled"}>Print Box Label</button>
      </div>
    </div>
  `;
}
function updateBatchCheckerAvailability() {
  const genPclBtn = document.querySelector("#batchchecker-generate-pcl");
  const printLabelBtn = document.querySelector("#batchchecker-detail-print-label");
  if (!genPclBtn && !printLabelBtn) return;
  const rows = getBatchCheckerRows();
  const row = selectedBatchCheckerRowKey !== null ? rows[selectedBatchCheckerRowKey] : null;
  const rowKey = row ? getBatchCheckerRowKey(row) : "";
  const checksComplete = row ? areBatchCheckerLineChecksComplete(row) : false;
  const verified = row && batchCheckerVerifiedRows[rowKey];
  if (printLabelBtn) printLabelBtn.disabled = !(checksComplete && !verified);
  if (genPclBtn) genPclBtn.disabled = !(row && verified);
}

function openBatchCheckerDocumentViewer(row, documentType) {
  const title = documentType === "temperature" ? "Temperature Record" : "Supplier Declaration";
  const subtitle = documentType === "temperature"
    ? "Temperature readings checked and within accepted parameters."
    : "Supplier declaration confirms goods comply with Article 51 and approved supplier sourcing.";
  const documentNo = documentType === "temperature" ? `TEMP-${row.orderNo || "PO"}-${row.batchNo || "BATCH"}` : `DECL-${row.orderNo || "PO"}-${row.batchNo || "BATCH"}`;
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="760" height="520" viewBox="0 0 760 520">
      <rect width="760" height="520" fill="#f8fafc"/>
      <rect x="34" y="28" width="692" height="464" rx="10" fill="#ffffff" stroke="#b9c8d6" stroke-width="2"/>
      <rect x="34" y="28" width="692" height="62" rx="10" fill="#dfeef8"/>
      <text x="60" y="66" font-family="Segoe UI, Arial" font-size="24" font-weight="700" fill="#12395a">${title}</text>
      <text x="60" y="118" font-family="Segoe UI, Arial" font-size="15" fill="#334155">${subtitle}</text>
      <line x1="60" y1="145" x2="700" y2="145" stroke="#cbd5e1" stroke-width="2"/>
      <text x="60" y="185" font-family="Segoe UI, Arial" font-size="15" font-weight="700" fill="#0f172a">PO No</text>
      <text x="250" y="185" font-family="Segoe UI, Arial" font-size="15" fill="#0f172a">${row.orderNo || "-"}</text>
      <text x="60" y="225" font-family="Segoe UI, Arial" font-size="15" font-weight="700" fill="#0f172a">Supplier Name</text>
      <text x="250" y="225" font-family="Segoe UI, Arial" font-size="15" fill="#0f172a">${row.supplier || row.foreignLicense || "Supplier from PO"}</text>
      <text x="60" y="265" font-family="Segoe UI, Arial" font-size="15" font-weight="700" fill="#0f172a">Batch No</text>
      <text x="250" y="265" font-family="Segoe UI, Arial" font-size="15" fill="#0f172a">${row.batchNo || "-"}</text>
      <text x="60" y="305" font-family="Segoe UI, Arial" font-size="15" font-weight="700" fill="#0f172a">MFG Lot No</text>
      <text x="250" y="305" font-family="Segoe UI, Arial" font-size="15" fill="#0f172a">${getMfgLotNo(row) || "-"}</text>
      <text x="60" y="345" font-family="Segoe UI, Arial" font-size="15" font-weight="700" fill="#0f172a">Document Ref</text>
      <text x="250" y="345" font-family="Segoe UI, Arial" font-size="15" fill="#0f172a">${documentNo}</text>
      <rect x="60" y="385" width="640" height="58" rx="7" fill="#eef6fc" stroke="#cbd5e1"/>
      <text x="82" y="420" font-family="Segoe UI, Arial" font-size="15" font-weight="700" fill="#14532d">Viewed document preview for wireframe demonstration</text>
    </svg>`;
  const imgEl = document.querySelector("#image-viewer-img");
  imgEl.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
  document.querySelector("#image-viewer-title").textContent = `${title} - ${row.batchNo || row.orderNo || "Document"}`;
  document.querySelector("#image-viewer-modal").classList.remove("hidden");
}
function openMfgPopup() {
  const mfgBody = document.querySelector("#mfg-popup-body");
  mfgBody.innerHTML = batchCheckerMfgList.map((mfg, idx) => `
    <tr class="${idx === 0 ? "selected-mfg-row" : ""}">
      <td><input type="radio" name="mfg-select-radio" value="${idx}" ${idx === 0 ? "checked" : ""}></td>
      <td><strong>${mfg.name}</strong></td>
      <td>${mfg.address}</td>
    </tr>
  `).join("");
  document.querySelector("#mfg-popup-modal").classList.remove("hidden");
}

function openSplitBatchPopup(idx) {
  selectedBatchCheckerRowIndexForSplit = idx;
  const rows = getBatchCheckerRows();
  const row = rows[idx];
  const currentMfgLot = getMfgLotNo(row);
  document.querySelector("#split-batch-no").value = currentMfgLot === "-" ? "" : currentMfgLot;
  document.querySelector("#split-qty").value = row.qty;
  document.querySelector("#split-exp").value = row.expiryDate;
  document.querySelector("#split-batch-modal").classList.remove("hidden");
}

function openBatchCheckVerifyPopup() {
  const rows = getBatchCheckerRows();
  const row = rows[selectedBatchCheckerRowKey];
  if (!row) {
    statusMessage.textContent = "Select one product line before opening Batch Check.";
    return;
  }

  const items = getBatchCheckerVerificationItems(row);
  const checks = getBatchCheckerLineChecks(row);
  const modal = document.querySelector("#batch-check-verify-modal");
  const body = modal.querySelector(".confirm-body");
  const title = modal.querySelector("#batch-check-verify-title");
  if (title) title.textContent = "Batch Check - Product Verification";

  body.innerHTML = `
    <h3 style="margin-bottom: 8px;">Checklist</h3>
    <p style="font-size: 11px; margin-bottom: 12px; color: #555;">Confirm every product detail against the supplier documents and raw pack scans before generating the PCL.</p>
    <div class="batchcheck-verification-grid">
      ${items.map((item, index) => `
        <label class="batchcheck-verification-row">
          <input type="checkbox" data-batchcheck-field-check="${index}" ${checks[index] ? "checked" : ""}>
          <span class="batchcheck-verification-label">${item.label}</span>
          <strong class="batchcheck-verification-value">${item.value}</strong>
        </label>
      `).join("")}
    </div>
    <div class="confirm-actions" style="justify-content: center; margin-top: 14px;">
      <button class="classic-button primary" type="button" id="batch-check-confirm-btn" ${checks.every(Boolean) ? "" : "disabled"}>Verify</button>
      <button class="classic-button" type="button" data-close-batch-check-verify>Cancel</button>
    </div>
  `;

  modal.classList.remove("hidden");
}

function updatePclSubmissionAvailability() {
  const submitBtn = document.querySelector("#pcl-clearance-submit-btn");
  const lineClearanceChk = document.querySelector("#chk-line-clearance");
  if (!submitBtn || !lineClearanceChk) return;
  
  const lineClearanceChecked = lineClearanceChk.checked;
  const allPclChecked = Array.from(document.querySelectorAll(".pcl-checkbox")).every(chk => chk.checked);
  
  submitBtn.disabled = !(lineClearanceChecked && allPclChecked);
}

function openGeneratePclPopup() {
  const rows = getBatchCheckerRows();
  const row = rows[selectedBatchCheckerRowKey];
  if (!row) {
    statusMessage.textContent = "Select one Batch Checker line before generating PCL.";
    updateBatchCheckerAvailability();
    return;
  }
  
  const rowKey = getBatchCheckerRowKey(row);
  const isChecked = batchCheckerCheckedRows[rowKey] === true;
  const isVerifiedForPcl = batchCheckerVerifiedRows[rowKey] || row.status === "BatchCheck" || row.status === "Printer";
  if (!isChecked || !isVerifiedForPcl) {
    statusMessage.textContent = "Print PCL is available only after the selected line is checked and verified.";
    updateBatchCheckerAvailability();
    return;
  }
  const isVerified = batchCheckerVerifiedRows[rowKey];
  const mfg = batchCheckerMfgList.find(m => m.name === row.manufacturer);
  const mfgAddress = mfg ? mfg.address : (row.manufacturer ? row.manufacturer : "5th km Paiania - Markopoulo, Koropi Attiki, 194 00, Greece");

  const checkDetails = isVerified ? `${isVerified.checker}, ${isVerified.time || "15:45:00"}, ${isVerified.date}` : '';
  const totalPages = row.coldChain === "Yes" ? 2 : 1;

  let page2Html = "";
  if (row.coldChain === "Yes") {
    page2Html = `
  <!-- Page Break or Separator -->
  <div style="page-break-before: always; margin-top: 25px; border-top: 2px dashed #000; padding-top: 25px;"></div>
  
  <div class="pcl-sheet" style="font-family: Arial, sans-serif; font-size: 11px; color: #000; background: #fff; padding: 20px; border: 1px solid #000; line-height: 1.4; box-sizing: border-box; margin-top: 15px;">
    <!-- Header -->
    <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 15px;">
      <div style="display: flex; align-items: center; gap: 8px;">
<div style="position: relative; width: 40px; height: 40px;">
  <div style="position: absolute; width: 30px; height: 30px; border-radius: 50%; border: 3px solid #0f52ba; top: 0; left: 0; opacity: 0.85;"></div>
  <div style="position: absolute; width: 30px; height: 30px; border-radius: 50%; border: 3px solid #228b22; bottom: 0; right: 0; opacity: 0.85; display: flex; align-items: center; justify-content: center;">
    <strong style="color: #0f52ba; font-size: 12px; font-family: 'Times New Roman', serif;">B&S</strong>
  </div>
</div>
<div>
  <div style="font-size: 14px; font-weight: bold; color: #0b3c5d; letter-spacing: 0.5px; line-height: 1.1;">B&S HEALTHCARE</div>
  <div style="font-size: 8px; color: #666; letter-spacing: 1px;">PARALLEL IMPORT</div>
</div>
      </div>
      <div style="display: flex; gap: 1px; height: 30px; align-items: flex-end;">
<div style="width: 2px; height: 25px; background: #000;"></div>
<div style="width: 1px; height: 25px; background: #000;"></div>
<div style="width: 3px; height: 25px; background: #000;"></div>
<div style="width: 1px; height: 25px; background: #000;"></div>
<div style="width: 2px; height: 25px; background: #000;"></div>
<div style="width: 4px; height: 25px; background: #000;"></div>
<div style="width: 1px; height: 25px; background: #000;"></div>
<div style="width: 2px; height: 25px; background: #000;"></div>
<div style="width: 3px; height: 25px; background: #000;"></div>
      </div>
    </div>
  
    <div style="text-align: center; margin-bottom: 20px;">
      <h2 style="margin: 0; font-size: 15px; text-decoration: underline; font-weight: bold; letter-spacing: 1px; color: #111;">CHECKLIST CONTINUATION</h2>
    </div>
  
    <div style="margin-bottom: 15px; font-size: 11px;">
      <p>This continuation page contains temperature log verification for cold chain goods (+2C to +8C) during transit and receipt.</p>
      <div style="margin-bottom: 10px;">PO Number: <strong>${row.orderNo}</strong> | Batch No: <strong>${row.batchNo}</strong></div>
    </div>
  
    <!-- Temp logs table -->
    <table class="classic-table" style="width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 10px;">
      <thead>
<tr style="background: #f4f6f8;">
  <th style="border: 1px solid #000; padding: 4px;">Time/Date of Reading</th>
  <th style="border: 1px solid #000; padding: 4px;">Temp Recording Device ID</th>
  <th style="border: 1px solid #000; padding: 4px;">Minimum Temp (C)</th>
  <th style="border: 1px solid #000; padding: 4px;">Maximum Temp (C)</th>
  <th style="border: 1px solid #000; padding: 4px;">Satisfactory? (2C to 8C)</th>
  <th style="border: 1px solid #000; padding: 4px;">Verified By (Initial)</th>
</tr>
      </thead>
      <tbody>
<tr>
  <td style="border: 1px solid #000; padding: 4px; text-align: center;">${isVerified ? isVerified.date + ' ' + isVerified.time : ''}</td>
  <td style="border: 1px solid #000; padding: 4px; text-align: center;">LOG-9921</td>
  <td style="border: 1px solid #000; padding: 4px; text-align: center;">3.4 C</td>
  <td style="border: 1px solid #000; padding: 4px; text-align: center;">5.8 C</td>
  <td style="border: 1px solid #000; padding: 4px; text-align: center;">Yes <input type="checkbox" checked disabled> No <input type="checkbox" disabled></td>
  <td style="border: 1px solid #000; padding: 4px; text-align: center;">${isVerified ? isVerified.checker : 'batch.checker'}</td>
</tr>
<tr>
  <td style="border: 1px solid #000; padding: 4px; text-align: center;">&nbsp;</td>
  <td style="border: 1px solid #000; padding: 4px; text-align: center;">&nbsp;</td>
  <td style="border: 1px solid #000; padding: 4px; text-align: center;">&nbsp;</td>
  <td style="border: 1px solid #000; padding: 4px; text-align: center;">&nbsp;</td>
  <td style="border: 1px solid #000; padding: 4px; text-align: center;">Yes <input type="checkbox" disabled> No <input type="checkbox" disabled></td>
  <td style="border: 1px solid #000; padding: 4px; text-align: center;">&nbsp;</td>
</tr>
      </tbody>
    </table>
  
    <div style="border: 1px solid #000; padding: 10px; margin-bottom: 20px; font-weight: bold;">
      <div>Cold Chain Checklist:</div>
      <div style="font-weight: normal; margin-top: 8px;">
<label style="display: block; margin-bottom: 5px; cursor: pointer;"><input type="checkbox" class="pcl-checkbox" style="cursor: pointer;"> Transit Temp graph downloaded and checked</label>
<label style="display: block; margin-bottom: 5px; cursor: pointer;"><input type="checkbox" class="pcl-checkbox" style="cursor: pointer;"> No alarms or temperature excursions recorded</label>
<label style="display: block; cursor: pointer;"><input type="checkbox" class="pcl-checkbox" style="cursor: pointer;"> Quarantine status removed and cleared for batching</label>
      </div>
    </div>
  
    <!-- Footer -->
    <div style="display: flex; justify-content: space-between; font-size: 8px; color: #555; border-top: 1px solid #ccc; padding-top: 5px; font-family: Arial, sans-serif; line-height: 1.2; margin-top: 40px;">
      <div>
<div>Parent SOP SOP/PLPI/0002</div>
<div>Effective Date: 02Jan2025</div>
      </div>
      <div style="text-align: center; font-weight: bold;">Page 2 of 2</div>
      <div style="text-align: right;">
<div>Form Number F/PLPI/0002/002/v14</div>
<div>Review Date: 31Dec2026</div>
      </div>
    </div>
  </div>
    `;
  }

  document.querySelector("#pcl-sheet-container").innerHTML = `
<div class="pcl-sheet" style="font-family: Arial, sans-serif; font-size: 11px; color: #000; background: #fff; padding: 20px; border: 1px solid #000; line-height: 1.4; box-sizing: border-box;">
  
  <!-- Header: Logo on left, Barcode on right -->
  <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 15px;">
    <div style="display: flex; align-items: center; gap: 8px;">
      <div style="position: relative; width: 40px; height: 40px;">
<div style="position: absolute; width: 30px; height: 30px; border-radius: 50%; border: 3px solid #0f52ba; top: 0; left: 0; opacity: 0.85;"></div>
<div style="position: absolute; width: 30px; height: 30px; border-radius: 50%; border: 3px solid #228b22; bottom: 0; right: 0; opacity: 0.85; display: flex; align-items: center; justify-content: center;">
  <strong style="color: #0f52ba; font-size: 12px; font-family: 'Times New Roman', serif;">B&S</strong>
</div>
      </div>
      <div>
<div style="font-size: 14px; font-weight: bold; color: #0b3c5d; letter-spacing: 0.5px; line-height: 1.1;">B&S HEALTHCARE</div>
<div style="font-size: 8px; color: #666; letter-spacing: 1px;">PARALLEL IMPORT</div>
      </div>
    </div>
    <div style="display: flex; gap: 1px; height: 30px; align-items: flex-end;">
      <div style="width: 2px; height: 25px; background: #000;"></div>
      <div style="width: 1px; height: 25px; background: #000;"></div>
      <div style="width: 3px; height: 25px; background: #000;"></div>
      <div style="width: 1px; height: 25px; background: #000;"></div>
      <div style="width: 2px; height: 25px; background: #000;"></div>
      <div style="width: 4px; height: 25px; background: #000;"></div>
      <div style="width: 1px; height: 25px; background: #000;"></div>
      <div style="width: 2px; height: 25px; background: #000;"></div>
      <div style="width: 3px; height: 25px; background: #000;"></div>
    </div>
  </div>

  <div style="text-align: center; margin-bottom: 20px;">
    <h2 style="margin: 0; font-size: 15px; text-decoration: underline; font-weight: bold; letter-spacing: 1px; color: #111;">CHECKLIST</h2>
  </div>

  <!-- Initial Line Clearances -->
  <div style="margin-bottom: 15px; font-weight: bold; font-size: 11px;">
    <div style="margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center;">
      <span>Line clearance by PCL and Invoice issuer (Initial, time and Date):</span>
      <span style="border-bottom: 1px solid #000; width: 250px; text-align: center; font-weight: normal; font-size: 10px; height: 14px;">${checkDetails}</span>
    </div>
    <div style="display: flex; justify-content: space-between; align-items: center;">
      <span>Line clearance verification before batch checking (Initial, time and Date):</span>
      <span style="border-bottom: 1px solid #000; width: 250px; text-align: center; font-weight: normal; font-size: 10px; height: 14px;">${checkDetails}</span>
    </div>
  </div>

  <!-- Fields with square check boxes on right -->
  <div style="display: flex; justify-content: space-between; margin-bottom: 12px; gap: 20px;">
    <div style="display: flex; align-items: center;">
      <span style="font-weight: bold;">Controlled Drug Product:</span>
      <span style="width: 30px; height: 18px; border: 1px solid #000; margin-left: 10px; display: inline-flex; align-items: center; justify-content: center; font-weight: bold;">
${row.controlDr === 'Yes' ? 'X' : ''}
      </span>
    </div>
    <div style="display: flex; align-items: center;">
      <span style="font-weight: bold;">Cold Chain Product:</span>
      <span style="width: 30px; height: 18px; border: 1px solid #000; margin-left: 10px; display: inline-flex; align-items: center; justify-content: center; font-weight: bold;">
${row.coldChain === 'Yes' ? 'X' : ''}
      </span>
    </div>
  </div>

  <div class="pcl-row" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; border-bottom: 1px dotted #ccc; padding-bottom: 4px;">
    <span class="pcl-label" style="font-weight: bold; width: 140px; flex-shrink: 0;">PO No:</span>
    <span class="pcl-value" style="flex-grow: 1; border-bottom: 1px solid #000; padding-left: 8px; height: 16px;">${row.orderNo || ''}</span>
    <input type="checkbox" class="pcl-checkbox" style="width: 16px; height: 16px; margin-left: 15px; flex-shrink: 0; cursor: pointer;">
  </div>

  <div class="pcl-row" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; border-bottom: 1px dotted #ccc; padding-bottom: 4px;">
    <span class="pcl-label" style="font-weight: bold; width: 140px; flex-shrink: 0;">Supplier Name:</span>
    <span class="pcl-value" style="flex-grow: 1; border-bottom: 1px solid #000; padding-left: 8px; height: 16px;">${row.supplier || row.foreignLicense || 'Supplier from PO'}</span>
    <input type="checkbox" class="pcl-checkbox" style="width: 16px; height: 16px; margin-left: 15px; flex-shrink: 0; cursor: pointer;">
  </div>
  <div class="pcl-row" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; border-bottom: 1px dotted #ccc; padding-bottom: 4px;">
    <span class="pcl-label" style="font-weight: bold; width: 140px; flex-shrink: 0;">Contract Supplier:</span>
    <span class="pcl-value" style="flex-grow: 1; border-bottom: 1px solid #000; padding-left: 8px; height: 16px;">${row.supplier} / ${row.contract || 'WHO'}</span>
    <input type="checkbox" class="pcl-checkbox" style="width: 16px; height: 16px; margin-left: 15px; flex-shrink: 0; cursor: pointer;">
  </div>

  <div class="pcl-row" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; border-bottom: 1px dotted #ccc; padding-bottom: 4px;">
    <span class="pcl-label" style="font-weight: bold; width: 140px; flex-shrink: 0;">Product Name:</span>
    <span class="pcl-value" style="flex-grow: 1; border-bottom: 1px solid #000; padding-left: 8px; height: 16px;">${row.product || row.description}</span>
    <input type="checkbox" class="pcl-checkbox" style="width: 16px; height: 16px; margin-left: 15px; flex-shrink: 0; cursor: pointer;">
  </div>

  <div class="pcl-row" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; border-bottom: 1px dotted #ccc; padding-bottom: 4px;">
    <span class="pcl-label" style="font-weight: bold; width: 140px; flex-shrink: 0;">Strength & Pack Size:</span>
    <span class="pcl-value" style="flex-grow: 1; border-bottom: 1px solid #000; padding-left: 8px; height: 16px;">${row.strength} & ${row.packSize}</span>
    <input type="checkbox" class="pcl-checkbox" style="width: 16px; height: 16px; margin-left: 15px; flex-shrink: 0; cursor: pointer;">
  </div>

  <div class="pcl-row" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; border-bottom: 1px dotted #ccc; padding-bottom: 4px;">
    <span class="pcl-label" style="font-weight: bold; width: 140px; flex-shrink: 0;">ECMA:</span>
    <span class="pcl-value" style="flex-grow: 1; border-bottom: 1px solid #000; padding-left: 8px; height: 16px;">${row.ecma}</span>
    <input type="checkbox" class="pcl-checkbox" style="width: 16px; height: 16px; margin-left: 15px; flex-shrink: 0; cursor: pointer;">
  </div>

  <div style="display: flex; align-items: center; margin-bottom: 8px; gap: 10px;">
    <span style="font-weight: bold; width: 100px; flex-shrink: 0;">Source Country:</span>
    <span style="border-bottom: 1px solid #000; width: 100px; padding-left: 8px; height: 16px;">${row.country}</span>
    <input type="checkbox" class="pcl-checkbox" style="width: 16px; height: 16px; cursor: pointer; flex-shrink: 0;">
    
    <span style="font-weight: bold; margin-left: 10px; flex-shrink: 0;">Country of origin (if different from Source Country):</span>
    <span style="border-bottom: 1px solid #000; flex-grow: 1; padding-left: 8px; height: 16px; text-align: center;">${row.originCountry}</span>
    <input type="checkbox" class="pcl-checkbox" style="width: 16px; height: 16px; cursor: pointer; flex-shrink: 0;">
  </div>

  <div class="pcl-row" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; border-bottom: 1px dotted #ccc; padding-bottom: 4px;">
    <span class="pcl-label" style="font-weight: bold; width: 140px; flex-shrink: 0;">Invoice No:</span>
    <span class="pcl-value" style="flex-grow: 1; border-bottom: 1px solid #000; padding-left: 8px; height: 16px;">${row.invoice}</span>
    <input type="checkbox" class="pcl-checkbox" style="width: 16px; height: 16px; margin-left: 15px; flex-shrink: 0; cursor: pointer;">
  </div>

  <div style="display: flex; align-items: center; margin-bottom: 8px; gap: 10px;">
    <span style="font-weight: bold; width: 170px; flex-shrink: 0;">Raw Product scans checked:</span>
    <span>Yes</span>
    <input type="checkbox" class="pcl-checkbox" style="width: 16px; height: 16px; cursor: pointer; flex-shrink: 0;">
    <span>No</span>
    <input type="checkbox" style="width: 16px; height: 16px; cursor: pointer; flex-shrink: 0;">
    
    <span style="font-weight: bold; margin-left: auto; flex-shrink: 0;">Expiry:</span>
    <span style="border-bottom: 1px solid #000; width: 100px; padding-left: 8px; height: 16px; text-align: center;">${row.expiryDate}</span>
    <input type="checkbox" class="pcl-checkbox" style="width: 16px; height: 16px; cursor: pointer; flex-shrink: 0;">
  </div>

  <div class="pcl-row" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; border-bottom: 1px dotted #ccc; padding-bottom: 4px;">
    <span class="pcl-label" style="font-weight: bold; width: 140px; flex-shrink: 0;">Batch No:</span>
    <span class="pcl-value" style="flex-grow: 1; border-bottom: 1px solid #000; padding-left: 8px; height: 16px;">${row.batchNo}</span>
    <input type="checkbox" class="pcl-checkbox" style="width: 16px; height: 16px; margin-left: 15px; flex-shrink: 0; cursor: pointer;">
  </div>

  <div style="display: flex; align-items: center; margin-bottom: 8px; gap: 10px;">
    <span style="font-weight: bold; width: 110px; flex-shrink: 0;">Quantity Received:</span>
    <span style="border-bottom: 1px solid #000; width: 100px; padding-left: 8px; height: 16px;">${row.qty}</span>
    <input type="checkbox" class="pcl-checkbox" style="width: 16px; height: 16px; cursor: pointer; flex-shrink: 0;">
    
    <span style="font-weight: bold; margin-left: auto; flex-shrink: 0;">All packs are in good condition</span>
    <input type="checkbox" class="pcl-checkbox" style="width: 16px; height: 16px; cursor: pointer; flex-shrink: 0;">
  </div>

  <div style="display: flex; align-items: center; margin-bottom: 8px;">
    <span style="font-weight: bold; flex-shrink: 0;">Number of boxes in this batch:</span>
    <span style="border: 1px solid #000; width: 60px; height: 18px; margin-left: 15px; display: inline-flex; align-items: center; justify-content: center; font-weight: bold;">${row.boxes}</span>
  </div>

  <div class="pcl-row" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; border-bottom: 1px dotted #ccc; padding-bottom: 4px;">
    <span class="pcl-label" style="font-weight: bold; width: 140px; flex-shrink: 0;">Manufacturer:</span>
    <span class="pcl-value" style="flex-grow: 1; border-bottom: 1px solid #000; padding-left: 8px; height: 16px;">${row.manufacturer || '(Not Selected)'}</span>
    <input type="checkbox" class="pcl-checkbox" style="width: 16px; height: 16px; margin-left: 15px; flex-shrink: 0; cursor: pointer;">
  </div>

  <div class="pcl-row" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; border-bottom: 1px dotted #ccc; padding-bottom: 4px;">
    <span class="pcl-label" style="font-weight: bold; width: 140px; flex-shrink: 0;">Manufacturer Address:</span>
    <span class="pcl-value" style="flex-grow: 1; border-bottom: 1px solid #000; padding-left: 8px; height: 16px; font-size: 9px; line-height: 1.2; text-overflow: ellipsis; white-space: nowrap; overflow: hidden;" title="${mfgAddress}">${mfgAddress}</span>
    <input type="checkbox" class="pcl-checkbox" style="width: 16px; height: 16px; margin-left: 15px; flex-shrink: 0; cursor: pointer;">
  </div>

  <div class="pcl-row" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; border-bottom: 1px dotted #ccc; padding-bottom: 4px;">
    <span class="pcl-label" style="font-weight: bold; width: 140px; flex-shrink: 0;">Foreign ECMA Holder:</span>
    <span class="pcl-value" style="flex-grow: 1; border-bottom: 1px solid #000; padding-left: 8px; height: 16px;">${row.foreignLicense || 'Boehringer Ingelheim'}</span>
    <input type="checkbox" style="width: 16px; height: 16px; margin-left: 15px; flex-shrink: 0; cursor: pointer; visibility: hidden;">
  </div>

  <div class="pcl-row" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; border-bottom: 1px dotted #ccc; padding-bottom: 4px;">
    <span class="pcl-label" style="font-weight: bold; width: 140px; flex-shrink: 0;">Foreign leaflet Date:</span>
    <span class="pcl-value" style="flex-grow: 1; border-bottom: 1px solid #000; padding-left: 8px; height: 16px;">${row.foreignLeaflet || '04/2022'}</span>
    <input type="checkbox" class="pcl-checkbox" style="width: 16px; height: 16px; margin-left: 15px; flex-shrink: 0; cursor: pointer;">
  </div>
  <!-- Any Comments -->
  <div style="margin-top: 15px; margin-bottom: 15px;">
    <div style="font-weight: bold; text-decoration: underline; margin-bottom: 5px;">Any Comments:</div>
    <div style="border: 1px solid #000; min-height: 40px; padding: 8px; background: #fafafa; font-family: monospace;">
      ${row.comments || 'Satisfactory. All checks match specifications.'}
    </div>
  </div>

  <!-- Checks carried out by -->
  <div style="font-weight: bold; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #000; padding-bottom: 5px; margin-bottom: 15px; font-size: 11px;">
    <span>Checks carried out by: <span style="font-weight: normal; border-bottom: 1px solid #000; padding: 0 10px;">${isVerified ? isVerified.checker : 'batch.checker'}</span></span>
    <span>and found satisfactory on: <span style="font-weight: normal; border-bottom: 1px solid #000; padding: 0 10px;">${isVerified ? isVerified.date : ''}</span></span>
  </div>

  <!-- Footer -->
  <div style="display: flex; justify-content: space-between; font-size: 8px; color: #555; border-top: 1px solid #ccc; padding-top: 5px; font-family: Arial, sans-serif; line-height: 1.2;">
    <div>
      <div>Parent SOP SOP/PLPI/0002</div>
      <div>Effective Date: 02Jan2025</div>
    </div>
    <div style="text-align: center; font-weight: bold;">Page 1 of ${totalPages}</div>
    <div style="text-align: right;">
      <div>Form Number F/PLPI/0002/002/v14</div>
      <div>Review Date: 31Dec2026</div>
    </div>
  </div>
</div>

${page2Html}
  `;

  const savedChecks = getBatchCheckerLineChecks(row);
  document.querySelectorAll("#pcl-sheet-container .pcl-checkbox").forEach((checkbox, index) => {
    checkbox.checked = Boolean(savedChecks[index] ?? true);
    checkbox.disabled = true;
  });
  const lineClearance = document.querySelector("#chk-line-clearance");
  if (lineClearance) lineClearance.checked = true;
  const submitBtn = document.querySelector("#pcl-clearance-submit-btn");
  if (submitBtn) submitBtn.disabled = false;
  
  document.querySelector("#generate-pcl-modal").classList.remove("hidden");
}

function markRpDocumentAsViewed(poNo, docId) {
  if (!poNo) return;
  const po = rpPackWorkflows[poNo];
  if (!po) return;
  if (!po.viewedDocs) {
    po.viewedDocs = {};
  }
  po.viewedDocs[docId] = true;
  
  renderStage("rp-pack");
  updateRpApprovalAvailability();
}

function areAllRpDocumentsViewed(poNo) {
  const po = rpPackWorkflows[poNo];
  if (!po) return false;
  if (!po.viewedDocs) {
    po.viewedDocs = {};
  }
  
  // The 7 uploaded documents
  const allUploadedIds = po.documents.map(d => d.id);
  const uploadedViewed = allUploadedIds.every(id => {
    const doc = po.documents.find(d => d.id === id);
    if (!doc || !doc.uploaded) return true;
    return po.viewedDocs[id] === true;
  });
  
  // The generated packing list
  const packingListGen = packingListGenerated;
  const packingListViewed = !packingListGen || po.viewedDocs["generated-packing-list"] === true;
  
  return uploadedViewed && packingListViewed;
}

function renderChangeOfPackSizeForm(batchNumber, isReadOnly, stage, isQcSignOnly = false) {
  const product = bnsProducts.find(p => p.batch === batchNumber);
  if (!product) return "";
  
  if (!changeOfPackSizeData[batchNumber]) {
    changeOfPackSizeData[batchNumber] = {
      receivedAs: {
ecma: product.ecma || "",
packSize: "120 actuations",
blisterPerPack: "10",
qty: product.quantity || "",
totalBlisters: (parseInt(product.quantity) || 0) * 10,
initials: ""
      },
      assembledAs: {
ecma: product.ecma || "",
packSize: product.packSize || "",
blisterPerPack: "10",
finishedQty: product.quantity || "",
surplus: "0",
initials: ""
      },
      printerAmendmentsInitials: "",
      qcAmendmentsInitials: ""
    };
  }
  
  const data = changeOfPackSizeData[batchNumber];
  const disableInputs = isReadOnly ? "disabled" : "";
  const record = cartonPrintRecords[batchNumber] || {};
  
  return `
    <div class="change-of-pack-size-container" style="background: #ffffff; border: 1px solid #000; padding: 15px; margin: 15px 0; font-family: Arial, sans-serif; font-size: 11px; color: #000; line-height: 1.4; text-align: left; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);">
      <!-- Header -->
      <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px; border-bottom: 2px solid #000080; padding-bottom: 8px;">
<div>
  <div style="font-size: 15px; font-weight: bold; color: #000080;">B&S Healthcare</div>
  <div style="font-size: 12px; font-weight: bold; color: #000080; margin-top: 2px; text-transform: uppercase;">Change of Pack Size</div>
</div>
<div style="text-align: right; font-size: 9px; color: #555;">
  <div>Form Number: F/PLPI/0044/001/v7</div>
</div>
      </div>
      
      <!-- Top Details Table -->
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 11px; border: 1px solid #000;">
<tr>
  <td style="width: 25%; padding: 4px 6px; font-weight: bold; background: #f0f4f8; border-right: 1px solid #000; border-bottom: 1px solid #000;">PRODUCT NAME</td>
  <td style="padding: 4px 6px; border-bottom: 1px solid #000; border-right: 1px solid #000;">${product.product}</td>
  <td style="width: 25%; padding: 4px 6px; font-weight: bold; background: #f0f4f8; border-bottom: 1px solid #000; border-right: 1px solid #000;">INT. BATCH NUMBER</td>
  <td style="padding: 4px 6px; border-bottom: 1px solid #000; font-weight: bold;">${product.batch}</td>
</tr>
<tr>
  <td style="padding: 4px 6px; font-weight: bold; background: #f0f4f8; border-right: 1px solid #000;">STRENGTH</td>
  <td style="padding: 4px 6px;" colspan="3">${product.strength}</td>
</tr>
      </table>

      <!-- RECEIVED AS Section -->
      <div style="background: #000080; color: white; padding: 4px 6px; font-weight: bold; font-size: 11px; text-align: center; text-transform: uppercase;">RECEIVED AS</div>
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 11px; border: 1px solid #000;">
<thead>
  <tr style="background: #f0f4f8; border-bottom: 1px solid #000; font-weight: bold; text-align: center;">
    <td style="padding: 4px; border-right: 1px solid #000; width: 20%;">ECMA</td>
    <td style="padding: 4px; border-right: 1px solid #000; width: 16%;">PACK SIZE</td>
    <td style="padding: 4px; border-right: 1px solid #000; width: 16%;">NO. OF BLISTER/PACK</td>
    <td style="padding: 4px; border-right: 1px solid #000; width: 12%;">QTY</td>
    <td style="padding: 4px; border-right: 1px solid #000; width: 16%;">TOTAL BLISTERS</td>
    <td style="padding: 4px; width: 20%;">INITIAL AND DATE</td>
  </tr>
</thead>
<tbody>
  <tr style="text-align: center;">
    <td style="padding: 4px; border-right: 1px solid #000;"><input type="text" data-ps-batch="${batchNumber}" data-ps-section="receivedAs" data-ps-field="ecma" value="${data.receivedAs.ecma}" style="width: 95%; text-align: center; border: 1px solid #ccc; font-size: 10px; padding: 2px;" ${disableInputs}></td>
    <td style="padding: 4px; border-right: 1px solid #000;"><input type="text" data-ps-batch="${batchNumber}" data-ps-section="receivedAs" data-ps-field="packSize" value="${data.receivedAs.packSize}" style="width: 95%; text-align: center; border: 1px solid #ccc; font-size: 10px; padding: 2px;" ${disableInputs}></td>
    <td style="padding: 4px; border-right: 1px solid #000;"><input type="number" data-ps-batch="${batchNumber}" data-ps-section="receivedAs" data-ps-field="blisterPerPack" value="${data.receivedAs.blisterPerPack}" style="width: 95%; text-align: center; border: 1px solid #ccc; font-size: 10px; padding: 2px;" ${disableInputs}></td>
    <td style="padding: 4px; border-right: 1px solid #000;"><input type="number" data-ps-batch="${batchNumber}" data-ps-section="receivedAs" data-ps-field="qty" value="${data.receivedAs.qty}" style="width: 95%; text-align: center; border: 1px solid #ccc; font-size: 10px; padding: 2px;" ${disableInputs}></td>
    <td style="padding: 4px; border-right: 1px solid #000;"><input type="number" data-ps-batch="${batchNumber}" data-ps-section="receivedAs" data-ps-field="totalBlisters" value="${data.receivedAs.totalBlisters}" style="width: 95%; text-align: center; border: 1px solid #ccc; font-size: 10px; padding: 2px;" ${disableInputs}></td>
    <td style="padding: 4px; font-size: 9px; vertical-align: middle;">
      ${data.receivedAs.initials ? `
<div style="color: #0d9488; font-weight: bold; line-height: 1.1;">
  Signed ${data.receivedAs.initials}
  ${!isReadOnly ? `<button type="button" class="classic-button" data-ps-clear-sig="receivedAs" data-ps-batch="${batchNumber}" style="background: #ef4444; color: #fff; border: none; font-size: 8px; padding: 1px 3px; cursor: pointer; margin-top: 2px; border-radius: 2px; line-height: 1;">Clear</button>` : ""}
</div>
      ` : `
<button type="button" class="classic-button primary" data-ps-sign="receivedAs" data-ps-batch="${batchNumber}" ${disableInputs} style="font-size: 9px; padding: 2px 4px; height: auto; line-height: 1;">Sign</button>
      `}
    </td>
  </tr>
</tbody>
      </table>

      <!-- ASSEMBLED AS Section -->
      <div style="background: #000080; color: white; padding: 4px 6px; font-weight: bold; font-size: 11px; text-align: center; text-transform: uppercase;">ASSEMBLED AS</div>
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 11px; border: 1px solid #000;">
<thead>
  <tr style="background: #f0f4f8; border-bottom: 1px solid #000; font-weight: bold; text-align: center;">
    <td style="padding: 4px; border-right: 1px solid #000; width: 20%;">ECMA</td>
    <td style="padding: 4px; border-right: 1px solid #000; width: 16%;">PACK SIZE</td>
    <td style="padding: 4px; border-right: 1px solid #000; width: 16%;">NO. OF BLISTER/PACK</td>
    <td style="padding: 4px; border-right: 1px solid #000; width: 12%;">FINISHED QTY</td>
    <td style="padding: 4px; border-right: 1px solid #000; width: 16%;">SURPLUS BLISTER (IF ANY)</td>
    <td style="padding: 4px; width: 20%;">INITIAL AND DATE</td>
  </tr>
</thead>
<tbody>
  <tr style="text-align: center;">
    <td style="padding: 4px; border-right: 1px solid #000;"><input type="text" data-ps-batch="${batchNumber}" data-ps-section="assembledAs" data-ps-field="ecma" value="${data.assembledAs.ecma}" style="width: 95%; text-align: center; border: 1px solid #ccc; font-size: 10px; padding: 2px;" ${disableInputs}></td>
    <td style="padding: 4px; border-right: 1px solid #000;"><input type="text" data-ps-batch="${batchNumber}" data-ps-section="assembledAs" data-ps-field="packSize" value="${data.assembledAs.packSize}" style="width: 95%; text-align: center; border: 1px solid #ccc; font-size: 10px; padding: 2px;" ${disableInputs}></td>
    <td style="padding: 4px; border-right: 1px solid #000;"><input type="number" data-ps-batch="${batchNumber}" data-ps-section="assembledAs" data-ps-field="blisterPerPack" value="${data.assembledAs.blisterPerPack}" style="width: 95%; text-align: center; border: 1px solid #ccc; font-size: 10px; padding: 2px;" ${disableInputs}></td>
    <td style="padding: 4px; border-right: 1px solid #000;"><input type="number" data-ps-batch="${batchNumber}" data-ps-section="assembledAs" data-ps-field="finishedQty" value="${data.assembledAs.finishedQty}" style="width: 95%; text-align: center; border: 1px solid #ccc; font-size: 10px; padding: 2px;" ${disableInputs}></td>
    <td style="padding: 4px; border-right: 1px solid #000;"><input type="text" data-ps-batch="${batchNumber}" data-ps-section="assembledAs" data-ps-field="surplus" value="${data.assembledAs.surplus}" style="width: 95%; text-align: center; border: 1px solid #ccc; font-size: 10px; padding: 2px;" ${disableInputs}></td>
    <td style="padding: 4px; font-size: 9px; vertical-align: middle;">
      ${data.assembledAs.initials ? `
<div style="color: #0d9488; font-weight: bold; line-height: 1.1;">
  Signed ${data.assembledAs.initials}
  ${!isReadOnly ? `<button type="button" class="classic-button" data-ps-clear-sig="assembledAs" data-ps-batch="${batchNumber}" style="background: #ef4444; color: #fff; border: none; font-size: 8px; padding: 1px 3px; cursor: pointer; margin-top: 2px; border-radius: 2px; line-height: 1;">Clear</button>` : ""}
</div>
      ` : `
<button type="button" class="classic-button primary" data-ps-sign="assembledAs" data-ps-batch="${batchNumber}" ${disableInputs} style="font-size: 9px; padding: 2px 4px; height: auto; line-height: 1;">Sign</button>
      `}
    </td>
  </tr>
</tbody>
      </table>

      <!-- AMENDMENTS ON BAR Section -->
      <div style="background: #000080; color: white; padding: 4px 6px; font-weight: bold; font-size: 11px; text-align: center; text-transform: uppercase;">AMENDMENTS ON BAR</div>
      <table style="width: 100%; border-collapse: collapse; font-size: 11px; border: 1px solid #000;">
<thead>
  <tr style="background: #f0f4f8; border-bottom: 1px solid #000; font-weight: bold; text-align: center;">
    <td style="padding: 4px; border-right: 1px solid #000; width: 50%;">AMENDMENTS</td>
    <td style="padding: 4px; border-right: 1px solid #000; width: 25%;">PRINTER (INITIAL AND DATE)</td>
    <td style="padding: 4px; width: 25%;">PRE-ASSEMBLY QUALITY CHECKER (INITIAL AND DATE)</td>
  </tr>
</thead>
<tbody>
  <tr style="border-bottom: 1px solid #000;">
    <td style="padding: 6px 8px; border-right: 1px solid #000; text-align: left; font-weight: 500;">CHANGE MADE IN PACK QUANTITY IN PROCESS 1 and LAST PAGE</td>
    <td style="padding: 6px; border-right: 1px solid #000; text-align: center; font-size: 9px; vertical-align: middle;" rowspan="2">
      ${data.printerAmendmentsInitials ? `
<div style="color: #0d9488; font-weight: bold; line-height: 1.1;">
  Signed ${data.printerAmendmentsInitials}
  ${!isReadOnly ? `<button type="button" class="classic-button" data-ps-clear-sig="printerAmendments" data-ps-batch="${batchNumber}" style="background: #ef4444; color: #fff; border: none; font-size: 8px; padding: 1px 3px; cursor: pointer; margin-top: 2px; border-radius: 2px; line-height: 1;">Clear</button>` : ""}
</div>
      ` : `
<button type="button" class="classic-button primary" data-ps-sign="printerAmendments" data-ps-batch="${batchNumber}" ${disableInputs} style="font-size: 9px; padding: 2px 4px; height: auto; line-height: 1;">Sign</button>
      `}
    </td>
    <td style="padding: 6px; text-align: center; font-size: 9px; vertical-align: middle;" rowspan="2">
      ${data.qcAmendmentsInitials ? `
<div style="color: #0d9488; font-weight: bold; line-height: 1.1;">
  Signed ${data.qcAmendmentsInitials}
  ${isQcSignOnly && !isReadOnly ? `<button type="button" class="classic-button" data-ps-clear-sig="qcAmendments" data-ps-batch="${batchNumber}" style="background: #ef4444; color: #fff; border: none; font-size: 8px; padding: 1px 3px; cursor: pointer; margin-top: 2px; border-radius: 2px; line-height: 1;">Clear</button>` : ""}
</div>
      ` : `
<button type="button" class="classic-button primary" data-ps-sign="qcAmendments" data-ps-batch="${batchNumber}" ${!isQcSignOnly || isReadOnly ? "disabled" : ""} style="font-size: 9px; padding: 2px 4px; height: auto; line-height: 1;">Sign</button>
      `}
    </td>
  </tr>
  <tr>
    <td style="padding: 6px 8px; border-right: 1px solid #000; text-align: left; font-weight: 500;">CHANGES MADE FOR RECONCILIATION ON PROCESS 8</td>
  </tr>
</tbody>
      </table>

      <!-- SOP Footer -->
      <div style="display: flex; justify-content: space-between; font-size: 8px; color: #555; border-top: 1px solid #000; padding-top: 4px; margin-top: 12px; font-family: Arial, sans-serif; line-height: 1.2;">
<div>
  <div>Parent SOP: SOP/PLPI/0044</div>
  <div>Effective Date: 03Aug2024</div>
</div>
<div style="text-align: right;">
  <div>Form Number: F/PLPI/0044/001/v7</div>
  <div>Review Date: 02Aug2026</div>
</div>
      </div>
    </div>
  `;
}

function renderRpApprovalFormInteractive(activePoKey, isApprovedByRp, stage) {
  const details = getRpApprovalPrefilledDetails(activePoKey);
  const answers = rpApprovalAnswers[activePoKey] || {};
  const comments = rpApprovalComments[activePoKey] || "";
  
  const renderPillOptions = (field, hasNa = false) => {
    const val = answers[field];
    const disableAttr = isApprovedByRp ? "disabled" : "";
    return `
      <div class="modern-check-options">
        <button type="button" class="modern-pill-btn ${val === "Y" || val === true ? "active-yes" : ""}" data-rp-field="${field}" data-val="Y" ${disableAttr}>YES</button>
        <button type="button" class="modern-pill-btn ${val === "N" || val === false ? "active-no" : ""}" data-rp-field="${field}" data-val="N" ${disableAttr}>NO</button>
        ${hasNa ? `
          <button type="button" class="modern-pill-btn ${val === "NA" ? "active-na" : ""}" data-rp-field="${field}" data-val="NA" ${disableAttr}>N/A</button>
        ` : ""}
      </div>
    `;
  };

  return `
    <div style="padding: 15px; background: #f8fafc; border-radius: 8px; font-family: Tahoma, sans-serif;">
      <h3 class="rp-checklist-heading">Checklist</h3>
      
      <!-- Custom Details Check Card -->
      <div class="modern-checklist-section">
        <div class="modern-checklist-title">1. Custom Details Check</div>
        <div class="modern-check-card">
          <span class="modern-check-question">EORI Verification</span>
          ${renderPillOptions("eori")}
        </div>
        <div class="modern-check-card">
          <span class="modern-check-question">Commodity Code Verification</span>
          ${renderPillOptions("commodity")}
        </div>
      </div>
      
      <!-- Supplier Compliance Check Card -->
      <div class="modern-checklist-section">
        <div class="modern-checklist-title">2. Supplier Compliance Check</div>
        <div class="modern-check-card" style="flex-direction: column; align-items: stretch; gap: 8px;">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <span class="modern-check-question">Supplier Status in FE</span>
            <div class="modern-check-options">
              <button type="button" class="modern-pill-btn ${answers["fe-status"] === "Y" ? "active-yes" : ""}" data-rp-field="fe-status" data-val="Y" ${isApprovedByRp ? "disabled" : ""}>Active</button>
              <button type="button" class="modern-pill-btn ${answers["fe-status"] === "N" ? "active-no" : ""}" data-rp-field="fe-status" data-val="N" ${isApprovedByRp ? "disabled" : ""}>Inactive</button>
            </div>
          </div>
          <div style="margin-top: 5px;">
            <label style="font-size: 11px; font-weight: bold; color: #475569; display: block; margin-bottom: 4px;">Give Reason if Inactive:</label>
            <input type="text" id="rp-form-inactive-reason" value="${answers["inactive-reason"] || ""}" style="width: 100%; border: 1px solid #cbd5e1; border-radius: 4px; padding: 6px; font-size: 11px;" ${answers["fe-status"] === "N" && !isApprovedByRp ? "" : "disabled"} placeholder="Enter inactivity reason if Inactive is selected...">
          </div>
        </div>
        <div class="modern-check-card">
          <span class="modern-check-question">Is the collection address matches with the WDA?</span>
          ${renderPillOptions("wda-match")}
        </div>
      </div>
      
      <!-- Temperature Compliance Card -->
      <div class="modern-checklist-section">
        <div class="modern-checklist-title">3. Temperature Compliance During Transit</div>
        <div class="modern-check-card">
          <span class="modern-check-question">Stock Transported by Authorised Transporter?</span>
          ${renderPillOptions("transporter")}
        </div>
        <div class="modern-check-card">
          <span class="modern-check-question">Temperature records in transit checked and within parameters</span>
          ${renderPillOptions("temp-transit")}
        </div>
        <div class="modern-check-card">
          <span class="modern-check-question">Temperature Records at Storage Site checked and within parameters</span>
          ${renderPillOptions("temp-storage", true)}
        </div>
      </div>
      
      <!-- Article 51 Compliance Card -->
      <div class="modern-checklist-section">
        <div class="modern-checklist-title">4. Compliance check in line with Article 51 of Directive 2001/83/EC</div>
        <div class="modern-check-card">
          <span class="modern-check-question">Supplier declaration that all Goods on delivery note comply with Article 51 of Directive 2001/83/EC and sourced from approved suppliers</span>
          ${renderPillOptions("art51-decl")}
        </div>
        <div class="modern-check-card">
          <span class="modern-check-question">Does the declaration contain compliance with FMD</span>
          ${renderPillOptions("fmd-compliance")}
        </div>
        <div class="modern-check-card">
          <span class="modern-check-question">Does the declaration states that all FMD applicable products has been Decommissioned in accordance with FMD 2011/62/EU</span>
          ${renderPillOptions("fmd-decom")}
        </div>
        <div class="modern-check-card">
          <span class="modern-check-question">Italian and Greek packs checked for presence of Bollino/Vignate stickers</span>
          ${renderPillOptions("bollino", true)}
        </div>
      </div>
      
      <!-- Conclusion Card -->
      <div class="modern-checklist-section">
        <div class="modern-checklist-title">5. Conclusion</div>
        <div style="padding: 10px 0;">
          <label style="font-size: 11px; font-weight: bold; color: #475569; display: block; margin-bottom: 4px;">RPi Comments:</label>
          <textarea id="rp-form-comments" style="width: 100%; height: 60px; border: 1px solid #cbd5e1; border-radius: 4px; padding: 6px; font-size: 11px;" ${isApprovedByRp ? "disabled" : ""} placeholder="Enter any RPi comments...">${comments}</textarea>
        </div>
        <div class="modern-check-card">
          <span class="modern-check-question">RPi Checks completed and stock is suitable for processing</span>
          ${renderPillOptions("stock-suitable")}
        </div>
        <div class="modern-check-card">
          <span class="modern-check-question">Any Deviation to be raised?</span>
          ${renderPillOptions("deviation")}
        </div>
      </div>
    </div>
  `;
}

function renderRpPackWork(stage) {
  if (Object.keys(rpPackWorkflows).length === 0) {
    rpPackWorkflows["C13719"] = {
      poNo: "C13719",
      status: "Pending Uploads",
      signoff: null,
      documents: [
        { id: "supplier-invoice", name: "Supplier invoice", required: true, uploaded: false, fileName: "", verified: false },
        { id: "po", name: "PO", required: true, uploaded: false, fileName: "", verified: false },
        { id: "supplier-packing-list", name: "Supplier packing list", required: true, uploaded: false, fileName: "", verified: false },
        { id: "supplier-declaration", name: "Supplier declaration", required: true, uploaded: false, fileName: "", verified: false },
        { id: "temperature-record", name: "Temperature record", required: true, uploaded: false, fileName: "", verified: false },
        { id: "goods-receiving-checklist", name: "Goods receiving checklist", required: true, uploaded: false, fileName: "", verified: false },
        { id: "delivery-details", name: "Delivery Details", required: true, uploaded: false, fileName: "", verified: false }
      ]
    };
  }
  
  const completedPoKeys = getRpTaskFilteredPoKeys();

  // REMOVED AUTO SELECTION - Keep selectedRpApprovalPo null unless selected explicitly!

  const poListHtml = completedPoKeys.length > 0
    ? completedPoKeys
        .map((poKey) => {
          const po = rpPackWorkflows[poKey];
          const isActive = poKey === selectedRpApprovalPo ? "active" : "";
          const statusStyle = po.status === "Rejected by RPi" ? "rejected" : "";
          
          const isSignedOffByGoodsIn = po.status === "Signed Off" || po.signoff !== null;
          const isApprovedByRp = rpApprovalSignoffs[poKey] !== undefined;
          const uploadedCount = po.documents.filter(d => d.uploaded).length;
          const totalCount = po.documents.length;
          
          let displayStatus = `Uploaded: ${uploadedCount}/${totalCount}`;
          let badgeClass = "pending-status";
          
          if (po.status === "Rejected by RPi") {
            displayStatus = "Rejected by RPi";
            badgeClass = "rejected-status";
          } else if (isApprovedByRp) {
            displayStatus = "Approved by RPi";
            badgeClass = "done-status";
          } else if (isSignedOffByGoodsIn) {
            displayStatus = "Ready for RPi Review";
            badgeClass = "active-status";
          }

          return `
            <button class="rp-po-card rp-task-po-card ${isActive} ${statusStyle}" type="button" data-rp-approval-select-po="${poKey}">
              <strong>${poKey}</strong>
              <span class="status ${badgeClass}">${displayStatus}</span>
              ${rpRejectionComments[poKey] ? `<small class="rp-reject-note">Rejected: ${rpRejectionComments[poKey]}</small>` : ""}
            </button>
          `;
        })
        .join("")
    : `<div style="padding: 10px; font-size: 11px; color: #666; font-style: italic;">No POs created yet.</div>`;

  const activePo = selectedRpApprovalPo ? rpPackWorkflows[selectedRpApprovalPo] : null;
  if (!activePo) {
    return `
      <div class="packing-list-panel rp-documents-panel rp-task-queue-panel">
        <div class="rp-documents-header">
          <div>
            <h3>RPi Task - Active PO Queue</h3>
            <p>Select a PO card to open the review dashboard.</p>
          </div>
        </div>
        <div class="rp-task-search-row"><label class="classic-search-label">Search : <input class="classic-search-input" data-rp-approval-search value="${rpApprovalSearch}" placeholder="PO, supplier, batch or status"></label><button class="classic-search-button" type="button" data-rp-approval-search-button>Search</button></div>
        <div class="rp-doc-po-grid rp-workflow-card-grid">${poListHtml}</div>
      </div>
    `;
  }
  let mainContentHtml = "";

  {
    const isApprovedByRp = rpApprovalSignoffs[selectedRpApprovalPo] !== undefined;
    const rpSignoff = rpApprovalSignoffs[selectedRpApprovalPo];

    const rpTaskViewedDocs = getRpTaskViewedDocs(activePo);
    const operationalDocIds = ["temperature-record", "goods-receiving-checklist", "delivery-details"];
    const docTilesHtml = activePo.documents
      .map((doc, index) => {
        const isUploaded = doc.uploaded || operationalDocIds.includes(doc.id);
        const isVerified = rpTaskViewedDocs[doc.id] === true;
        const fileLabel = doc.fileName || (doc.uploaded ? "Uploaded File" : "Available in PLPI workflow");
        
        let statusClass = "missing";
        let statusText = "No File";
        if (isUploaded) {
          statusClass = isVerified ? "verified" : "pending";
          statusText = isVerified ? "Viewed" : "Pending View";
        }

        return `
          <div class="rp-doc-tile" data-rp-view-file="${doc.id}" data-rp-po="${activePo.poNo}" style="cursor: pointer;">
            <span class="rp-tile-index">${String(index + 1).padStart(2, "0")}</span>
            <div class="rp-tile-header">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: #1e3a8a; margin-bottom: 4px; display: block;">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                <polyline points="14 2 14 8 20 8"></polyline>
              </svg>
              <div class="rp-tile-title">${doc.name}</div>
              <div class="rp-tile-subtitle">${isUploaded ? fileLabel : "No File Uploaded"}</div>
            </div>
            <div class="rp-tile-status">
              <span class="rp-tile-badge ${statusClass}">${statusText}</span>
            </div>
            <div class="rp-tile-action">
              ${isUploaded ? `
                <button class="classic-button link-button" type="button" style="font-size: 11px; padding: 4px 8px; width: 100%; pointer-events: none;">View File</button>
              ` : `
                <span class="disabled-text" style="font-size: 11px; text-align: center; width: 100%; display: block;">N/A</span>
              `}
            </div>
          </div>
        `;
      })
      .join("");

    const isPackingListVerified = rpTaskViewedDocs["generated-packing-list"] === true;
    let plStatusClass = packingListGenerated ? (isPackingListVerified ? "verified" : "pending") : "missing";
    let plStatusText = packingListGenerated ? (isPackingListVerified ? "Viewed" : "Pending View") : "Not Generated";

    const packingListTileHtml = `
      <div class="rp-doc-tile" data-pl-preview-generated-packing-list data-rp-view-generated-packing-list data-pl-preview-po="${activePo.poNo}" style="cursor: pointer; background-color: #fffbeb; border-color: #fcd34d;">
        <span class="rp-tile-index">08</span>
        <div class="rp-tile-header">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: #b45309; margin-bottom: 4px; display: block;">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
            <polyline points="14 2 14 8 20 8"></polyline>
          </svg>
          <div class="rp-tile-title" style="color: #92400e;">Generated PO Packing List</div>
          <div class="rp-tile-subtitle">Generated by PLPI</div>
        </div>
        <div class="rp-tile-status">
          <span class="rp-tile-badge ${plStatusClass}">${plStatusText}</span>
        </div>
        <div class="rp-tile-action">
          ${packingListGenerated ? `
            <button class="classic-button link-button" type="button" style="font-size: 11px; padding: 4px 8px; width: 100%; background-color: #d97706; color: white; pointer-events: none;">View File</button>
          ` : `
            <span class="disabled-text" style="font-size: 11px; color: #92400e; text-align: center; width: 100%; display: block; font-weight: bold;">N/A</span>
          `}
        </div>
      </div>
    `;

    const checksHtml = renderRpApprovalFormInteractive(activePo.poNo, isApprovedByRp, stage);
    const allRpDocumentsVerified = areAllRpDocumentsVerified(activePo.poNo);
    const checklistApprovedToOpen = activePo.rpChecklistOpen === true;

    if (allRpDocumentsVerified && checklistApprovedToOpen) {
      mainContentHtml = `
        <div class="rp-documents-main rp-checklist-full-window" style="display: flex; flex-direction: column; gap: 12px; font-family: Tahoma, sans-serif; min-height: 650px;">
          <div class="rp-documents-header" style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px;">
            <div>
              <h3 style="margin: 0; color: #1f3a5f; font-size: 20px; font-weight: bold;">RPi Approval Checklist - PO ${activePo.poNo}</h3>
              <p style="margin: 2px 0 0; font-size: 12px; color: #666;">All 8 documents have been viewed by RPi. Complete the checklist and generate the signed form.</p>
            </div>
            <span class="viewed-badge ${isApprovedByRp ? "viewed" : "pending"}">${isApprovedByRp ? "Approved" : "Pending RPi Sign-Off"}</span>
          </div>
          <div class="rp-task-checklist-scroll-panel" style="flex: 1; overflow-y: auto; border: 1px solid #cbd5e1; border-radius: 6px; background: #ffffff; padding: 8px; min-height: 540px;">
            ${checksHtml}
          </div>
          <div class="signature-grid rp-doc-signoff-row" style="background: #f8fafc; border: 1px solid #cbd5e1; padding: 10px; border-radius: 6px;">
            <label>Responsible Person <input value="${currentLogin ? currentLogin.user : stage.user}" readonly></label>
            <label>Date / Time <input value="${isApprovedByRp ? rpSignoff.dateTime : "Pending RPi approval"}" readonly></label>
            <div class="signoff-action process-signoff-action">
              <button class="classic-button primary" type="button" id="rp-verify-signoff-btn" ${isApprovedByRp ? "disabled" : ""}>Generate & Sign</button>
            </div>
          </div>
        </div>
      `;
    } else {
      mainContentHtml = `
        <div class="rp-documents-main" style="display: flex; flex-direction: column; gap: 12px; font-family: Tahoma, sans-serif;">
          <div class="rp-documents-header" style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px;">
            <div>
              <h3 style="margin: 0; color: #1f3a5f; font-size: 18px; font-weight: bold;">RPi Review Dashboard - PO ${activePo.poNo}</h3>
              <p style="margin: 2px 0 0; font-size: 12px; color: #666;">View each document as the RPi user before opening the approval decision.</p>
            </div>
            <span class="viewed-badge pending">Pending RPi Review</span>
          </div>
          <div style="background: #ffffff; border: 1px solid #cbd5e1; border-radius: 6px; padding: 12px;">
            <div style="font-weight: bold; font-size: 13px; color: #1f3a5f; margin-bottom: 8px; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px;">Supplier Compliance Documents</div>
            <div class="rp-doc-tiles-grid">
              ${docTilesHtml}
              ${packingListTileHtml}
            </div>
          </div>
          <div class="rp-checklist-placeholder" style="padding: 25px; text-align: center; border: 2px dashed #cbd5e1; border-radius: 8px; background: #fafafa; font-family: Tahoma, sans-serif;">
            ${allRpDocumentsVerified ? `<h4 style="margin: 0 0 10px; color: #334155; font-size: 14px; font-weight: bold;">All files viewed</h4><p style="margin: 0 0 12px; color: #64748b; font-size: 11px;">Approve to open the checklist, or reject with comments for RPi Pack correction.</p><div style="display:flex; justify-content:center; gap:10px;"><button class="classic-button primary" type="button" data-rp-approve-open-checklist="${activePo.poNo}">Approve</button><button class="classic-button danger" type="button" data-rp-reject-po="${activePo.poNo}">Reject</button></div>` : `<h4 style="margin: 0 0 6px; color: #334155; font-size: 14px; font-weight: bold;">Checklist Locked</h4><p style="margin: 0; color: #64748b; font-size: 11px;">View all 8 documents in RPi Task to unlock Approve / Reject.</p>`}
          </div>
        </div>
      `;
    }
  }

  return `
    <div class="packing-list-panel rp-documents-panel">
      <div class="rp-pack-layout">
        <aside class="rp-sidebar">
          <div class="panel-title">Active PO Workflows</div>
          <div class="rp-task-search-row"><label class="classic-search-label">Search : <input class="classic-search-input" data-rp-approval-search value="${rpApprovalSearch}" placeholder="PO, supplier, batch or status"></label><button class="classic-search-button" type="button" data-rp-approval-search-button>Search</button></div>
          <div class="rp-po-list">
            ${poListHtml}
          </div>
        </aside>
        <section class="rp-main-content">
          ${mainContentHtml}
        </section>
      </div>
    </div>
  `;
}

function updateRpApprovalAvailability() {
  const button = document.querySelector("#rp-verify-signoff-btn");
  if (!button) return;
  const activePoKey = selectedRpApprovalPo;
  const activePo = rpPackWorkflows[activePoKey];
  const isApprovedByRp = rpApprovalSignoffs[activePoKey] !== undefined;
  if (!activePo || isApprovedByRp) {
    button.disabled = true;
    return;
  }
  
  const answers = rpApprovalAnswers[activePoKey] || {};
  const fields = [
    "eori", "commodity", "fe-status", "wda-match", "transporter", 
    "temp-transit", "temp-storage", "art51-decl", "fmd-compliance", 
    "fmd-decom", "bollino", "stock-suitable", "deviation"
  ];
  
  const allAnswered = fields.every(field => answers[field] !== undefined);
  
  let reasonOk = true;
  if (answers["fe-status"] === "N") {
    reasonOk = answers["inactive-reason"] && answers["inactive-reason"].trim().length > 0;
  }
  
  const docsVerified = areAllRpDocumentsVerified(activePoKey);
  button.disabled = !(allAnswered && reasonOk && docsVerified);
  button.title = button.disabled ? "Complete all checklist answers and verify every document before sign off." : "Ready for RPi Approval Sign Off";
}

function getRpApprovalPrefilledDetails(poNo) {
  const rows = getPackingListRows().filter(r => r.orderNo === poNo);
  const firstRow = rows.length > 0 ? rows[0] : null;
  return {
    poNo: poNo,
    supplier: firstRow ? `${firstRow.suppName} / ${firstRow.country}` : "EUROSERV, S.A. / SPAIN",
    invoice: firstRow && (firstRow.invoice || firstRow.comments) ? (firstRow.invoice || firstRow.comments) : "77337"
  };
}

function openRpApprovalFormPopup() {
  const activePoKey = selectedRpApprovalPo;
  const activePo = rpPackWorkflows[activePoKey];
  if (!activePo) return;

  const container = document.querySelector("#rp-approval-sheet-container");
  if (!container) return;
  
  // Render the RPi checks form as read-only (true) matching the exact layout
  container.innerHTML = renderRpApprovalFormInteractive(activePoKey, true, activePo);
  
  // Open the modal
  document.querySelector("#rp-approval-form-modal").classList.remove("hidden");
  
  // Submit button in the modal should be enabled since questions are answered on the main screen
  const submitBtn = document.querySelector("#rp-approval-sheet-submit-btn");
  if (submitBtn) submitBtn.disabled = false;
}

function completeRpApprovalSignoff() {
  const now = getAssemblyAuditTimestamp();
  rpApprovalSignoffs[selectedRpApprovalPo] = {
    user: currentLogin ? currentLogin.user : "rp.user",
    dateTime: now
  };
  
  const po = rpPackWorkflows[selectedRpApprovalPo];
  if (po) {
    po.status = "RPi Approved";
  }
  
  statusMessage.textContent = `RPi Pack approved and signed off for PO ${selectedRpApprovalPo}.`;
  renderStage("rp-pack");
}

function openMockDocumentPreview(docId, poNo) {
  const po = rpPackWorkflows[poNo];
  const doc = po ? po.documents.find((d) => d.id === docId) : null;
  const docName = doc ? doc.name : "Document";
  const fileName = doc ? doc.fileName : "file.pdf";
  
  const previewTitle = document.getElementById("print-preview-title");
  const previewBody = document.getElementById("print-preview-body");
  
  if (previewTitle) previewTitle.textContent = `${docName} Review`;
  if (previewBody) {
    previewBody.innerHTML = `
      <div class="mock-document-review-view" style="padding: 20px; font-family: monospace; line-height: 1.6;">
<div style="border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;">
  <h2 style="margin: 0;">${docName}</h2>
  <span style="background: #e1f5fe; color: #0288d1; padding: 4px 8px; border-radius: 4px; font-size: 12px;">Verified File: ${fileName}</span>
</div>
<p><strong>PO Number:</strong> ${poNo}</p>
<p><strong>Uploaded By:</strong> goods.in</p>
<p><strong>System Integrity Status:</strong> Valid PDF Document / OCR Scan Match (100%)</p>
<div style="background: #f5f5f5; border: 1px solid #ddd; padding: 15px; border-radius: 4px; font-size: 13px; color: #444; margin-top: 20px;">
  --- BEGIN DIGITAL METADATA ---
  <br>SHA256: d5a4e321b6c08e928c0018fbc8a21fec881e3a6c2306c55ef9c801bc462bca9
  <br>Page count: 1
  <br>Content-Type: application/pdf
  <br>Parsed Fields: Invoice Date, Supplier Address, Line Qty Matches PO.
  <br>--- END DIGITAL METADATA ---
</div>
      </div>
    `;
  }
  printPreviewModal.classList.remove("hidden");
}

function markGeneratedPackingListViewedForCurrentContext(poNo) {
  if (!poNo) return;
  const workflow = rpPackWorkflows[poNo];
  if (!workflow) return;
  workflow.viewedDocs = workflow.viewedDocs || {};
  workflow.viewedDocs["generated-packing-list"] = true;
  if (currentStageId === "rp-pack") {
    getRpTaskViewedDocs(workflow)["generated-packing-list"] = true;
  }
  if (currentStageId === "packing-list" && packingListMode === "documents") {
    workflow.viewedDocs["generated-packing-list"] = true;
  }
}
function openPackingListPreview(poNoOverride = null, rowsOverride = null) {
  const poNo = poNoOverride || selectedRpPackPo || selectedRpApprovalPo || packingListSelectedPo || packingListSearch || "C13719";
  activePreviewPo = poNo;
  const existingSnapshot = getGeneratedPackingRows(poNo);
  const hasRowsOverride = Array.isArray(rowsOverride) && rowsOverride.length > 0;
  const rows = hasRowsOverride ? rowsOverride : existingSnapshot || getFilteredPackingListRows().filter((row) => row.orderNo === poNo);
  const printedOn = new Date().toLocaleString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  });
  packingListGenerated = true;
  if (rows.length && (hasRowsOverride || !generatedPackingListSnapshots[poNo])) {
    generatedPackingListSnapshots[poNo] = rows.map((row) => ({ ...row }));
  }
  if ((currentStageId === "rp-pack" || (currentStageId === "packing-list" && packingListMode === "documents")) && rpPackWorkflows[poNo]) {
    rpPackWorkflows[poNo].viewedDocs = rpPackWorkflows[poNo].viewedDocs || {};
    rpPackWorkflows[poNo].viewedDocs["generated-packing-list"] = true;
    if (currentStageId === "rp-pack") getRpTaskViewedDocs(rpPackWorkflows[poNo])["generated-packing-list"] = true;
  }

  const previewTitle = document.getElementById("print-preview-title");
  const previewBody = document.getElementById("print-preview-body");

  if (previewTitle) previewTitle.textContent = "Packing List";
  if (previewBody) {
    previewBody.innerHTML = `
      <div class="packing-list-preview">
<div class="packing-list-preview-header">
  <div class="preview-logo">B&amp;S GROUP</div>
  <h2>Packing List</h2>
</div>
<div class="packing-list-preview-meta">
  <span>PO No : ${poNo}</span>
  <span>Printed By : ${currentLogin ? currentLogin.user : "goods.in"}</span>
  <span>Printed On : ${printedOn}</span>
</div>
<table class="packing-list-preview-table">
  <thead>
    <tr>
      <th>Product name</th>
      <th>ECMA No</th>
      <th>Batch No</th>
      <th>Expiry Date</th>
      <th>Qty</th>
      <th>No of boxes</th>
      <th>Comments</th>
    </tr>
  </thead>
  <tbody>
    ${rows
      .map((row) => {
const isInactive = row.status === "Not Active";
return `
<tr class="${isInactive ? "inactive-row" : ""}">
  <td>
    <strong>${row.description}</strong>
    <div class="preview-row-checks">
      <label><input type="checkbox" disabled ${row.presenceOf2D ? "checked" : ""}> Presence of 2D</label>
    </div>
    <div class="preview-row-status">Status : ${row.status || "Active"}</div>
  </td>
  <td>${row.ecma || ""}</td>
  <td>${isInactive ? "/" : row.batchNo || "Pending"}</td>
  <td>${isInactive ? "/" : row.expiryDate || "Pending"}</td>
  <td>${isInactive ? "/" : row.qty}</td>
  <td>${isInactive ? "/" : row.boxes}</td>
  <td>${getPackingLineUserComment(row) || ""}</td>
</tr>
      `;
      })
      .join("")}
  </tbody>
</table>
<div class="packing-list-preview-comment-section"><strong>Comments:</strong> ${rows.map((row) => getPackingLineUserComment(row)).filter(Boolean).join("; ") || "No comments recorded."}</div>
<div class="packing-list-preview-footer">Page 1 of 1</div>
<div class="packing-list-preview-actions">
    ${(currentStageId === "rp-pack" || (currentStageId === "packing-list" && packingListMode === "documents")) ? `
      <button class="classic-button" type="button" id="pl-preview-download-btn" style="background-color: #2563eb; color: white;">Download</button>
    ` : `
      <button class="classic-button primary" type="button" data-sign-po-packing-list>User Sign Off</button>
    `}
</div>
      </div>
    `;
  }
  printPreviewModal.classList.remove("hidden");
  statusMessage.textContent = "Packing list generated and ready to view.";
}

function signPoPackingList() {
  const now = getAssemblyAuditTimestamp();
  const poNo = activePreviewPo || packingListSelectedPo || packingListSearch || "C13719";
  poPackingListSignoff = { user: currentLogin ? currentLogin.user : "goods.in", dateTime: now, poNo };

  if (!rpPackWorkflows[poNo]) {
    rpPackWorkflows[poNo] = createPackingWorkflow(poNo);
  }
  packingListSelectedPo = poNo;
  packingListSearch = poNo;
  selectedRpPackPo = null;
  packingListMode = "view";

  statusMessage.textContent = `PO Packing List signed off. PO ${poNo} workflow created in RPi Pack.`;
  closePrintPreview();
  renderStage("packing-list");
}

function printPackingLabel(lineKey) {
  const now = new Date().toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" });
  packingLabelPrintRecords[lineKey] = { user: currentLogin ? currentLogin.user : "goods.in", dateTime: now };
  statusMessage.textContent = `Packing label printed and signed off for ${lineKey}.`;
  renderStage("packing-list");
}

function updatePackingListAvailability() {
  const button = document.querySelector("#packing-complete-button");
  if (!button) return;
  button.disabled = packingListSignedOff;
}

function completePackingList() {
  const now = new Date().toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" });
  packingListSignedOff = true;
  packingListRecord = { user: currentLogin ? currentLogin.user : "goods.in", dateTime: now, poNo: packingListSelectedPo };
  statusMessage.textContent = `${packingListSelectedPo} Goods-In Packing List signed off and RPi Pack documents are available.`;
  renderStage("packing-list");
}
function renderBarCreationWork(stage) {
  if (!barCreated) {
    const productRows = getFilteredBnsProducts();
    return `
      <div class="bar-create-start">
<section class="bns-window" style="padding: 15px;">
  <div style="text-align: center; font-size: 16px; font-weight: bold; margin-bottom: 12px; font-family: Tahoma, sans-serif;">BNS Batch Creation</div>
  <div class="search-form minimal-search" style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px; flex-wrap: wrap;">
    <label class="classic-search-label" style="font-size: 11px;">Country : <select data-bns-filter="country" style="min-height: 22px; width: 100px;"><option value="All"></option><option>Spain</option></select></label>
    <label class="classic-search-label" style="font-size: 11px;">Site : <select data-bns-filter="site" style="min-height: 22px; width: 80px;"><option value="All"></option><option>WHO</option></select></label>
    <label class="classic-search-label" style="font-size: 11px;">Stock : <select style="min-height: 22px; width: 100px;"><option></option></select></label>
    <label class="classic-search-label" style="font-size: 11px;">Status : <select data-bns-filter="status" style="min-height: 22px; width: 100px;"><option value="Not Printed BAR"></option><option>Not Printed BAR</option><option>Printed BAR</option></select></label>
    <label class="classic-search-label" style="font-size: 11px;">Obj ID : <input class="classic-search-input" data-bns-filter="objId" value="${bnsFilters.objId}" style="min-height: 22px; width: 130px;"></label>
    <label class="classic-search-label" style="font-size: 11px;">MFG Lot No : <input class="classic-search-input" data-bns-filter="mfgLot" value="${bnsFilters.mfgLot}" style="min-height: 22px; width: 130px;"></label>
    <button class="classic-search-button" type="button" data-bns-search>Search</button>
  </div>
  <div class="grid-scroll">
    <table class="classic-table product-grid minimal-product-grid">
      <thead>
<tr>
  <th style="width: 50px;">Select</th>
  <th>PRODUCT_STATUS</th>
  <th>SITE</th>
  <th>COUNTRY</th>
  <th>PART_NO</th>
  <th>FOREIGN_NAME</th>
  <th>ECMA</th>
  <th>STRENGTH</th>
  <th>PACK_SIZE</th>
  <th>BATCH_NO</th>
  <th class="mfg-lot-col">MFG_LOT_NO</th>
   <th>EXPIRY_DATE</th>
  <th>QUANTITY</th>
  <th>IMP</th>
  <th>INVOICE_NO</th>
  <th>DESCRIPTION</th>
  <th>WAREHOUSE_LO</th>
</tr>
      </thead>
      <tbody>
${
  productRows.length
    ? productRows
.map(
  (product, index) => `
      <tr class="${index === 0 ? "selected-row " : ""}${bnsFilters.status === "Not Printed BAR" ? "clickable-row" : ""}" ${bnsFilters.status === "Not Printed BAR" ? `data-create-bar="${product.batch}"` : ""}>
<td style="text-align: center;"><input type="checkbox" ${index === 0 ? "checked" : ""}></td>
<td>${product.status}</td>
<td>${product.site}</td>
<td>${product.country}</td>
<td>${product.partNo}</td>
<td>${product.foreignName || ""}</td>
<td>${product.ecma}</td>
<td>${product.strength}</td>
<td>${product.packSize}</td>
<td>${product.batch}</td>
<td class="mfg-lot-col">${getMfgLotNo(product) || "-"}</td>
    <td>${product.expiry}</td>
<td>${product.quantity}</td>
<td>${product.imp}</td>
<td>${product.invoice}</td>
<td>${product.description}</td>
<td>${product.warehouse}</td>
      </tr>
    `
)
.join("")
    : `<tr><td colspan="17">No products available for BAR creation.</td></tr>`
}
      </tbody>
    </table>
  </div>
  <div class="bns-count-footer" style="display: flex; align-items: center; justify-content: space-between; margin-top: 15px; padding-top: 10px; border-top: 1px solid #c0c0c0; font-family: Tahoma, sans-serif; font-size: 11px;">
    <div>
      <button class="classic-button" type="button" style="min-width: 100px; font-weight: bold; font-size: 13px;">SAVE</button>
    </div>
    <div style="display: flex; gap: 15px; align-items: center; color: #000;">
      <span>Total BNS Batch : <strong style="background: #ffe3e3; padding: 2px 6px; border: 1px solid #ffc0c0; color: #b91c1c; font-size: 12px; border-radius: 2px;">189</strong></span>
      <span>Total Composite Batch : <strong style="background: #ffe3e3; padding: 2px 6px; border: 1px solid #ffc0c0; color: #b91c1c; font-size: 12px; border-radius: 2px;">361</strong></span>
      <span>Total Packs : <strong style="background: #ffe3e3; padding: 2px 6px; border: 1px solid #ffc0c0; color: #b91c1c; font-size: 12px; border-radius: 2px;">51247</strong></span>
      <button class="classic-button" type="button" style="background: #f0f4f8 !important; color: #333 !important; border-color: #b0c2d4 !important; padding: 3px 12px; font-size: 11px; font-weight: bold;">Not Printed BAR</button>
    </div>
    <div style="display: flex; gap: 8px;">
      <button class="classic-button" type="button">PRINT APPROVED CARTON</button>
      <button class="classic-button" type="button">PRINT PEEL OUT</button>
      <button class="classic-button" type="button">PRINT BRAILLE</button>
    </div>
  </div>
</section>
      </div>
    `;
  }

  const product = selectedProduct || bnsProducts[0];
  const createdBy = barCreatedRecord ? barCreatedRecord.user : currentLogin ? currentLogin.user : stage.user;
  const createdDateTime = barCreatedRecord ? barCreatedRecord.dateTime : "";

  return `
    <div class="bar-creation-layout process-only">
      <section class="process-one-form">
<div class="panel-title">BAR Created - Process 1</div>
${renderBatchDetails(product)}

<div class="process-checks">
  <div class="process-instruction">BAR Issuer checks</div>
  <label class="process-tick"><input type="checkbox" data-process-check> PCL has been checked for completeness and invoice is attached</label>
  <label class="process-tick"><input type="checkbox" data-process-check> Batch number and expiry date are correct</label>
  <label class="process-tick"><input type="checkbox" data-process-check> Product name, strength, pack size and ECMA are correct</label>
</div>

<div class="signature-grid">
  <label class="span-three">Comments <textarea id="process-comments" data-process-comment></textarea></label>
  <label>BAR Created By <input value="${createdBy}" readonly></label>
  <label>Created Date / Time <input value="${createdDateTime}" readonly></label>
  <div class="signoff-action process-signoff-action">
    <button class="classic-button primary" type="button" id="user-signoff-button" disabled>${signOffRecord ? "Signed Off" : "User Sign Off"}</button>
  </div>
</div>

${
  barMovedToNextStage && signOffRecord
    ? `<div class="workflow-note" id="bar-workflow-state">Signed off by <strong>${signOffRecord.user}</strong> at <strong>${signOffRecord.dateTime}</strong>. Batch <strong>${product.batch}</strong> moved to Printer - Label Printing list view.</div>`
    : `<div class="workflow-note hidden" id="bar-workflow-state"></div>`
}
      </section>
    </div>
  `;
}

function getLabelPrintingProducts() {
  return bnsProducts.filter(
    (product) => generatedBatchNumbers.includes(product.batch) && !labelPrintedBatchNumbers.includes(product.batch)
  );
}

function getLeafletPrintingProducts() {
  return bnsProducts.filter(
    (product) => labelPrintedBatchNumbers.includes(product.batch) && product.leafletRequired && !leafletPrintedBatchNumbers.includes(product.batch)
  );
}

function getCartonPrintingProducts() {
  return bnsProducts.filter(
    (product) => leafletPrintedBatchNumbers.includes(product.batch) && product.routeType === "Reboxing" && !cartonPrintedBatchNumbers.includes(product.batch)
  );
}

function getBraillePrintingProducts() {
  return bnsProducts.filter(
    (product) => leafletPrintedBatchNumbers.includes(product.batch) && product.routeType === "Relabelling" && product.brailleRequired && !braillePrintedBatchNumbers.includes(product.batch)
  );
}

function getLeafletFoldingProducts() {
  return bnsProducts.filter(
    (product) => leafletPrintedBatchNumbers.includes(product.batch) && !leafletFoldedBatchNumbers.includes(product.batch)
  );
}

function renderLeafletFoldingList() {
  const products = getLeafletFoldingProducts();
  return `
    <div class="label-printing-layout">
      <section class="bns-window">
<div class="sub-window-title">Leaflet Folding List</div>
<div class="grid-scroll label-grid-scroll">
  <table class="classic-table product-grid label-product-grid">
    <thead>
      <tr>
<th></th>
<th>B&S Batch Number</th>
<th class="mfg-lot-col">MFG Lot No</th>
<th>Product Name</th>
<th>Strength</th>
<th>Pack Size</th>
<th>ECMA</th>
<th>Expiry Date</th>
<th>Leaflet Qty</th>
<th>Status</th>
      </tr>
    </thead>
    <tbody>
      ${
products.length
  ? products
      .map(
(product, index) => `
  <tr class="${index === 0 ? "selected-row " : ""}clickable-row" data-open-leaflet-folding="${product.batch}">
    <td>${index === 0 ? ">" : ""}</td>
    <td>${product.batch}</td>
    <td class="mfg-lot-col">${getMfgLotNo(product) || "-"}</td>
    <td>${product.product}</td>
    <td>${product.strength}</td>
    <td>${product.packSize}</td>
    <td>${product.ecma}</td>
    <td>${product.expiry}</td>
    <td>${product.leafletQuantity}</td>
    <td>Ready for folding</td>
  </tr>
`
      )
      .join("")
  : `<tr><td colspan="10">No batches available for Leaflet Folding.</td></tr>`
      }
    </tbody>
  </table>
</div>
      </section>
    </div>
  `;
}

function renderLeafletFoldingWork(stage) {
  if (!leafletFoldingSelectedProduct) return renderLeafletFoldingList();
  const product = leafletFoldingSelectedProduct;
  const record = leafletFoldingRecords[product.batch] || {};
  return `
    <div class="bar-creation-layout process-only">
      <section class="process-one-form">
<div class="panel-title">Leaflet Folding - Process 5</div>
${renderBatchDetails(product)}

<div class="folding-summary-grid">
  <label>Leaflet Reference <input value="${product.ecma}" readonly></label>
  <label>Leaflet Size <input value="${product.packSize} leaflet" readonly></label>
  <label>Leaflet Quantity <input id="leaflet-folding-quantity" data-folding-quantity type="number" min="1" value="${record.quantity || product.leafletQuantity}"></label>
</div>

<div class="line-clearance-box">
  <div class="process-instruction">Count Confirmation</div>
  <label class="process-tick line-clearance-tick"><input type="checkbox" id="leaflet-folding-line-clearance" data-folding-line-clearance> Confirm the count</label>
</div>

<div class="signature-grid">
  <label>Folded By <input value="${currentLogin ? currentLogin.user : stage.user}" readonly></label>
  <label>Date / Time <input value="${record.dateTime || "Pending sign off"}" readonly></label>
  <div class="signoff-action process-signoff-action">
    <button class="classic-button primary" type="button" id="leaflet-folding-complete-button" disabled>User Sign Off</button>
  </div>
</div>
      </section>
    </div>
  `;
}

function getPreAssemblyProducts() {
  const completedProducts = bnsProducts.filter((product) => leafletFoldedBatchNumbers.includes(product.batch));
  const sourceProducts = completedProducts.length ? completedProducts : [bnsProducts[0]];
  return sourceProducts.filter(
    (product) =>
      !preAssemblyCheckedBatchNumbers.includes(product.batch) &&
      matchesBatchOrMfgLot(product, preAssemblySearch)
  );
}

function renderPreAssemblyList() {
  const products = getPreAssemblyProducts();
  const totalQuantity = products.reduce((total, product) => total + Number(product.quantity || 0), 0);
  return `
    <div class="double-check-layout" style="padding: 15px; font-family: Tahoma, sans-serif;">
      <section class="double-check-window">
<div style="text-align: center; font-size: 16px; font-weight: bold; margin-bottom: 12px;">Pre Assembly</div>

<div class="preassembly-batch-search-panel preassembly-clean-search" style="border: 1px solid #c0c0c0; padding: 8px 10px; background: #f9f9f9; display: flex; align-items: center; gap: 12px; margin-bottom: 15px; width: 100%; box-sizing: border-box;">
  <label class="classic-search-label" style="font-size: 11px; display: inline-flex; align-items: center; gap: 6px; white-space: nowrap;">BNS Batch No : <input class="classic-search-input" data-preassembly-search style="width: 135px;" value="${preAssemblySearch}"></label>
  <button class="classic-search-button preassembly-search-button" style="min-width: 78px;" type="button" data-preassembly-search-button>Search</button>
</div>

<div class="grid-scroll label-grid-scroll">
  <table class="classic-table product-grid label-product-grid">
    <thead>
      <tr>
<th>BATCH_STATUS</th>
<th>BNS_BATCH_NO</th>
<th class="mfg-lot-col">MFG_LOT_NO</th>
<th>EXPIRY_DATE</th>
<th>DESCRIPTION</th>
<th>STRENGTH</th>
<th>PACK_SIZE</th>
<th>ECMA</th>
<th>PL_NO</th>
<th>QUANTITY</th>
<th>Assembled</th>
      </tr>
    </thead>
    <tbody>
      ${
products.length
  ? products
      .map(
(product, index) => `
  <tr class="${index === 0 ? "selected-row " : ""}clickable-row" data-open-preassembly="${product.batch}">
    <td>PRINTED</td>
    <td>${product.batch}</td>
    <td class="mfg-lot-col">${getMfgLotNo(product) || "-"}</td>
    <td>${product.expiry}</td>
    <td>${product.description}</td>
    <td>${product.strength}</td>
    <td>${product.packSize}</td>
    <td>${product.ecma}</td>
    <td>${product.pl}</td>
    <td>${product.quantity}</td>
    <td>No</td>
  </tr>
`
      )
      .join("")
  : `<tr><td colspan="11">No batches available for Pre Assembly.</td></tr>`
      }
    </tbody>
  </table>
</div>
<div style="display: flex; gap: 30px; margin-top: 10px; font-size: 11px; color: #000; font-family: Tahoma, sans-serif;">
  <span>Total Batches : <strong>${products.length}</strong></span>
  <span>Total Quantity : <strong>${totalQuantity}</strong></span>
</div>
      </section>
    </div>
  `;
}

function renderPreAssemblyRouteFields(product) {
  if (product.routeType === "Reboxing") {
    return `
      <div class="double-check-scan-panel">
<label>MARKS : <input value="${product.marks || "9"}"></label>
<label>Reason : <input data-preassembly-input placeholder="Enter reason"></label>
<label>Cartons Per Pack : <input value="${product.cartonsPerPack || "1"}" readonly></label>
      </div>
    `;
  }

  return `
    <div class="double-check-scan-panel">
            <label>Product Reference : <input value="${product.partNo}" readonly></label>
      <label>Leaflet Reference : <input value="${product.ecma}" readonly></label>
      <label>Braille Required : <input value="${product.brailleRequired ? "Yes" : "No"}" readonly></label>
    </div>
  `;
}

function getPreAssemblyMaterialRows(product) {
  if (product.routeType === "Reboxing") {
    return [
      { type: "Carton/Braille Label 1", reference: `FLU250-10/120/CZ (${product.ecma})` },
      { type: "Blister Label 1", reference: `FLU250-10/120/CZ/B1 (${product.partNo})` },
      { type: "Blister/Carton Label 2", reference: `FLU250-10/120/CZ/B2 (${product.pl})` },
      { type: "Leaflet 1", reference: `FLU250-10/120/CZ/LT (${product.leafletDate})` }
    ];
  }

  const rows = [
    { type: "Blister Label 1", reference: `${product.partNo}` },
    { type: "Obscure Label", reference: `${product.ecma}` },
    { type: "Leaflet 1", reference: `${product.leafletDate}` }
  ];
  if (product.brailleRequired) rows.push({ type: "Braille Label", reference: `${product.ecma}` });
  return rows;
}

function renderPreAssemblyWork(stage) {
  if (!preAssemblySelectedProduct) return renderPreAssemblyList();
  const product = preAssemblySelectedProduct;
  const record = preAssemblyRecords[product.batch] || {};
  const routeLabel = product.routeType === "Reboxing" ? "Carton information required" : "Product details verification";
  const materialRows = getPreAssemblyMaterialRows(product);
  return `
    <div class="bar-creation-layout process-only">
      <section class="process-one-form double-check-detail">
<div class="panel-title">Pre Assembly - Process 6</div>
${renderBatchDetails(product)}
<div class="route-banner">${routeLabel}</div>
${renderPreAssemblyRouteFields(product)}

<div class="preassembly-reference-list">
  <table class="classic-table preassembly-material-table">
    <thead>
      <tr>
<th>Type Of label</th>
<th>Reference code</th>
<th>Checked & Confirmed</th>
      </tr>
    </thead>
    <tbody>
      ${materialRows
.map(
  (row, index) => `
    <tr>
      <td>${row.type}</td>
      <td>${row.reference}</td>
      <td><input type="checkbox" data-preassembly-material="${index}"></td>
    </tr>
  `
)
.join("")}
    </tbody>
  </table>
  <div class="preassembly-count-grid">
    <label>No of specimen <input data-preassembly-input id="preassembly-specimen-count" type="number" min="0" value="${record.specimenCount || "2"}"></label>
    <label>No Of Leaflet Folds <input data-preassembly-input id="preassembly-leaflet-folds" type="number" min="0" value="${record.leafletFolds || "3"}"></label>
    <label>Tamper seal per pack <input data-preassembly-input id="preassembly-tamper-seal" type="number" min="0" value="${record.tamperSeal || "0"}"></label>
  </div>
  <ul class="preassembly-note-list">
    <li>Stamp a Dot on the inner flap of the specimen pack and initial the Dot</li>
    <li>Details in working copy of BAR are satisfactory and printed materials are correct</li>
  </ul>
  <label>Comments <textarea id="preassembly-comments" data-preassembly-input>${record.comments || ""}</textarea></label>
</div>


<div class="signature-grid preassembly-signoff-grid">
  <div class="preassembly-action-inline">
    <button class="classic-button compact-action" type="button" data-view-mockup="${product.batch}">Mockup</button>
    <button class="classic-button primary compact-action" type="button" id="preassembly-complete-button" disabled>User Sign Off</button>
  </div>
  <label>Checked By <input value="${currentLogin ? currentLogin.user : stage.user}" readonly></label>
  <label>Date / Time <input value="${record.dateTime || "Pending sign off"}" readonly></label>
</div>
      </section>
    </div>
  `;
}

function updatePreAssemblyAvailability() {
  const submitButton = document.querySelector("#preassembly-complete-button");
  if (!submitButton || !preAssemblySelectedProduct) return;
  const materials = [...document.querySelectorAll("[data-preassembly-material]")];
  const specimenCount = document.querySelector("#preassembly-specimen-count");
  const leafletFolds = document.querySelector("#preassembly-leaflet-folds");
  const tamperSeal = document.querySelector("#preassembly-tamper-seal");
  const materialsComplete = materials.length > 0 && materials.every((check) => check.checked);
  const countsEntered = [specimenCount, leafletFolds, tamperSeal].every((input) => input && input.value !== "");
  
  submitButton.disabled = !(materialsComplete && countsEntered);

  if (!materialsComplete) {
    statusMessage.textContent = "Confirm all received printed material rows.";
  } else if (!countsEntered) {
    statusMessage.textContent = "Enter specimen, leaflet fold, and tamper seal counts.";
  } else {
    statusMessage.textContent = "Process 6 Pre Assembly is ready for sign off.";
  }
}

function openMockupPreview(batchNumber) {
  const product = bnsProducts.find((item) => item.batch === batchNumber);
  if (!product) return;
  document.querySelector("#print-preview-title").textContent = "Mockup";
  printPreviewRequest = null;
  printPreviewBody.innerHTML = `
    <div class="mockup-viewer">
      <div class="mockup-toolbar">
<strong>${product.product}</strong>
<button class="classic-button" type="button" data-close-print-preview>Close</button>
      </div>
      <div class="mockup-image">
<div class="finished-product-mockup">
  <div class="finished-carton">
    <div class="carton-face carton-front">
      <span class="mockup-brand">${product.product}</span>
      <span class="mockup-strength">${product.strength}</span>
      <span>${product.packSize}</span>
      <span>PL ${product.pl}</span>
      <span>EXP ${product.expiry}</span>
    </div>
    <div class="carton-face carton-side">
      <span>${product.ecma}</span>
      <span>${product.batch}</span>
    </div>
  </div>
  <div class="sample-label-preview">
    <strong>Finished sample label position</strong>
    <span>${product.foreignName || product.product}</span>
    <span>B&S Batch Number ${product.batch}</span>
    <span>Leaflet and ${product.routeType === "Reboxing" ? "carton" : "braille"} reference checked</span>
  </div>
</div>
<div class="mockup-label-strip">
  <span>Expected finished presentation</span>
  <span>Use this mockup to prepare and compare the assembly reference sample.</span>
</div>
      </div>
    </div>
  `;
  printPreviewModal.classList.remove("hidden");
  statusMessage.textContent = `Mockup opened for ${product.batch}.`;
}

function completePreAssemblyCheck() {
  if (!preAssemblySelectedProduct) return;
  const batchNumber = preAssemblySelectedProduct.batch;
  const now = getAssemblyAuditTimestamp();
  preAssemblyRecords[batchNumber] = {
    user: currentLogin ? currentLogin.user : "preassembly.qc",
    dateTime: now,
    specimenCount: document.querySelector("#preassembly-specimen-count") ? document.querySelector("#preassembly-specimen-count").value : "",
    leafletFolds: document.querySelector("#preassembly-leaflet-folds") ? document.querySelector("#preassembly-leaflet-folds").value : "",
    tamperSeal: document.querySelector("#preassembly-tamper-seal") ? document.querySelector("#preassembly-tamper-seal").value : "",
    comments: document.querySelector("#preassembly-comments") ? document.querySelector("#preassembly-comments").value : "",
    mockupViewed: true
  };
  if (!preAssemblyCheckedBatchNumbers.includes(batchNumber)) {
    preAssemblyCheckedBatchNumbers.push(batchNumber);
  }
  statusMessage.textContent = `Batch ${batchNumber} moved to Production Control / Room Allocation after Pre Assembly.`;
  window.setTimeout(() => {
    preAssemblySelectedProduct = null;
    renderStage("pre-assembly-qc");
    statusMessage.textContent = `Batch ${batchNumber} removed from Pre Assembly list.`;
  }, 1200);
}

function getProductionProducts() {
  const completedProducts = bnsProducts.filter((product) => preAssemblyCheckedBatchNumbers.includes(product.batch));
  const sourceProducts = completedProducts.length ? completedProducts : [bnsProducts[0], bnsProducts[1]].filter(Boolean);
  return sourceProducts.filter(
    (product) =>
      !productionAllocatedBatchNumbers.includes(product.batch) &&
      matchesBatchOrMfgLot(product, productionSearch)
  );
}

function renderProductionControlList() {
  const products = getProductionProducts();
  const totalQuantity = products.reduce((total, product) => total + Number(product.quantity || 0), 0);
  const rowsHtml = products.map((product) => {
    const boxCount = Math.max(1, Math.ceil(Number(product.quantity || 0) / 100));
    return `
    <tr class="production-queue-row">
      <td><strong>${product.batch}</strong><span class="production-mfg-lot">${getMfgLotNo(product) || "MFG lot pending"}</span></td>
      <td>${product.description || product.product}</td>
      <td>${product.quantity}</td>
      <td>${boxCount}</td>
      <td><button class="classic-button primary production-action-button" type="button" data-open-production="${product.batch}">Open Checklist</button></td>
    </tr>
  `;
  }).join("");

  return `
    <div class="production-layout production-queue-layout">
      <section class="production-window production-queue-window">
        <div class="sub-window-title">Production Controller</div>
        <div class="production-queue-header">
          <div>
            <h3>Production Controller Queue</h3>
          </div>
          <div class="production-queue-summary"><span>Total Batches</span><strong>${products.length}</strong><span>Total Quantity</span><strong>${totalQuantity}</strong></div>
        </div>
        <div class="production-single-list-shell">
          <table class="classic-table production-table production-queue-table">
            <thead>
              <tr><th>BNS_BATCH_NO</th><th>DESCRIPTION</th><th>QUANTITY</th><th>NUMBER_OF_BOXES</th><th>ACTION</th></tr>
            </thead>
            <tbody>${rowsHtml || `<tr><td colspan="5">No batches available in Production Controller stage.</td></tr>`}</tbody>
          </table>
        </div>
      </section>
    </div>
  `;
}

function renderProductionControlWork(stage) {
  if (!productionSelectedProduct) return renderProductionControlList();
  const product = productionSelectedProduct;
  const record = productionRecords[product.batch] || {};
  return `
    <div class="bar-creation-layout process-only">
      <section class="process-one-form production-detail">
<div class="panel-title">Production Controller - Process 7</div>
<div class="production-summary-panel">
  <label>B&S Batch Number <input value="${product.batch}" readonly></label>
  <label>Product Name <input value="${product.product}" readonly></label>
  <label>Number of Boxes <input id="production-box-count" data-production-input type="number" min="1" value="${record.boxCount || Math.max(1, Math.ceil(Number(product.quantity || 0) / 100))}"></label>
  <label>Room No. <input id="production-room-no" data-production-input value="${record.roomNo || "Room 2"}"></label>
</div>
<div class="process-checks">
  <div class="process-instruction">Production Control checks</div>
  <label class="process-tick"><input type="checkbox" data-production-check> Number of boxes checked</label>
  <label class="process-tick"><input type="checkbox" data-production-check> Product name, strength, pack size, expiry and quantity confirmed</label>
</div>
<div class="signature-grid">
  <label>Allocated By <input value="${currentLogin ? currentLogin.user : stage.user}" readonly></label>
  <label>Date / Time <input value="${record.dateTime || "Pending sign off"}" readonly></label>
  <div class="signoff-action process-signoff-action">
    <button class="classic-button primary" type="button" id="production-complete-button" disabled>User Sign Off</button>
  </div>
</div>
      </section>
    </div>
  `;
}

function updateProductionAvailability() {
  const submitButton = document.querySelector("#production-complete-button");
  if (!submitButton || !productionSelectedProduct) return;
  const checks = [...document.querySelectorAll("[data-production-check]")];
  const boxCount = document.querySelector("#production-box-count");
  const roomNo = document.querySelector("#production-room-no");
  const checksComplete = checks.length > 0 && checks.every((check) => check.checked);
  const hasBoxes = Boolean(boxCount && Number(boxCount.value) > 0);
  const hasRoom = Boolean(roomNo && roomNo.value.trim());
  submitButton.disabled = !(checksComplete && hasBoxes && hasRoom);
}

function completeProductionControl() {
  if (!productionSelectedProduct) return;
  const batchNumber = productionSelectedProduct.batch;
  const now = getAssemblyAuditTimestamp();
  productionRecords[batchNumber] = {
    user: currentLogin ? currentLogin.user : "production.control",
    dateTime: now,
    boxCount: document.querySelector("#production-box-count") ? document.querySelector("#production-box-count").value : "",
    roomNo: document.querySelector("#production-room-no") ? document.querySelector("#production-room-no").value : ""
  };
  if (!productionAllocatedBatchNumbers.includes(batchNumber)) productionAllocatedBatchNumbers.push(batchNumber);
  statusMessage.textContent = `Batch ${batchNumber} allocated to Assembly Room.`;
  window.setTimeout(() => {
    productionSelectedProduct = null;
    renderStage("room-allocation");
  }, 900);
}

function getAssemblyProducts() {
  const allocatedProducts = bnsProducts.filter((product) => productionAllocatedBatchNumbers.includes(product.batch));
  const sourceProducts = allocatedProducts.length ? allocatedProducts : [bnsProducts[0], bnsProducts[1]].filter(Boolean);
  return sourceProducts.filter(
    (product) =>
      !assembledBatchNumbers.includes(product.batch) &&
      matchesBatchOrMfgLot(product, assemblySearch)
  );
}

function getAssemblyCheckInRows() {
  return [
    { user: "JACINTA FER", start: "08:32", end: "10:17" },
    { user: "SUITAI BEN", start: "08:33", end: "10:19" },
    { user: "NASNEEN", start: "08:48", end: "09:04", active: true },
    { user: "MONICA CAR", start: "09:33", end: "" },
    { user: "SITA BEN", start: "10:26", end: "" },
    { user: "JACINTA FER", start: "10:30", end: "" },
    { user: "NASNEEN", start: "", end: "", active: true }
  ];
}

function renderAssemblyCheckInPanel() {
  const rows = getAssemblyCheckInRows().map((row, index) => `
    <tr class="${row.active ? "assembly-check-active" : ""}">
      <td>${index === 0 ? ">" : ""}</td>
      <td>${row.user}</td>
      <td>${row.start}</td>
      <td>${row.end}</td>
    </tr>
  `).join("");
  return `
    <section class="assembly-list-table-wrap assembly-clean-table assembly-checkin-panel">
      <div class="assembly-checkin-actions">
        <button class="classic-button assembly-checkin-button checkin" type="button">Check In</button>
        <button class="classic-button assembly-checkin-button checkout" type="button">Check Out</button>
        <button class="classic-button assembly-checkin-button break" type="button">Break</button>
      </div>
      <div class="assembly-checkin-table-wrap">
        <table class="classic-table assembly-checkin-table">
          <thead>
            <tr><th></th><th>USERNAME</th><th>START_TIME</th><th>END_TIME</th></tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </section>
  `;
}
function renderAssemblyRoomList() {
  const products = getAssemblyProducts();
  const totalQuantity = products.reduce((total, product) => total + Number(product.quantity || 0), 0);
  const completedProducts = bnsProducts.filter(
    (product) =>
      assembledBatchNumbers.includes(product.batch) &&
      matchesBatchOrMfgLot(product, assemblySearch)
  );
  const totalCompletedQuantity = completedProducts.reduce((total, product) => total + Number(product.quantity || 0), 0);

  const activeRowsHtml = products
    .map((product, index) => {
      const record = assemblyRecords[product.batch] || {};
      const productionRecord = productionRecords[product.batch] || {};
      const startRecord = getAssemblyLifecycleRecord(record, "start");
      let statusText = "Ready to Start";
      let statusClass = "hold-status";
      let actionText = "Start Assembly";
      if (startRecord.dateTime) {
        statusText = "In Progress";
        statusClass = "active-status";
        actionText = "Open Checklist";
      }
      return `
        <tr class="${index === 0 ? "selected-row " : ""}clickable-row" data-open-assembly="${product.batch}">
          <td>${index === 0 ? ">" : ""}</td>
          <td><strong>${product.batch}</strong></td>
          <td class="mfg-lot-col">${getMfgLotNo(product) || "-"}</td>
          <td>${product.description}</td>
          <td>${product.quantity}</td>
          <td>${productionRecord.roomNo || "Room 2"}</td>
          <td><span class="status ${statusClass}" style="font-size: 10px; padding: 2px 4px;">${statusText}</span></td>
          <td><button class="classic-button primary" style="font-size: 10px; padding: 2px 6px; min-height: unset !important; height: 24px;" data-open-assembly="${product.batch}">${actionText}</button></td>
        </tr>
      `;
    })
    .join("") || `<tr><td colspan="8">No active batches available for Assembly Room.</td></tr>`;

  const completedRowsHtml = completedProducts
    .map((product) => {
      const record = assemblyRecords[product.batch] || {};
      const productionRecord = productionRecords[product.batch] || {};
      const finishRecord = getAssemblyLifecycleRecord(record, "finish");
      return `
        <tr style="background: #fafafa; opacity: 0.9;">
          <td><strong>${product.batch}</strong></td>
          <td class="mfg-lot-col">${getMfgLotNo(product) || "-"}</td>
          <td>${product.description}</td>
          <td>${product.quantity}</td>
          <td>${productionRecord.roomNo || record.roomNo || "Room 2"}</td>
          <td>${finishRecord.user || "assembly.room"}</td>
          <td>${finishRecord.dateTime || "24 Jun 2026, 12:45:00"}</td>
          <td><span class="status done-status" style="font-size: 10px; padding: 2px 4px;">Completed</span></td>
        </tr>
      `;
    })
    .join("") || `<tr><td colspan="8">No completed batches available.</td></tr>`;

  return `
    <div class="assembly-layout">
      <section class="assembly-window assembly-main-clean">
        <div class="preassembly-batch-search-panel assembly-clean-search assembly-reference-search">
          <label class="classic-search-label">B&S Batch Number : <input class="classic-search-input" data-assembly-search value="${assemblySearch}"></label>
          <label class="classic-search-label">MFG Lot No : <input class="classic-search-input" data-assembly-search value=""></label>
          <button class="classic-search-button classic-button" type="button" data-assembly-search-button>Search</button>
        </div>

        <section class="assembly-list-table-wrap assembly-clean-table">
          <div class="assembly-clean-table-title"><span>Assembly Room Workflow - Active Batches</span><strong>${products.length} batches / ${totalQuantity} packs</strong></div>
          <div style="overflow-x: auto;">
            <table class="classic-table product-grid production-table" style="width: 100%; border-collapse: collapse; margin: 0; table-layout: auto;">
              <thead>
                <tr>
                  <th style="width: 25px;"></th>
                  <th>BNS_BATCH_NO</th>
                  <th class="mfg-lot-col">MFG_LOT_NO</th>
                  <th>DESCRIPTION</th>
                  <th>QUANTITY</th>
                  <th>ROOM_NO</th>
                  <th>STATUS</th>
                  <th>ACTION</th>
                </tr>
              </thead>
              <tbody>${activeRowsHtml}</tbody>
            </table>
          </div>
        </section>

        <section class="assembly-list-table-wrap assembly-clean-table">
          <div class="assembly-clean-table-title"><span>Previous Batches - Completed</span><strong>${completedProducts.length} batches / ${totalCompletedQuantity} packs</strong></div>
          <div style="overflow-x: auto;">
            <table class="classic-table product-grid production-table" style="width: 100%; border-collapse: collapse; margin: 0; table-layout: auto;">
              <thead>
                <tr>
                  <th>BNS_BATCH_NO</th>
                  <th class="mfg-lot-col">MFG_LOT_NO</th>
                  <th>DESCRIPTION</th>
                  <th>QUANTITY</th>
                  <th>ROOM_NO</th>
                  <th>FINISHED_BY</th>
                  <th>FINISH_DATE_TIME</th>
                  <th>STATUS</th>
                </tr>
              </thead>
              <tbody>${completedRowsHtml}</tbody>
            </table>
          </div>
        </section>

        ${renderAssemblyCheckInPanel()}
      </section>
    </div>
  `;
}
function renderAssemblyRoomWork(stage) {
  if (!assemblySelectedProduct) return renderAssemblyRoomList();
  const product = assemblySelectedProduct;
  const record = assemblyRecords[product.batch] || {};
  const productionRecord = productionRecords[product.batch] || {};
  const startRecord = getAssemblyLifecycleRecord(record, "start");
  const finishRecord = getAssemblyLifecycleRecord(record, "finish");
  const signedTabs = record.signedTabs || {};
  const activeTab = assemblyActiveTab || "materials";
  const signedBy = currentLogin ? currentLogin.user : stage.user;
  const tabDisabled = (tabName) => signedTabs[tabName] ? "disabled" : "";
  const tabChecked = (tabName) => signedTabs[tabName] ? "checked" : "";
  const tabSignoff = (tabName, label) => `
    <div class="page-signoff-row ${signedTabs[tabName] ? "signed" : ""}">
      <label>${label} By <input value="${signedTabs[tabName] ? signedTabs[tabName].user : signedBy}" readonly></label>
      <label>Date / Time <input value="${signedTabs[tabName] ? signedTabs[tabName].dateTime : "Pending sign off"}" readonly></label>
      <button class="classic-button primary" type="button" data-assembly-page-signoff="${tabName}" ${signedTabs[tabName] ? "disabled" : ""}>User Sign Off</button>
    </div>
  `;
  const boxCount = Math.max(1, Number(productionRecord.boxCount || record.boxCount || 1));
  const estimatedMinutes = Number(product.quantity || 0) <= 250 ? 30 : Number(product.quantity || 0) <= 500 ? 40 : 60;
  const baseIpcCount = Math.max(1, Math.ceil(estimatedMinutes / 20));
  const ipcCount = baseIpcCount + assemblyExtraIpcRows;
  const quantity = Number(product.quantity || 0);
  const qtyReceived = record.qtyReceived || String(quantity + Math.max(1, Math.round(quantity * 0.01)));
  const qtyUsed = record.usedQty || String(quantity);
  const damages = record.damagedQty || "0";
  const discrepancyQty = record.discrepancyQty || String(Number(qtyReceived || 0) - Number(qtyUsed || 0) - Number(damages || 0));
  const sampleRows = Array.from({ length: boxCount }).map((_, index) => {
    const boxNo = String(index + 1).padStart(2, "0");
    return `
      <tr>
<td>Box ${boxNo}</td>
<td>${product.manufacturingLot || "25088FA"}</td>
<td>${product.expiry}</td>
<td><label class="compact-tick"><input type="checkbox" data-assembly-check data-assembly-tab-check="samples" ${tabChecked("samples")} ${tabDisabled("samples")}> Confirmed</label></td>
      </tr>
    `;
  }).join("");
  const ipcRows = Array.from({ length: ipcCount }).map((_, index) => `
    <label class="ipc-check-card ${signedTabs.ipc ? "signed" : ""}">
      <input type="checkbox" data-assembly-check data-assembly-tab-check="ipc" ${tabChecked("ipc")} ${tabDisabled("ipc")}>
      <strong>IPC ${index + 1}</strong>
      <span>Product: ${product.product}</span>
      <span>Strength: ${product.strength}</span>
      <span>Pack: ${product.packSize}</span>
      <span>ECMA: ${product.ecma}</span>
      <span>PL: ${product.pl}</span>
      <span>Lot: ${product.manufacturingLot || "25088FA"}</span>
      <span>Expiry: ${product.expiry}</span>
      <span>B&S: ${product.batch}</span>
    </label>
  `).join("");
  const reconRows = ["Carton / Braille Label 1", "Blister Label 1", "Blister / Carton 2", "Leaflet 1", "Other"].map((label, index) => `
    <tr>
      <td>${label}</td>
      <td>${index === 4 ? "Blank Label" : "FLU250-10/120/CZ"}</td>
      <td><input data-assembly-input value="${qtyReceived}" ${index === 0 ? 'id="assembly-qty-received"' : ""} ${tabDisabled("recon")}></td>
      <td><input data-assembly-input value="${qtyUsed}" ${index === 0 ? 'id="assembly-used-qty"' : ""} ${tabDisabled("recon")}></td>
      <td><input data-assembly-input value="${damages}" ${index === 0 ? 'id="assembly-damaged-qty"' : ""} ${tabDisabled("recon")}></td>
      <td><input data-assembly-input value="${discrepancyQty}" ${index === 0 ? 'id="assembly-discrepancy-qty"' : ""} ${tabDisabled("recon")}></td>
    </tr>
  `).join("");
  return `
    <div class="assembly-layout">
      <section class="assembly-window assembly-detail-window">
<div class="assembly-toolbar assembly-toolbar-compact">
  <label>Scan BarCode Here <input value="${product.batch}"></label>
  <label>QTY <input value="${product.quantity}" readonly></label>
</div>

<div class="assembly-reference-row">
  <table class="classic-table production-table">
    <thead>
      <tr>
<th>BNS_BATCH_NO</th>
  <th class="mfg-lot-col">MFG_LOT_NO</th>
  <th>DESCRIPTION</th>
<th>QUANTITY</th>
<th>MARKS</th>
<th>BNS_NEW_QTY</th>
<th>ROOM_NO</th>
      </tr>
    </thead>
    <tbody>
      <tr class="selected-row">
<td>${product.batch}</td>
<td class="mfg-lot-col">${getMfgLotNo(product) || "-"}</td>
<td>${product.description}</td>
<td>${product.quantity}</td>
<td>${product.marks || "9"}</td>
<td>${product.quantity}</td>
<td>${productionRecord.roomNo || "Room 2"}</td>
      </tr>
    </tbody>
  </table>
  <div class="assembly-partial-actions">
    <button class="classic-button primary" type="button">Partial Start</button>
    <button class="classic-button" type="button">Partial Finish</button>
    <button class="classic-button assembly-break-action" type="button">Break</button>
  </div>
</div>

<div class="assembly-process-tabs">
  <button class="assembly-tab ${activeTab === "materials" ? "active" : ""}" type="button" data-assembly-tab="materials">Initial Checks</button>
  <button class="assembly-tab ${activeTab === "samples" ? "active" : ""}" type="button" data-assembly-tab="samples">Random Sample Check</button>
  <button class="assembly-tab ${activeTab === "ipc" ? "active" : ""}" type="button" data-assembly-tab="ipc">IPC Checks</button>
  <button class="assembly-tab ${activeTab === "recon" ? "active" : ""}" type="button" data-assembly-tab="recon">Reconciliation & Closure</button>
</div>

<div class="assembly-tab-panel ${activeTab === "materials" ? "active" : ""}" data-assembly-panel="materials">
  <fieldset class="assembly-lock-fieldset" ${tabDisabled("materials")}>
  <div class="system-panel-grid">
    <section class="system-panel">
      <div class="panel-title">Initial Checks</div>
      <div class="assembly-start-grid">
<label>Assembly Room <input value="${productionRecord.roomNo || "Room 2"}" readonly></label>
<label>Batch Started By <input id="assembly-start-user" data-assembly-input value="${startRecord.user || "Pending"}" readonly></label>
<label>Batch Start Date / Time <input id="assembly-start-time" data-assembly-input value="${startRecord.dateTime || "Pending"}" readonly></label>
<label>Batch Finished By <input id="assembly-finish-user" data-assembly-input value="${finishRecord.user || "Pending"}" readonly></label>
<label>Batch Finish Date / Time <input id="assembly-finish-time" data-assembly-input value="${finishRecord.dateTime || "Pending"}" readonly></label>
<label>Briefing Done By <input id="assembly-briefing-time" data-assembly-input value="${record.briefingTime || signedBy}" readonly></label>
      </div>
      <div class="process-checks">
<label class="process-tick"><input type="checkbox" data-assembly-check data-assembly-tab-check="materials" ${tabChecked("materials")}> Allocated BNS Batch No verified on PLPI against BAR</label>
<label class="process-tick"><input type="checkbox" data-assembly-check data-assembly-tab-check="materials" ${tabChecked("materials")}> Specimen verified against BAR</label>
<label class="process-tick"><input type="checkbox" data-assembly-check data-assembly-tab-check="materials" ${tabChecked("materials")}> Room leader confirms BAR, printed material and specimen are correct</label>
      </div>
    </section>
    <section class="system-panel">
      <div class="panel-title">Received Materials</div>
      <div class="material-card-grid">
${[
  ["Carton/Braille Label 1", "FLU250-10/120/CZ (R4)"],
  ["Blister Label 1", "FLU250-10/120/CZ/B1 (R3)"],
  ["Blister/Carton Label 2", "FLU250-10/120/CZ/B2 (R3)"],
  ["Leaflet 1", "FLU250-10/120/CZ/LT (R5)"],
  ["Other", "Blank Label"]
].map(([label, ref]) => `
  <label class="material-check-card"><input type="checkbox" data-assembly-check data-assembly-tab-check="materials" ${tabChecked("materials")}><span>${label}</span><strong>${ref}</strong></label>
`).join("")}
      </div>
    </section>
  </div>
  </fieldset>
  ${tabSignoff("materials", "Initial Checks")}
</div>

<div class="assembly-tab-panel ${activeTab === "samples" ? "active" : ""}" data-assembly-panel="samples">
  <fieldset class="assembly-lock-fieldset" ${tabDisabled("samples")}>
  <div class="system-panel-grid single-panel-grid">
    <section class="system-panel">
      <div class="panel-title">Product Random Sample Check</div>
      <table class="classic-table sample-check-table">
<thead><tr><th>Box Number</th><th class="mfg-lot-col">Mfg. Lot No.</th><th>Exp. Date</th><th>Confirmed</th></tr></thead>
<tbody>${sampleRows}</tbody>
      </table>
      <p class="quiet-system-note">${boxCount} box${boxCount === 1 ? "" : "es"} carried from Production Controller. Mfg. lot and expiry are populated from the BAR details.</p>
    </section>
  </div>
  </fieldset>
  ${tabSignoff("samples", "Random Sample Check")}
</div>

<div class="assembly-tab-panel ${activeTab === "ipc" ? "active" : ""}" data-assembly-panel="ipc">
  <fieldset class="assembly-lock-fieldset" ${tabDisabled("ipc")}>
  <div class="system-panel">
    <div class="panel-title">In Process Checks</div>
    <div class="ipc-summary-row">
      <span>Estimated assembly time: ${estimatedMinutes} minutes</span>
      <span>Required IPC checks: ${baseIpcCount}</span>
      <button class="classic-button" type="button" data-add-ipc-row>Add IPC Row</button>
    </div>
    <div class="ipc-product-strip">
      <span><strong>Product</strong>${product.product}</span>
      <span><strong>Strength</strong>${product.strength}</span>
      <span><strong>Pack Size</strong>${product.packSize}</span>
      <span><strong>ECMA</strong>${product.ecma}</span>
      <span><strong>PL No.</strong>${product.pl}</span>
      <span><strong>Units</strong>${product.unitsPerPack || "1"}</span>
      <span><strong>Mfg. Lot No.</strong>${product.manufacturingLot || "25088FA"}</span>
      <span><strong>Expiry</strong>${product.expiry}</span>
      <span><strong>B&S Batch No.</strong>${product.batch}</span>
    </div>
    <div class="ipc-card-grid">${ipcRows}</div>
  </div>
  </fieldset>
  ${tabSignoff("ipc", "IPC Checks")}
</div>

<div class="assembly-tab-panel ${activeTab === "recon" ? "active" : ""}" data-assembly-panel="recon">
  <fieldset class="assembly-lock-fieldset" ${tabDisabled("recon")}>
  <div class="system-panel">
    <div class="panel-title">Reconciliation</div>
    <table class="recon-clean-table">
      <thead>
<tr>
  <th>Type of Label</th>
  <th>Reference Code</th>
  <th>Qty Received</th>
  <th>Qty Used</th>
  <th>Damages</th>
  <th>Discrepancy</th>
</tr>
      </thead>
      <tbody>${reconRows}</tbody>
    </table>
    <div class="reconciliation-grid">
      <label>Total <input id="assembly-used-labels" data-assembly-input type="number" min="0" value="${record.usedLabels || product.quantity}"></label>
      <label>Retention Sample <input data-assembly-input value="1"></label>
      <label>Yield <input id="assembly-surplus-qty" data-assembly-input type="number" min="0" value="${record.surplusQty || Number(product.quantity || 0) - 1}"></label>
      <label>Damages <input id="assembly-extra-components" data-assembly-input value="${record.extraComponents || "0"}"></label>
      <label class="span-three">Comment <textarea id="assembly-comments" data-assembly-input>${record.comments || ""}</textarea></label>
    </div>
    <div class="panel-title">End of Batch Clearance</div>
    <div class="clearance-card-grid">
      <label class="process-tick"><input type="checkbox" data-assembly-check data-assembly-tab-check="recon" ${tabChecked("recon")}> Waste material cleared from work surfaces and floor</label>
      <label class="process-tick"><input type="checkbox" data-assembly-check data-assembly-tab-check="recon" ${tabChecked("recon")}> Waste bin is empty</label>
      <label class="process-tick"><input type="checkbox" data-assembly-check data-assembly-tab-check="recon" ${tabChecked("recon")}> Unwanted containers removed from room</label>
      <label class="process-tick"><input type="checkbox" data-assembly-check data-assembly-tab-check="recon" ${tabChecked("recon")}> No material left from current operation</label>
    </div>
  </div>
  </fieldset>
  ${tabSignoff("recon", "Reconciliation")}
</div>
      </section>
    </div>
  `;
}

function updateAssemblyAvailability() {
  if (!assemblySelectedProduct) return;
  refreshAssemblyReconciliationStatus();
  document.querySelectorAll("[data-assembly-page-signoff]").forEach((button) => {
    const tabName = button.dataset.assemblyPageSignoff;
    const record = assemblyRecords[assemblySelectedProduct.batch] || {};
    const signedTabs = record.signedTabs || {};
    if (signedTabs[tabName]) {
      button.disabled = true;
      return;
    }
    const checks = [...document.querySelectorAll(`[data-assembly-tab-check="${tabName}"]`)];
    const checksComplete = checks.length === 0 || checks.every((check) => check.checked);
    const briefingComplete = tabName !== "materials" || Boolean(document.querySelector("#assembly-briefing-time") && document.querySelector("#assembly-briefing-time").value.trim());
    const reconComplete = tabName !== "recon" || Boolean(document.querySelector("#assembly-used-qty") && document.querySelector("#assembly-used-qty").value !== "");
    button.disabled = !(checksComplete && briefingComplete && reconComplete);
  });
}

function refreshAssemblyReconciliationStatus() {
  if (!assemblySelectedProduct) return;
  const quantity = Number(assemblySelectedProduct.quantity || 0);
  const qtyReceived = Number(document.querySelector("#assembly-qty-received") ? document.querySelector("#assembly-qty-received").value : quantity);
  const qtyUsed = Number(document.querySelector("#assembly-used-qty") ? document.querySelector("#assembly-used-qty").value : quantity);
  const damages = Number(document.querySelector("#assembly-damaged-qty") ? document.querySelector("#assembly-damaged-qty").value : 0);
  const discrepancyInput = document.querySelector("#assembly-discrepancy-qty");
  if (discrepancyInput && document.activeElement !== discrepancyInput) {
    discrepancyInput.value = String(qtyReceived - qtyUsed - damages);
  }
}

function getAssemblyAuditUser() {
  return currentLogin ? currentLogin.user : "assembly.room";
}

function getAssemblyAuditTimestamp() {
  return new Date().toLocaleString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  });
}

function getAssemblyLifecycleRecord(record, type) {
  if (!record) return { user: "", dateTime: "" };
  const auditRecord = type === "start" ? record.startRecord : record.finishRecord;
  if (auditRecord && (auditRecord.user || auditRecord.dateTime)) {
    return {
      user: auditRecord.user || record.user || "assembly.room",
      dateTime: auditRecord.dateTime || ""
    };
  }
  const legacyDateTime = type === "start" ? record.startTime : record.finishTime;
  if (legacyDateTime && legacyDateTime !== "Pending" && legacyDateTime !== "Not started" && legacyDateTime !== "Not finished") {
    return {
      user: record.user || "assembly.room",
      dateTime: legacyDateTime
    };
  }
  return { user: "", dateTime: "" };
}

function getAssemblyLifecycleText(record, type, pendingText) {
  const auditRecord = getAssemblyLifecycleRecord(record, type);
  if (!auditRecord.dateTime) return pendingText;
  return `${auditRecord.user || "assembly.room"} - ${auditRecord.dateTime}`;
}

function requestAssemblyBatchStart(product) {
  requestAppConfirmation(
    () => recordAssemblyBatchStart(product),
    "Start Batch",
    `Start the Batch ${product.batch}?`,
    "This will record the current user name and date / time as the Assembly Room batch start.",
    "Yes, Start Batch"
  );
}

function requestAssemblyBatchFinish(batchNumber) {
  requestAppConfirmation(
    () => recordAssemblyBatchFinish(batchNumber),
    "Finish Batch",
    `Finish Batch ${batchNumber}?`,
    "This will record the current user name and date / time as the Assembly Room batch finish.",
    "Yes, Finish Batch"
  );
}

function recordAssemblyBatchStart(product) {
  if (!product) return;
  const batchNumber = product.batch;
  const now = getAssemblyAuditTimestamp();
  const user = getAssemblyAuditUser();
  const existingRecord = assemblyRecords[batchNumber] || {};
  assemblyRecords[batchNumber] = {
    ...existingRecord,
    user,
    startRecord: { user, dateTime: now },
    startTime: now,
    briefingTime: existingRecord.briefingTime || user
  };
  assemblySelectedProduct = product;
  assemblyExtraIpcRows = 0;
  assemblyActiveTab = "materials";
  renderStage("assembly-room");
  statusMessage.textContent = `Batch ${batchNumber} started by ${user} at ${now}.`;
}

function recordAssemblyBatchFinish(batchNumber) {
  const now = getAssemblyAuditTimestamp();
  const user = getAssemblyAuditUser();
  const existingRecord = assemblyRecords[batchNumber] || {};
  assemblyRecords[batchNumber] = {
    ...existingRecord,
    user,
    dateTime: now,
    finishRecord: { user, dateTime: now },
    finishTime: now,
    briefingTime: existingRecord.briefingTime || user
  };
  if (!assembledBatchNumbers.includes(batchNumber)) assembledBatchNumbers.push(batchNumber);
  statusMessage.textContent = `Batch ${batchNumber} finished by ${user} at ${now} and moved to Post-Assembly QC.`;
  window.setTimeout(() => {
    assemblySelectedProduct = null;
    assemblyExtraIpcRows = 0;
    assemblyActiveTab = "materials";
    renderStage("assembly-room");
  }, 900);
}

function captureAssemblyTime(type) {
  if (!assemblySelectedProduct) {
    assemblySelectedProduct = getAssemblyProducts()[0] || bnsProducts[0] || null;
  }
  if (!assemblySelectedProduct) return;
  if (type === "start") {
    recordAssemblyBatchStart(assemblySelectedProduct);
  } else {
    recordAssemblyBatchFinish(assemblySelectedProduct.batch);
  }
}
function signOffAssemblyPage(tabName) {
  if (!assemblySelectedProduct) return;
  const batchNumber = assemblySelectedProduct.batch;
  const now = getAssemblyAuditTimestamp();
  const existingRecord = assemblyRecords[batchNumber] || {};
  assemblyRecords[batchNumber] = {
    ...existingRecord,
    user: getAssemblyAuditUser(),
    dateTime: Object.keys({ ...(existingRecord.signedTabs || {}), [tabName]: true }).length === 4 ? now : existingRecord.dateTime,
    startRecord: existingRecord.startRecord,
    finishRecord: existingRecord.finishRecord,
    startTime: existingRecord.startTime || (document.querySelector("#assembly-start-time") ? document.querySelector("#assembly-start-time").value : ""),
    finishTime: existingRecord.finishTime || (document.querySelector("#assembly-finish-time") ? document.querySelector("#assembly-finish-time").value : ""),
    briefingTime: document.querySelector("#assembly-briefing-time") ? document.querySelector("#assembly-briefing-time").value : "",
    boxCount: productionRecords[batchNumber] ? productionRecords[batchNumber].boxCount : "",
    qtyReceived: document.querySelector("#assembly-qty-received") ? document.querySelector("#assembly-qty-received").value : "",
    usedQty: document.querySelector("#assembly-used-qty") ? document.querySelector("#assembly-used-qty").value : "",
    usedLabels: document.querySelector("#assembly-used-labels") ? document.querySelector("#assembly-used-labels").value : "",
    damagedQty: document.querySelector("#assembly-damaged-qty") ? document.querySelector("#assembly-damaged-qty").value : "",
    discrepancyQty: document.querySelector("#assembly-discrepancy-qty") ? document.querySelector("#assembly-discrepancy-qty").value : "",
    surplusQty: document.querySelector("#assembly-surplus-qty") ? document.querySelector("#assembly-surplus-qty").value : "",
    extraComponents: document.querySelector("#assembly-extra-components") ? document.querySelector("#assembly-extra-components").value : "",
    comments: document.querySelector("#assembly-comments") ? document.querySelector("#assembly-comments").value : "",
    signedTabs: {
      ...(existingRecord.signedTabs || {}),
      [tabName]: {
user: getAssemblyAuditUser(),
dateTime: now
      }
    }
  };
  const signedCount = Object.keys(assemblyRecords[batchNumber].signedTabs).length;
  if (signedCount >= 4) {
    requestAssemblyBatchFinish(batchNumber);
    return;
  }
  statusMessage.textContent = `${tabName === "materials" ? "Initial Checks" : tabName === "samples" ? "Random Sample Check" : tabName === "ipc" ? "IPC Checks" : "Reconciliation"} signed off for ${batchNumber}.`;
  renderStage("assembly-room");
}

function getPostAssemblyProducts() {
  const completedProducts = bnsProducts.filter((product) => assembledBatchNumbers.includes(product.batch));
  const sourceProducts = completedProducts.length ? completedProducts : [bnsProducts[0], bnsProducts[1], bnsProducts[2]].filter(Boolean);
  return sourceProducts.filter(
    (product) =>
      !postAssemblyCheckedBatchNumbers.includes(product.batch) &&
      matchesBatchOrMfgLot(product, postAssemblySearch)
  );
}

function renderPostAssemblyList() {
  const products = getPostAssemblyProducts();
  const totalQuantity = products.reduce((total, product) => total + Number(product.quantity || 0), 0);
  return `
    <div class="postassembly-layout">
      <section class="postassembly-window postassembly-list-window">
<div class="sub-window-title">Production Checking</div>
<div class="postassembly-list-header">
  <div class="production-search">
    <label class="classic-search-label">BNS Batch No : <input class="classic-search-input" data-postassembly-search value="${postAssemblySearch}" placeholder="Enter batch no"></label>
    <label class="classic-search-label">MFG Lot No : <input class="classic-search-input" data-postassembly-search value="${postAssemblySearch}" placeholder="Enter MFG lot"></label>
    <button class="classic-search-button" type="button" data-postassembly-search-button>Search</button>
  </div>
</div>
<div class="postassembly-list-panel">
  <table class="classic-table product-grid postassembly-table postassembly-list-table">
    <thead>
      <tr>
<th></th>
<th>BNS_BATCH_NO</th>
  <th class="mfg-lot-col">MFG_LOT_NO</th>
  <th>DESCRIPTION</th>
<th>QUANTITY</th>
<th>ASSEMBLED_QTY</th>
<th>EXPIRY_DATE</th>
<th>STRENGTH</th>
<th>PACK_SIZE</th>
<th>STATUS</th>
      </tr>
    </thead>
    <tbody>
      ${products
.map(
  (product, index) => `
    <tr class="${index === 0 ? "selected-row " : ""}clickable-row" data-open-postassembly="${product.batch}">
      <td>${index === 0 ? ">" : ""}</td>
      <td>${product.batch}</td>
<td class="mfg-lot-col">${getMfgLotNo(product) || "-"}</td>
<td>${product.description}</td>
      <td>${product.quantity}</td>
      <td>${assemblyRecords[product.batch] && assemblyRecords[product.batch].usedLabels ? assemblyRecords[product.batch].usedLabels : product.quantity}</td>
      <td>${product.expiry}</td>
      <td>${product.strength}</td>
      <td>${product.packSize}</td>
      <td>POST ASSEMBLY</td>
    </tr>
  `
)
.join("") || `<tr><td colspan="10">No batches available in Post Assembly status.</td></tr>`}
    </tbody>
  </table>
  <div class="double-check-counts">
    <span>Total Batches : <strong>${products.length}</strong></span>
    <span>Total Quantity : <strong>${totalQuantity}</strong></span>
  </div>
</div>
      </section>
    </div>
  `;
}

function renderPostAssemblyWork(stage) {
  if (!postAssemblySelectedProduct) return renderPostAssemblyList();
  const product = postAssemblySelectedProduct;
  const record = postAssemblyRecords[product.batch] || {};
  const assemblyRecord = assemblyRecords[product.batch] || {};
  const quantity = Number(assemblyRecord.usedLabels || product.quantity || 0);
  const defaultBoxes = Math.max(1, Math.ceil(quantity / 100));
  const sampleCount = Math.ceil(Math.sqrt(quantity)) + 1;
  const quarantinePrinted = Boolean(record.quarantinePrinted);
  const packChecksConfirmed = Boolean(record.packChecksConfirmed);
  return `
    <div class="postassembly-layout">
      <section class="postassembly-window postassembly-detail-window">
<div class="sub-window-title">Production Checking</div>
${renderBatchDetails(product)}

<div class="postassembly-entry-panel">
  <div class="panel-title">Post Assembly Quantity Details</div>
  <div class="postassembly-quantity-grid">
    <label>Total Packs <input id="postassembly-total-qty" data-postassembly-input type="number" min="1" value="${record.totalQty || quantity}"></label>
    <label>Total Box <input id="postassembly-box-count" data-postassembly-input type="number" min="1" value="${record.boxCount || defaultBoxes}"></label>
    <label>No. of Packs Checked <input id="postassembly-packs-checked" data-postassembly-input type="number" min="1" value="${record.packsChecked || sampleCount}"></label>
  </div>
</div>

<div class="system-panel">
  <div class="panel-title">Pack Details Against BAR</div>
  <table class="recon-clean-table postassembly-process-table">
    <thead>
      <tr>
<th>Details</th>
<th>Product Name & Strength</th>
<th>Reference Code</th>
<th>MFG Batch No.</th>
<th>B&S Batch No.</th>
<th>Expiry Date</th>
      </tr>
    </thead>
    <tbody>
      ${[
["Carton/Braille Label 1", "FLU250-10/120/CZ (R4)"],
["Blister Label 1", "FLU250-10/120/CZ/B1 (R3)"],
["Blister/Carton Label 2", "FLU250-10/120/CZ/B2 (R3)"],
["Leaflet 1", "FLU250-10/120/CZ/LT (R5)"],
["Other", "Blank Label"]
      ].map(([detail, ref]) => `
<tr>
  <td>${detail}</td>
  <td>${product.product} ${product.strength}</td>
  <td>${ref}</td>
  <td>${product.manufacturingLot || "25088FA"}</td>
  <td>${product.batch}</td>
  <td><label class="expiry-confirm"><span>${product.expiry}</span><input type="checkbox" data-postassembly-pack-check ${packChecksConfirmed ? "checked disabled" : ""}></label></td>
</tr>
      `).join("")}
    </tbody>
  </table>
</div>

<label class="postassembly-comment">Comment <textarea id="postassembly-comments" data-postassembly-input>${record.comments || ""}</textarea></label>

<div class="postassembly-print-actions">
  <button class="classic-button primary" type="button" id="postassembly-print-button" disabled>Print Quarantine Label</button>
  <button class="classic-button" type="button" data-test-quarantine-print>Test Print</button>
  <span>Quarantine Label: <strong>${quarantinePrinted ? "Printed" : "Pending"}</strong></span>
</div>

<div class="signature-grid">
  <label>Checked By <input value="${currentLogin ? currentLogin.user : stage.user}" readonly></label>
  <label>Date / Time <input value="${record.dateTime || "Pending sign off"}" readonly></label>
  <div class="signoff-action process-signoff-action">
    <button class="classic-button primary" type="button" id="postassembly-complete-button" disabled>User Sign Off</button>
  </div>
</div>
      </section>
    </div>
  `;
}

function updatePostAssemblyAvailability() {
  const submitButton = document.querySelector("#postassembly-complete-button");
  const printButton = document.querySelector("#postassembly-print-button");
  if (!submitButton || !postAssemblySelectedProduct) return;
  const boxCount = document.querySelector("#postassembly-box-count");
  const totalQty = document.querySelector("#postassembly-total-qty");
  const packsChecked = document.querySelector("#postassembly-packs-checked");
  const packChecks = [...document.querySelectorAll("[data-postassembly-pack-check]")];
  const packChecksComplete = packChecks.length > 0 && packChecks.every((check) => check.checked);
  const record = postAssemblyRecords[postAssemblySelectedProduct.batch] || {};
  const quantitiesComplete = Boolean(boxCount && Number(boxCount.value) > 0 && totalQty && Number(totalQty.value) > 0 && packsChecked && Number(packsChecked.value) > 0);
  const readyToPrint = packChecksComplete && quantitiesComplete;
  if (printButton) {
    printButton.disabled = record.quarantinePrinted || !readyToPrint;
  }
  submitButton.disabled = !(record.quarantinePrinted && (record.packChecksConfirmed || packChecksComplete) && quantitiesComplete);
}

function printQuarantineLabel() {
  if (!postAssemblySelectedProduct) return;
  const batchNumber = postAssemblySelectedProduct.batch;
  postAssemblyRecords[batchNumber] = {
    ...(postAssemblyRecords[batchNumber] || {}),
    quarantinePrinted: true,
    packChecksConfirmed: true,
    boxCount: document.querySelector("#postassembly-box-count") ? document.querySelector("#postassembly-box-count").value : "",
    totalQty: document.querySelector("#postassembly-total-qty") ? document.querySelector("#postassembly-total-qty").value : "",
    packsChecked: document.querySelector("#postassembly-packs-checked") ? document.querySelector("#postassembly-packs-checked").value : "",
    comments: document.querySelector("#postassembly-comments") ? document.querySelector("#postassembly-comments").value : ""
  };
  statusMessage.textContent = `Quarantine label printed for ${batchNumber}.`;
  renderStage("post-assembly-qc");
}

function completePostAssembly() {
  if (!postAssemblySelectedProduct) return;
  const batchNumber = postAssemblySelectedProduct.batch;
  const now = getAssemblyAuditTimestamp();
  postAssemblyRecords[batchNumber] = {
    ...(postAssemblyRecords[batchNumber] || {}),
    user: currentLogin ? currentLogin.user : "postassembly.qc",
    dateTime: now,
    boxCount: document.querySelector("#postassembly-box-count") ? document.querySelector("#postassembly-box-count").value : "",
    totalQty: document.querySelector("#postassembly-total-qty") ? document.querySelector("#postassembly-total-qty").value : "",
    packsChecked: document.querySelector("#postassembly-packs-checked") ? document.querySelector("#postassembly-packs-checked").value : "",
    comments: document.querySelector("#postassembly-comments") ? document.querySelector("#postassembly-comments").value : ""
  };
  if (!postAssemblyCheckedBatchNumbers.includes(batchNumber)) postAssemblyCheckedBatchNumbers.push(batchNumber);
  statusMessage.textContent = `Batch ${batchNumber} moved to Pre-QP.`;
  window.setTimeout(() => {
    postAssemblySelectedProduct = null;
    renderStage("post-assembly-qc");
  }, 900);
}

function getQpReleaseLogId(batchNumber) {
  return qpReleaseRecords[batchNumber] && qpReleaseRecords[batchNumber].qpId ? qpReleaseRecords[batchNumber].qpId : "";
}

function createQpReleaseLogId() {
  const existingIds = Array.from(new Set(Object.values(qpReleaseRecords).map((record) => record.qpId).filter(Boolean)));
  const nextNumber = existingIds.length + 1;
  return `QP-2026-${String(nextNumber).padStart(4, "0")}`;
}

function assignQpReleaseLogId(batchNumbers) {
  const existingId = batchNumbers.map(getQpReleaseLogId).find(Boolean);
  const qpId = existingId || createQpReleaseLogId();
  batchNumbers.forEach((batchNumber) => {
    qpReleaseRecords[batchNumber] = {
      ...(qpReleaseRecords[batchNumber] || {}),
      qpId,
      qpReady: true,
      qpLogGeneratedAt: getAssemblyAuditTimestamp()
    };
  });
  return qpId;
}

function ensurePreQpTestData() {
  const addMany = (target, values) => values.forEach((value) => {
    if (!target.includes(value)) target.push(value);
  });
  const postReadyBatches = ["LVT013", "LVT014", "LVT015", "LVT016", "LVT017", "LVT018", "LVT019", "LVT020"];
  const qpReadyBatches = ["LVT014", "LVT015", "LVT016", "LVT017"];

  addMany(postAssemblyCheckedBatchNumbers, postReadyBatches);
  addMany(preQpCheckedBatchNumbers, qpReadyBatches);

  postReadyBatches.forEach((batch, index) => {
    const product = bnsProducts.find((item) => item.batch === batch);
    if (!product) return;
    postAssemblyRecords[batch] = postAssemblyRecords[batch] || {
      user: "postassembly.qc",
      dateTime: `24 Jun 2026, ${14 + index}:20:00`,
      boxCount: String(Math.max(1, Math.ceil(Number(product.quantity || 0) / 100))),
      totalQty: product.quantity,
      packsChecked: String(26 + index),
      quarantinePrinted: true,
      packChecksConfirmed: true,
      comments: "Demo record ready for Pre-QP."
    };
  });

  qpReadyBatches.forEach((batch, index) => {
    const product = bnsProducts.find((item) => item.batch === batch);
    if (!product) return;
    preQpRecords[batch] = preQpRecords[batch] || {
      sampleBox: "01",
      docs: ["Yes", "Yes", "Yes", "Yes", "Yes", "Yes"],
      materialChecked: true,
      comments: index === 0 ? "Release log printed; waiting QP decision." : "Release log printed and QP decision recorded.",
      user: "pre.qp",
      dateTime: `24 Jun 2026, 16:${String(10 + index * 8).padStart(2, "0")}:00`,
      logGenerated: true
    };
    qpReleaseRecords[batch] = qpReleaseRecords[batch] || {
      qpId: `QP-2026-00${5 + index}`,
      qpReady: true,
      qpLogGeneratedAt: `24 Jun 2026, 16:${35 + index * 7}:00`,
      releaseLog: getQpReleaseLogDefaults(product)
    };
  });

  qpReleaseRecords.LVT019 = { ...(qpReleaseRecords.LVT019 || {}), decision: "Approve", approved: true, decisionBy: "qp.release", decisionDateTime: "24 Jun 2026, 17:25:00" };
  qpReleaseRecords.LVT020 = { ...(qpReleaseRecords.LVT020 || {}), decision: "Hold", decisionBy: "qp.release", decisionDateTime: "24 Jun 2026, 17:40:00" };
  addMany(qpCertifiedBatchNumbers, ["LVT019", "LVT020"]);
}
function getPreQpProducts() {
  ensurePreQpTestData();
  const completedProducts = bnsProducts.filter((product) => postAssemblyCheckedBatchNumbers.includes(product.batch));
  const sourceProducts = completedProducts.length ? completedProducts : [bnsProducts[0], bnsProducts[1], bnsProducts[2], bnsProducts[3]].filter(Boolean);
  const normalizedPreQpSearch = preQpSearch.trim().toLowerCase();
  return sourceProducts.filter((product) => {
    const batch = String(product.batch || product.batchNo || "").toLowerCase();
    const qpRecord = qpReleaseRecords[product.batch] || {};
    const movedToQp = qpRecord.qpReady || qpRecord.qpId || qpRecord.decision || qpRecord.approved || qpReleasedBatchNumbers.includes(product.batch);
    return !movedToQp && (!normalizedPreQpSearch || batch.includes(normalizedPreQpSearch));
  });
}

function renderPreQpList() {
  const products = getPreQpProducts().map((product, index) => ({
    relId: String(28940 + index),
    releasedOn: "24-06-2026",
    releaseFor: product.country || "UK",
    description: product.description || product.product,
    strength: product.strength,
    packSize: product.packSize,
    batch: product.batch,
    manufLotNo: getMfgLotNo(product),
    expiry: product.expiry,
    quantity: product.quantity,
    verified: preQpCheckedBatchNumbers.includes(product.batch),
    selectedForPrint: preQpReleaseLogSelection.includes(product.batch),
    product
  }));
  preQpReleaseLogSelection = preQpReleaseLogSelection.filter((batch) => products.some((product) => product.batch === batch && product.verified));
  const selectedVerifiedCount = preQpReleaseLogSelection.length;
  return `
    <div class="preqp-layout">
      <section class="preqp-window preqp-list-window" style="padding: 15px;">
<div style="text-align: center; font-size: 16px; font-weight: bold; margin-bottom: 12px; font-family: Tahoma, sans-serif;">Pre QP</div>
<div class="preqp-search-row" style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px; flex-wrap: wrap;">
  <label class="classic-search-label" style="font-size: 11px;">RID : <input class="classic-search-input" data-preqp-search style="width: 80px;" value="" placeholder=""></label>
  <label class="classic-search-label" style="font-size: 11px;">BNS Batch No : <input class="classic-search-input" data-preqp-search style="width: 100px;" value="${preQpSearch}" placeholder=""></label>
  <label class="classic-search-label" style="font-size: 11px;">Release Date : <select style="min-height: 22px; width: 100px;"><option></option></select></label>
  <label class="classic-search-label" style="font-size: 11px; flex-direction: row;"><input type="checkbox"> On Hold</label>
  <button class="classic-search-button" type="button" data-preqp-search-button>Search</button>
</div>
<div class="preqp-list-panel">
  <table class="classic-table product-grid preqp-table">
    <thead>
      <tr>
<th style="width: 50px;">Select</th>
<th>Rel Id</th>
<th>Released On</th>
<th>RELEASE_FOR</th>
<th>DESCRIPTION</th>
<th>STRENGTH</th>
<th>PACK_SIZE</th>
<th>BNS_BATCH_NO</th>
<th class="mfg-lot-col">MFG_LOT_NO</th>
<th>EXPIRY_DATE</th>
<th>QUANTITY</th>
      </tr>
    </thead>
    <tbody>
      ${products.map((product) => {
const statusClass = product.verified ? "preqp-row-approved preqp-row-verified" : "preqp-row-white";
return `
  <tr class="clickable-row ${statusClass}" data-open-preqp="${product.batch}">
    <td style="text-align: center;"><input type="checkbox" data-preqp-log-select="${product.batch}" ${product.selectedForPrint ? "checked" : ""} ${product.verified ? "" : "disabled"}></td>
    <td>${product.relId}</td>
    <td>${product.releasedOn}</td>
    <td>${product.releaseFor}</td>
    <td>${product.description}</td>
    <td>${product.strength}</td>
    <td>${product.packSize}</td>
    <td>${product.batch}</td>
    <td class="mfg-lot-col">${getMfgLotNo(product) || "-"}</td>
    <td>${product.expiry}</td>
    <td>${product.quantity}</td>
  </tr>
`;
      }).join("") || `<tr><td colspan="11">No batches available in Pre QP.</td></tr>`}
    </tbody>
  </table>
  <div style="display: flex; justify-content: flex-end; gap: 40px; margin-top: 8px; font-size: 11px; font-weight: normal; color: #000; font-family: Tahoma, sans-serif;">
    <span>Total Batches : <strong>${products.length}</strong></span>
    <span>Total Quantity : <strong>${products.reduce((total, product) => total + Number(product.quantity || 0), 0)}</strong></span>
  </div>
</div>
<div class="preqp-actions-row" style="display: flex; align-items: center; justify-content: space-between; margin-top: 15px; padding-top: 10px; border-top: 1px solid #c0c0c0; font-family: Tahoma, sans-serif;">
  <div>
    <button class="classic-button" type="button" data-preqp-select-verified>Select Verified</button>
  </div>
  <div style="display: flex; gap: 15px; align-items: center;">
    <span style="display: inline-flex; align-items: center; gap: 4px; font-size: 11px; font-weight: bold; color: #27ae60;"><span style="width: 8px; height: 8px; border-radius: 50%; background: #27ae60; border: 1px solid #1e7e43; display: inline-block;"></span> Verified</span>
    <span style="display: inline-flex; align-items: center; gap: 4px; font-size: 11px; font-weight: bold; color: #777;"><span style="width: 8px; height: 8px; border-radius: 50%; background: #fff; border: 1px solid #aaa; display: inline-block;"></span> Pending Verification</span>
  </div>
  <div style="display: flex; gap: 10px;">
    <button class="classic-button primary" type="button" id="preqp-print-release-log-button" ${selectedVerifiedCount ? "" : "disabled"}>Print QP Release Log</button>
    <button class="classic-button" type="button">Batch History</button>
    <button class="classic-button" type="button">Test Print</button>
  </div>
</div>
      </section>
    </div>
  `;
}
function renderReleaseLogPreview(product, record, stage) {
  const postRecord = postAssemblyRecords[product.batch] || {};
  const totalQty = postRecord.totalQty || product.quantity;
  const boxes = postRecord.boxCount || Math.max(1, Math.ceil(Number(product.quantity || 0) / 100));
  const yieldQty = Math.max(0, Number(totalQty || 0) - 1);
  return `
    <section class="release-log-preview">
      <div class="release-log-brand">B&S HEALTHCARE</div>
      <table class="release-log-table">
<thead>
  <tr>
    <th>Product</th>
    <th>B&S Batch No. / Exp Date</th>
    <th>Country of Origin</th>
    <th>Manufacturer Batch Number / Quantity / IMP</th>
    <th>QTY Issued</th>
    <th>Ret. Sample</th>
    <th>Damaged / Reg. Sample</th>
    <th>Yield</th>
    <th>Room No</th>
    <th>Boxes</th>
    <th>Approved</th>
    <th>Comments</th>
  </tr>
</thead>
<tbody>
  <tr>
    <td>${product.product}<br>${product.strength}</td>
    <td>${product.batch}<br>${product.expiry}</td>
    <td>${product.country}</td>
    <td>${product.manufacturingLot || "25088FA"} / ${totalQty} / ${product.imp || "C13278"}</td>
    <td>${totalQty}</td>
    <td>01</td>
    <td></td>
    <td>${yieldQty}</td>
    <td>${productionRecords[product.batch] ? productionRecords[product.batch].roomNo : "3"}</td>
    <td>${boxes}</td>
    <td>Yes / No</td>
    <td>${record.comments || ""}</td>
  </tr>
</tbody>
      </table>
      <div class="release-log-signature">
<span>QP Signature:</span>
<span>Release Date:</span>
      </div>
    </section>
  `;
}

function renderPreQpReleaseLogPrintPreview(products) {
  const rows = products.map((product) => {
    const record = preQpRecords[product.batch] || {};
    const postRecord = postAssemblyRecords[product.batch] || {};
    const totalQty = postRecord.totalQty || product.quantity;
    const boxes = postRecord.boxCount || Math.max(1, Math.ceil(Number(product.quantity || 0) / 100));
    const yieldQty = Math.max(0, Number(totalQty || 0) - 1);
    return `
  <tr>
    <td>${product.product}<br>${product.strength}</td>
    <td>${product.batch}<br>${product.expiry}</td>
    <td>${product.country}</td>
    <td>${product.manufacturingLot || "25088FA"} / ${totalQty} / ${product.imp || "C13278"}</td>
    <td>${totalQty}</td>
    <td>01</td>
    <td></td>
    <td>${yieldQty}</td>
    <td>${productionRecords[product.batch] ? productionRecords[product.batch].roomNo : "3"}</td>
    <td>${boxes}</td>
    <td>Yes / No</td>
    <td>${record.comments || ""}</td>
  </tr>
    `;
  }).join("");
  return `
    <section class="release-log-preview">
      <div class="release-log-brand">B&S HEALTHCARE</div>
      <table class="release-log-table">
<thead>
  <tr>
    <th>Product</th>
    <th>B&S Batch No. / Exp Date</th>
    <th>Country of Origin</th>
    <th>Manufacturer Batch Number / Quantity / IMP</th>
    <th>QTY Issued</th>
    <th>Ret. Sample</th>
    <th>Damaged / Reg. Sample</th>
    <th>Yield</th>
    <th>Room No</th>
    <th>Boxes</th>
    <th>Approved</th>
    <th>Comments</th>
  </tr>
</thead>
<tbody>${rows}</tbody>
      </table>
      <div class="release-log-signature">
<span>QP Signature:</span>
<span>Release Date:</span>
      </div>
    </section>
  `;
}

function openPreQpReleaseLogPrintPreview() {
  const selectedProducts = preQpReleaseLogSelection
    .map((batch) => bnsProducts.find((product) => product.batch === batch))
    .filter((product) => product && preQpCheckedBatchNumbers.includes(product.batch));
  if (!selectedProducts.length) {
    statusMessage.textContent = "Select at least one verified Pre QP batch to print the QP Release Log.";
    return;
  }
  printPreviewRequest = { type: "preqp-release-log", batches: selectedProducts.map((product) => product.batch) };
  document.querySelector("#print-preview-title").textContent = "QP Release Log";
  printPreviewBody.innerHTML = `
    <div class="release-log-modal-shell">
      <div class="preview-toolbar">
<div>
  <strong>QP Release Log Preview</strong>
  <span>${selectedProducts.length} product${selectedProducts.length === 1 ? "" : "s"} selected</span>
</div>
<button class="classic-button" type="button" data-close-print-preview>Close</button>
<button class="classic-button primary" type="button" id="preview-print-button">Print</button>
      </div>
      ${renderPreQpReleaseLogPrintPreview(selectedProducts)}
    </div>
  `;
  printPreviewModal.classList.remove("hidden");
  statusMessage.textContent = "QP Release Log preview opened.";
}
function getQpReleaseLogDefaults(product) {
  const postRecord = postAssemblyRecords[product.batch] || {};
  const preQpRecord = preQpRecords[product.batch] || {};
  const existingLog = qpReleaseRecords[product.batch] && qpReleaseRecords[product.batch].releaseLog ? qpReleaseRecords[product.batch].releaseLog : {};
  const totalQty = postRecord.totalQty || product.quantity;
  return {
    product: existingLog.product || product.product,
    batch: existingLog.batch || product.batch,
    expiry: existingLog.expiry || product.expiry,
    country: existingLog.country || product.country,
    manufacturerDetails: existingLog.manufacturerDetails || `${product.manufLotNo || product.manufacturingLot || "25088FA"} / ${totalQty} / ${product.imp || "C13278"}`,
    qtyIssued: existingLog.qtyIssued || totalQty,
    retentionSample: existingLog.retentionSample || "01",
    damagedSample: existingLog.damagedSample || "",
    yieldQty: existingLog.yieldQty || getQpDefaultYield(product),
    roomNo: existingLog.roomNo || (productionRecords[product.batch] ? productionRecords[product.batch].roomNo : "3"),
    boxes: existingLog.boxes || (postRecord.boxCount || Math.max(1, Math.ceil(Number(product.quantity || 0) / 100))),
    approved: existingLog.approved || "Yes",
    comments: existingLog.comments || preQpRecord.comments || "",
    qpSignature: existingLog.qpSignature || "",
    releaseDate: existingLog.releaseDate || "",
    signedBy: existingLog.signedBy || "",
    signedDateTime: existingLog.signedDateTime || ""
  };
}

function renderPreQpWork(stage) {
  if (!preQpSelectedProduct) return renderPreQpList();
  const product = preQpSelectedProduct;
  const record = preQpRecords[product.batch] || {};
  const logGenerated = Boolean(record.logGenerated);
  return `
    <div class="preqp-layout">
      <section class="preqp-window preqp-detail-window">
<div class="sub-window-title">Pre QP</div>
${renderBatchDetails(product)}

<div class="system-panel">
  <div class="panel-title">QA Checking</div>
  <div class="preqp-sample-row preqp-sample-inline-row">
    <label><span>Random sample taken from box number</span><input id="preqp-sample-box" data-preqp-input value="${record.sampleBox || "01"}"></label>
  </div>
  <div class="preqp-doc-list">
    ${[
      "Supplier invoice and PCL",
      "Mock UP and Braille Verification Sheet",
      "Sample with backing-paper (if applicable)",
      "Foreign Leaflet",
      "Change of pack size form (if applicable)",
      "Foreign Carton (if applicable)"
    ].map((item, index) => `
      <div class="preqp-doc-card" data-preqp-doc-row>
<div class="preqp-doc-name">
  <span>Document</span>
  <strong>${item}</strong>
</div>
<button class="classic-button" type="button" data-view-preqp-document="${item}">View File</button>
<div class="preqp-choice-group" aria-label="${item} check result">
  <label><input type="checkbox" data-preqp-doc-check data-preqp-doc-index="${index}" value="Yes" ${record.docs && record.docs[index] === "Yes" ? "checked" : ""}> Yes</label>
  <label><input type="checkbox" data-preqp-doc-check data-preqp-doc-index="${index}" value="No" ${record.docs && record.docs[index] === "No" ? "checked" : ""}> No</label>
</div>
<label class="preqp-doc-comment">Comments <input data-preqp-input value="${record.docComments && record.docComments[index] ? record.docComments[index] : ""}"></label>
      </div>
    `).join("")}
  </div>
</div>

<div class="system-panel">
  <div class="panel-title">Confirm Correct Material Has Been Used</div>
  <table class="recon-clean-table preqp-material-table">
    <thead><tr><th>Type of Label</th><th>Reference Code</th><th>Checked & Confirmed</th></tr></thead>
    <tbody>
      ${[
["Carton / Braille Label 1", "FLU250-10/120/CZ (R4)"],
["Blister Label 1", "FLU250-10/120/CZ/B1 (R3)"],
["Blister/Carton 2", "FLU250-10/120/CZ/B2 (R3)"],
["Leaflet 1", "FLU250-10/120/CZ/LT (R5)"],
["Other", "Blank Label"]
      ].map(([label, ref]) => `
<tr>
  <td>${label}</td>
  <td>${ref}</td>
  <td><label class="compact-tick"><input type="checkbox" data-preqp-material-check ${record.materialChecked ? "checked disabled" : ""}> Confirmed</label></td>
</tr>
      `).join("")}
    </tbody>
  </table>
</div>

<label class="postassembly-comment">Comments <textarea id="preqp-comments" data-preqp-input>${record.comments || ""}</textarea></label><div class="signature-grid">
  <label>Pre-QP Checker <input value="${currentLogin ? currentLogin.user : stage.user}" readonly></label>
  <label>Date / Time <input value="${record.dateTime || "Pending sign off"}" readonly></label>
  <div class="signoff-action process-signoff-action">
    <button class="classic-button primary" type="button" id="preqp-complete-button" disabled>User Sign Off</button>
  </div>
</div>
      </section>
    </div>
  `;
}

function updatePreQpAvailability() {
  const submitButton = document.querySelector("#preqp-complete-button");
  if (!submitButton || !preQpSelectedProduct) return;
  const sampleBox = document.querySelector("#preqp-sample-box");
  const docRows = [...document.querySelectorAll("[data-preqp-doc-row]")];
  const docsComplete = docRows.length > 0 && docRows.every((row) => row.querySelector("[data-preqp-doc-check]:checked"));
  const materialChecks = [...document.querySelectorAll("[data-preqp-material-check]")];
  const materialsComplete = materialChecks.length > 0 && materialChecks.every((check) => check.checked);
  const readyToGenerate = Boolean(sampleBox && sampleBox.value.trim() && docsComplete && materialsComplete);
  submitButton.disabled = !readyToGenerate;
}

function collectPreQpFormState() {
  const docRows = [...document.querySelectorAll("[data-preqp-doc-row]")];
  return {
    sampleBox: document.querySelector("#preqp-sample-box") ? document.querySelector("#preqp-sample-box").value : "",
    docs: docRows.map((row) => {
      const checked = row.querySelector("[data-preqp-doc-check]:checked");
      return checked ? checked.value : "";
    }),
    docComments: docRows.map((row) => {
      const input = row.querySelector("input[data-preqp-input]");
      return input ? input.value : "";
    }),
    materialChecked: [...document.querySelectorAll("[data-preqp-material-check]")].every((check) => check.checked),
    comments: document.querySelector("#preqp-comments") ? document.querySelector("#preqp-comments").value : ""
  };
}

function openPreQpDocumentPreview(documentName) {
  const previewProduct = currentStageId === "qp-release" ? qpSelectedProduct : preQpSelectedProduct || qpSelectedProduct;
  document.querySelector("#print-preview-title").textContent = documentName;
  printPreviewRequest = null;
  printPreviewBody.innerHTML = `
    <div class="document-preview-shell">
      <div class="preview-toolbar">
<strong>${documentName}</strong>
<button class="classic-button" type="button" data-close-print-preview>Close</button>
      </div>
      <section class="document-preview-page">
<div class="document-preview-header">
  <span>B&S Healthcare</span>
  <strong>${documentName}</strong>
  <span>Batch ${previewProduct ? previewProduct.batch : ""}</span>
</div>
<div class="document-preview-content">
  <div class="document-line wide"></div>
  <div class="document-line"></div>
  <div class="document-line short"></div>
  <table class="document-preview-table">
    <tbody>
      <tr><th>Product</th><td>${previewProduct ? previewProduct.product : ""}</td></tr>
      <tr><th>Reference</th><td>${previewProduct ? previewProduct.ecma : ""}</td></tr>
      <tr><th>Status</th><td>Available for QA checking</td></tr>
    </tbody>
  </table>
  <div class="document-stamp">FILE PREVIEW</div>
</div>
      </section>
    </div>
  `;
  printPreviewModal.classList.remove("hidden");
}

function openPreQpReleaseLogModal(product, record, stage, showProceed = true) {
  document.querySelector("#print-preview-title").textContent = "QP Release Log";
  printPreviewRequest = null;
  printPreviewBody.innerHTML = `
    <div class="release-log-modal-shell">
      <div class="preview-toolbar">
<strong>QP Release Log Preview</strong>
<button class="classic-button" type="button" data-close-print-preview>Close</button>
      </div>
      ${renderReleaseLogPreview(product, record, stage)}
      ${showProceed ? `
<div class="release-log-modal-actions">
  <button class="classic-button primary" type="button" id="preqp-proceed-log-button">Proceed to Generate</button>
</div>
      ` : ""}
    </div>
  `;
  printPreviewModal.classList.remove("hidden");
}

function previewPreQpReleaseLog() {
  if (!preQpSelectedProduct) return;
  const batchNumber = preQpSelectedProduct.batch;
  const stage = findStage("pre-qp");
  const nextRecord = {
    ...(preQpRecords[batchNumber] || {}),
    ...collectPreQpFormState()
  };
  preQpRecords[batchNumber] = {
    ...nextRecord,
    logPreviewOpen: true
  };
  openPreQpReleaseLogModal(preQpSelectedProduct, nextRecord, stage);
  statusMessage.textContent = `QP Release Log preview opened for ${batchNumber}.`;
}

function proceedGeneratePreQpReleaseLog() {
  if (!preQpSelectedProduct) return;
  const batchNumber = preQpSelectedProduct.batch;
  preQpRecords[batchNumber] = {
    ...(preQpRecords[batchNumber] || {}),
    ...collectPreQpFormState(),
    logPreviewOpen: true,
    logGenerated: true,
  };
  closePrintPreview();
  statusMessage.textContent = `QP Release Log generated and ready for ${batchNumber}.`;
  renderStage("pre-qp");
}

function completePreQp() {
  if (!preQpSelectedProduct) return;
  const batchNumber = preQpSelectedProduct.batch;
  const now = getAssemblyAuditTimestamp();
  preQpRecords[batchNumber] = {
    ...(preQpRecords[batchNumber] || {}),
    ...collectPreQpFormState(),
    user: currentLogin ? currentLogin.user : "pre.qp",
    dateTime: now,
    materialChecked: true,
    logGenerated: true
  };
  if (!preQpCheckedBatchNumbers.includes(batchNumber)) preQpCheckedBatchNumbers.push(batchNumber);
  statusMessage.textContent = `Batch ${batchNumber} moved to QP Release.`;
  window.setTimeout(() => {
    preQpSelectedProduct = null;
    renderStage("pre-qp");
  }, 900);
}

function getQpBatchDecision(product) {
  const record = qpReleaseRecords[product.batch] || {};
  if (record.approved || qpReleasedBatchNumbers.includes(product.batch)) return "Certified";
  if (record.decision === "Hold") return "Hold";
  if (record.decision === "Rejected") return "Rejected";
  if (record.decision === "Approve") return "Approved";
  return getQpReleaseLogId(product.batch) ? "QP Log Generated" : "Pending QP Review";
}

function setQpBatchDecision(decision) {
  if (!qpSelectedProduct) return;
  const batchNumber = qpSelectedProduct.batch;
  qpReleaseRecords[batchNumber] = {
    ...(qpReleaseRecords[batchNumber] || {}),
    decision,
    decisionBy: currentLogin ? currentLogin.user : "qp.release",
    decisionDateTime: getAssemblyAuditTimestamp()
  };
  if (decision === "Approve") {
    qpChecklistOpen = true;
    statusMessage.textContent = `Batch ${batchNumber} approved for QP checklist.`;
  } else if (decision === "Hold") {
    if (!qpCertifiedBatchNumbers.includes(batchNumber)) qpCertifiedBatchNumbers.push(batchNumber);
    qpSelectedProduct = null;
    qpChecklistOpen = false;
    statusMessage.textContent = `Batch ${batchNumber} placed on hold and recorded in QP Certified Batches.`;
  } else if (decision === "Rejected") {
    if (!qpCertifiedBatchNumbers.includes(batchNumber)) qpCertifiedBatchNumbers.push(batchNumber);
    qpSelectedProduct = null;
    qpChecklistOpen = false;
    statusMessage.textContent = `Batch ${batchNumber} rejected and recorded in QP Certified Batches.`;
  }
  renderStage("qp-release");
}
function getQpReleaseProducts() {
  ensurePreQpTestData();
  const sourceProducts = bnsProducts.filter((product) => preQpCheckedBatchNumbers.includes(product.batch));
  const normalizedQpIdSearch = qpIdSearch.trim().toLowerCase();
  const normalizedBatchSearch = qpBatchSearch.trim().toLowerCase();
  const normalizedStatusSearch = qpStatusSearch.trim().toLowerCase();
  return sourceProducts.filter((product) => {
    const record = qpReleaseRecords[product.batch] || {};
    const decision = getQpBatchDecision(product);
    if (!(record.qpReady || record.qpId || record.decision || record.approved || qpReleasedBatchNumbers.includes(product.batch))) return false;
    const qpId = getQpReleaseLogId(product.batch).toLowerCase();
    const batch = String(product.batch || "").toLowerCase();
    const qpIdMatches = !normalizedQpIdSearch || qpId.includes(normalizedQpIdSearch);
    const batchMatches = !normalizedBatchSearch || batch.includes(normalizedBatchSearch);
    const statusMatches = !normalizedStatusSearch || decision.toLowerCase() === normalizedStatusSearch;
    return qpIdMatches && batchMatches && statusMatches;
  });
}
function getQpDocumentPack(product) {
  const postRecord = postAssemblyRecords[product.batch] || {};
  return [
    { id: "po-packing-list", group: "RPi Documents", name: "PO Packing List", source: "PLPI", status: "Mandatory", ref: product.pl || product.partNo || "Generated" },
    { id: "supplier-declaration", group: "RPi Documents", name: "Supplier Declaration", source: "Supplier", status: "Mandatory", ref: product.supplierName || "Supplier declaration" },
    { id: "supplier-packing-list", group: "RPi Documents", name: "Supplier Packing List", source: "Supplier", status: "Mandatory", ref: product.partNo || "Uploaded" },
    { id: "supplier-invoice", group: "RPi Documents", name: "Supplier Invoice", source: "Supplier", status: "Mandatory", ref: product.invoice || product.supplierInvoice || "Uploaded" },
    { id: "temperature-record", group: "RPi Documents", name: "Temperature Record", source: "VTS / Upload", status: "Mandatory", ref: "Within range" },
    { id: "pcl", group: "Batch Checking", name: "PCL", source: "PLPI", status: "Mandatory", ref: "PCL approved" },
    { id: "goods-checklist", group: "Goods-In", name: "Goods-In Checklist", source: "Goods-In", status: "Mandatory", ref: product.country || "Received" },
    { id: "batch-summary", group: "Batch Record", name: "Batch Record Summary", source: "Assembly Room", status: "Mandatory", ref: `Yield ${Math.max(0, Number(postRecord.totalQty || product.quantity || 0) - 1)}` },
    { id: "release-log", group: "Pre-QP", name: "QP Release Log", source: "Pre-QP", status: "Mandatory", ref: "Ready for QP" }
  ];
}
function getQpDefaultYield(product) {
  const postRecord = postAssemblyRecords[product.batch] || {};
  return String(Math.max(0, Number(postRecord.totalQty || product.quantity || 0) - 1));
}

function renderQpReleaseWork(stage) {
  if (!qpSelectedProduct) return renderQpDashboard(stage);
  return qpChecklistOpen ? renderQpChecklistWindow(stage) : renderQpSelectedDashboard(stage);
}

function getQpDecisionRowClass(decision) {
  if (decision === "Certified" || decision === "Approved") return "preqp-row-approved preqp-row-verified";
  if (decision === "Hold") return "preqp-row-on-hold qp-hold-row";
  if (decision === "Rejected") return "qp-row-rejected";
  return "preqp-row-white";
}

function renderQpDashboard(stage) {
  ensurePreQpTestData();
  const isCertifiedModule = stage && stage.id === "qp-certified";
  const normalizedQpIdSearch = qpIdSearch.trim().toLowerCase();
  const normalizedBatchSearch = qpBatchSearch.trim().toLowerCase();
  const normalizedStatusSearch = qpStatusSearch.trim().toLowerCase();
  const toQpRow = (product, index) => {
    const record = qpReleaseRecords[product.batch] || {};
    const decision = getQpBatchDecision(product);
    const qpId = getQpReleaseLogId(product.batch) || "Pending Print";
    return {
      relId: String(38940 + index),
      qpId,
      releasedOn: record.decisionDateTime || record.dateTime || record.qpLogGeneratedAt || "Pending",
      releaseFor: product.country || "UK",
      description: product.description || product.product,
      strength: product.strength || "-",
      packSize: product.packSize || "-",
      batch: product.batch,
      manufLotNo: getMfgLotNo(product) || "-",
      expiry: product.expiry || "-",
      quantity: product.quantity || "-",
      decision,
      decisionBy: record.decisionBy || record.user || "-",
      product
    };
  };
  const matchesQpFilters = (product) => {
    const qpId = String(product.qpId || "").toLowerCase();
    const batch = String(product.batch || "").toLowerCase();
    const status = String(product.decision || "").toLowerCase();
    return (!normalizedQpIdSearch || qpId.includes(normalizedQpIdSearch)) &&
      (!normalizedBatchSearch || batch.includes(normalizedBatchSearch)) &&
      (!normalizedStatusSearch || status === normalizedStatusSearch);
  };
  const dashboardProducts = isCertifiedModule ? [] : getQpReleaseProducts()
    .filter((product) => !qpCertifiedBatchNumbers.includes(product.batch))
    .map(toQpRow)
    .filter(matchesQpFilters);
  const certifiedProducts = !isCertifiedModule ? [] : qpCertifiedBatchNumbers
    .map((batchNumber, index) => {
      const product = bnsProducts.find((item) => item.batch === batchNumber);
      return product ? toQpRow(product, index) : null;
    })
    .filter(Boolean)
    .filter(matchesQpFilters);
  const dashboardQuantity = dashboardProducts.reduce((total, product) => total + Number(product.quantity || 0), 0);
  const totalQuantity = certifiedProducts.reduce((total, product) => total + Number(product.quantity || 0), 0);
  qpCertifiedLabelSelection = qpCertifiedLabelSelection.filter((batchNumber) =>
    certifiedProducts.some((product) => product.batch === batchNumber && (product.decision === "Certified" || product.decision === "Approved"))
  );
  const certifiedCount = certifiedProducts.filter((product) => product.decision === "Certified").length;
  const holdCount = certifiedProducts.filter((product) => product.decision === "Hold").length;
  const renderQpRows = (products, emptyText, clickable = false) => products.map((product) => {
    const rowClass = getQpDecisionRowClass(product.decision);
    const openAttr = clickable ? ` data-open-qp="${product.batch}"` : "";
    const clickClass = clickable ? "clickable-row " : "";
    const canPrintReleaseLabel = product.decision === "Certified" || product.decision === "Approved";
    const selectCell = isCertifiedModule
      ? `<input type="checkbox" data-qp-certified-label-select="${product.batch}" ${qpCertifiedLabelSelection.includes(product.batch) ? "checked" : ""} ${canPrintReleaseLabel ? "" : "disabled"}>`
      : `<input type="checkbox" ${product.decision === "Certified" ? "checked" : ""} readonly>`;
    return `
      <tr class="${clickClass}${rowClass}"${openAttr}>
        <td style="text-align: center;">${selectCell}</td>
        <td><strong>${product.qpId}</strong></td>
        <td>${product.releasedOn}</td>
        <td>${product.releaseFor}</td>
        <td>${product.description}</td>
        <td>${product.strength}</td>
        <td>${product.packSize}</td>
        <td><strong>${product.batch}</strong></td>
        <td class="mfg-lot-col">${product.manufLotNo}</td>
        <td>${product.expiry}</td>
        <td>${product.quantity}</td>
        <td><span class="status ${product.decision === "Hold" ? "hold-status" : product.decision === "Rejected" ? "rejected-status" : product.decision === "Certified" ? "ready-status" : "active-status"}">${product.decision}</span></td>
        <td>${clickable ? "QP Release" : product.decisionBy}</td>
      </tr>
    `;
  }).join("") || `<tr><td colspan="13">${emptyText}</td></tr>`;
  const dashboardSection = isCertifiedModule ? "" : `
<div class="preqp-list-panel qp-certified-list-panel" style="margin-bottom: 14px;">
  <div class="qp-certified-title">QP Dashboard - Awaiting QP Decision</div>
  <table class="classic-table product-grid preqp-table qp-certified-table">
    <thead>
      <tr><th style="width: 44px;">Select</th><th>QP ID</th><th>Printed On</th><th>RELEASE_FOR</th><th>DESCRIPTION</th><th>STRENGTH</th><th>PACK_SIZE</th><th>BNS_BATCH_NO</th><th class="mfg-lot-col">MFG_LOT_NO</th><th>EXPIRY_DATE</th><th>QUANTITY</th><th>QP STATUS</th><th>OWNER</th></tr>
    </thead>
    <tbody>${renderQpRows(dashboardProducts, "No batches waiting for QP decision.", true)}</tbody>
  </table>
  <div style="display: flex; justify-content: flex-end; gap: 40px; margin-top: 8px; font-size: 11px; font-weight: normal; color: #000; font-family: Tahoma, sans-serif;">
    <span>Waiting Batches : <strong>${dashboardProducts.length}</strong></span>
    <span>Total Quantity : <strong>${dashboardQuantity}</strong></span>
  </div>
</div>`;
  const certifiedSection = !isCertifiedModule ? "" : `
<div class="preqp-list-panel qp-certified-list-panel">
  <div class="qp-certified-title">QP Certified Batches</div>
  <table class="classic-table product-grid preqp-table qp-certified-table">
    <thead>
      <tr><th style="width: 44px;">Select</th><th>QP ID</th><th>Decision Date</th><th>RELEASE_FOR</th><th>DESCRIPTION</th><th>STRENGTH</th><th>PACK_SIZE</th><th>BNS_BATCH_NO</th><th class="mfg-lot-col">MFG_LOT_NO</th><th>EXPIRY_DATE</th><th>QUANTITY</th><th>QP STATUS</th><th>DECISION_BY</th></tr>
    </thead>
    <tbody>${renderQpRows(certifiedProducts, "No QP approved, rejected, or held batches available yet.")}</tbody>
  </table>
  <div style="display: flex; justify-content: flex-end; gap: 40px; margin-top: 8px; font-size: 11px; font-weight: normal; color: #000; font-family: Tahoma, sans-serif;">
    <span>Total Batches : <strong>${certifiedProducts.length}</strong></span>
    <span>Certified : <strong>${certifiedCount}</strong></span>
    <span>Hold : <strong>${holdCount}</strong></span>
    <span>Total Quantity : <strong>${totalQuantity}</strong></span>
  </div>
</div>`;
  return `
    <div class="preqp-layout qp-certified-layout">
      <section class="preqp-window preqp-list-window qp-certified-window" style="padding: 15px;">
<div style="text-align: center; font-size: 16px; font-weight: bold; margin-bottom: 12px; font-family: Tahoma, sans-serif;">${isCertifiedModule ? "QP Certified Batches" : "QP Release Dashboard"}</div>
<div class="preqp-search-row qp-certified-search-row" style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px; flex-wrap: wrap;">
  <label class="classic-search-label" style="font-size: 11px;">QP ID : <input class="classic-search-input" data-qp-id-search style="width: 105px;" value="${qpIdSearch}" placeholder=""></label>
  <label class="classic-search-label" style="font-size: 11px;">BNS Batch No : <input class="classic-search-input" data-qp-batch-search style="width: 110px;" value="${qpBatchSearch}" placeholder=""></label>
  <label class="classic-search-label" style="font-size: 11px;">QP Status : <select data-qp-status-search style="min-height: 22px; width: 120px;"><option></option><option ${qpStatusSearch === "Certified" ? "selected" : ""}>Certified</option><option ${qpStatusSearch === "Approved" ? "selected" : ""}>Approved</option><option ${qpStatusSearch === "Rejected" ? "selected" : ""}>Rejected</option><option ${qpStatusSearch === "Hold" ? "selected" : ""}>Hold</option></select></label>
  <button class="classic-search-button" type="button" data-qp-search-button>Search</button>
</div>
${dashboardSection}
${certifiedSection}
<div class="preqp-actions-row" style="display: flex; align-items: center; justify-content: space-between; margin-top: 15px; padding-top: 10px; border-top: 1px solid #c0c0c0; font-family: Tahoma, sans-serif;">
  <div style="display: flex; gap: 15px; align-items: center;">
    <span style="display: inline-flex; align-items: center; gap: 4px; font-size: 11px; font-weight: bold; color: #27ae60;"><span style="width: 8px; height: 8px; border-radius: 50%; background: #27ae60; border: 1px solid #1e7e43; display: inline-block;"></span> Certified / Approved</span>
    <span style="display: inline-flex; align-items: center; gap: 4px; font-size: 11px; font-weight: bold; color: #b42318;"><span style="width: 8px; height: 8px; border-radius: 50%; background: #ffe1e1; border: 1px solid #b42318; display: inline-block;"></span> Rejected</span>
    <span style="display: inline-flex; align-items: center; gap: 4px; font-size: 11px; font-weight: bold; color: #8a5a00;"><span style="width: 8px; height: 8px; border-radius: 50%; background: #fff1d4; border: 1px solid #c98a00; display: inline-block;"></span> Hold</span>
  </div>
  <div style="display: flex; gap: 10px;">
    ${isCertifiedModule ? `<button class="classic-button primary" type="button" data-print-release-label ${qpCertifiedLabelSelection.length ? "" : "disabled"}>Print Release Label</button>` : `<button class="classic-button" type="button">Batch History</button><button class="classic-button" type="button" data-preqp-reprint-log>Reprint QP Certified Batch</button>`}
  </div>
</div>
      </section>
    </div>
  `;
}function renderQpSelectedDashboard(stage) {
  const product = qpSelectedProduct;
  const record = qpReleaseRecords[product.batch] || {};
  const documents = getQpDocumentPack(product);
  const verifiedCount = documents.filter((document) => record.documents && record.documents[document.id]).length;
  const allVerified = verifiedCount === documents.length && documents.length > 0;
  return `
    <div class="qp-release-layout qp-review-dashboard-layout">
      <section class="qp-release-window qp-release-detail-window qp-review-dashboard">
        <div class="qp-review-hero">
          <div>
            <button class="classic-button qp-review-back" type="button" data-qp-back-list>Back to QP List</button>
            <h2>QP Release Dashboard - ${product.batch}</h2>
            <p>Review each batch document before opening the QP release decision.</p>
          </div>
          <span class="qp-review-status ${allVerified ? "ready" : "pending"}">${allVerified ? "READY FOR QP DECISION" : "PENDING QP REVIEW"}</span>
        </div>
        <section class="qp-review-documents-panel">
          <div class="qp-review-section-title">QP Release Documents</div>
          <div class="qp-review-doc-grid">
            ${documents.map((document, index) => {
              const verified = record.documents && record.documents[document.id];
              return `
                <article class="qp-review-doc-card ${verified ? "verified" : "pending"}">
                  <div class="qp-review-doc-icon" aria-hidden="true"></div>
                  <span class="qp-review-doc-number">${String(index + 1).padStart(2, "0")}</span>
                  <strong>${document.name}</strong>
                  <small>${document.group} | ${document.ref}</small>
                  <em>${verified ? "VERIFIED" : "PENDING VIEW"}</em>
                  <button class="classic-button" type="button" data-view-qp-document="${document.id}">View File</button>
                  <label class="qp-review-check"><input type="checkbox" data-qp-doc-check="${document.id}" ${verified ? "checked" : ""}> Verified</label>
                </article>
              `;
            }).join("")}
          </div>
        </section>
        <div class="qp-release-actions qp-dashboard-actions qp-decision-actions qp-review-action-bar">
          <div class="qp-review-progress"><strong>${verifiedCount}/${documents.length}</strong> documents verified</div>
          <div class="qp-review-action-buttons">
            <button class="classic-button primary" type="button" data-qp-approve-batch>Approve Batch</button>
            <button class="classic-button danger" type="button" data-qp-reject-batch>Reject Batch</button>
            <button class="classic-button" type="button" data-qp-hold-batch>Hold Batch</button>
          </div>
        </div>
      </section>
    </div>
  `;
}

function renderQpChecklistWindow(stage) {
  const product = qpSelectedProduct;
  const record = qpReleaseRecords[product.batch] || {};
  const quantityReleased = record.quantityReleased || getQpDefaultYield(product);
  const releaseLogSigned = Boolean(record.releaseLog && record.releaseLog.signedDateTime);
  return `
    <div class="qp-release-layout">
      <section class="qp-release-window qp-release-detail-window qp-checklist-window">
        <div class="qp-selected-header">
          <button class="classic-button" type="button" data-qp-back-dashboard>Back to Dashboard</button>
          <div><span>QP Release Checklist</span><h2>${product.batch}</h2><p>${product.product}</p></div>
          <div class="qp-dashboard-status ready"><span>Documents</span><strong>Verified</strong></div>
        </div>
        ${renderBatchDetails(product)}
        <section class="qp-sentencing-panel qp-checklist-panel">
          <div class="panel-title">Batch Sentencing Checklist</div>
          <div class="qp-form-grid">
            <label>Retention sample lot no.<input data-qp-input id="qp-retention-lot" value="${record.retentionLot || product.manufLotNo || "25088FA"}"></label>
            <label>Quantity released<input data-qp-input id="qp-quantity-released" value="${quantityReleased}"></label>
            <label>Release date / time<input value="${record.dateTime || "Captured at QP sign off"}" readonly></label>
          </div>
          <label class="qp-declaration-check"><input type="checkbox" data-qp-input id="qp-declaration" ${record.declarationAccepted ? "checked" : ""}> I certify this is a true and accurate record, assembled at Gowrie Laxmico Ltd T/A B&S Healthcare, and found to comply with marketing authorisation and GMP requirements.</label>
          <div class="qp-form-grid">
            <label>Surplus printed packaging material<select data-qp-input id="qp-surplus-status"><option ${record.surplusStatus === "Destroyed after QP certification" ? "selected" : ""}>Destroyed after QP certification</option><option ${record.surplusStatus === "Not applicable" ? "selected" : ""}>Not applicable</option></select></label>
            <label>Destroyed by / date<input data-qp-input id="qp-destroyed-by" value="${record.destroyedBy || ""}" placeholder="Name and date if applicable"></label>
          </div>
          <label class="qp-comment-box">QP Comments<textarea id="qp-release-comment" data-qp-input>${record.comments || ""}</textarea></label>
          <div class="qp-release-actions">
            <button class="classic-button" type="button" data-view-qp-release-log>Preview QP Release Log</button>
            <span>${releaseLogSigned ? "QP Release Log signed." : "Preview the QP Release Log if required before final approval."}</span>
          </div>
        </section>
        <div class="signature-grid">
          <label>QP User <input value="${currentLogin ? currentLogin.user : stage.user}" readonly></label>
          <label>Release Date / Time <input value="${record.dateTime || "Pending QP approval"}" readonly></label>
          <div class="signoff-action process-signoff-action"><button class="classic-button primary" type="button" id="qp-release-complete-button" disabled>Approve Batch / Sign Off</button></div>
        </div>
      </section>
    </div>
  `;
}

function areAllQpDashboardDocumentsVerified(product) {
  const record = qpReleaseRecords[product.batch] || {};
  const documents = getQpDocumentPack(product);
  return documents.length > 0 && documents.every((document) => record.documents && record.documents[document.id]);
}

function updateQpReleaseAvailability() {
  const submitButton = document.querySelector("#qp-release-complete-button");
  if (!qpSelectedProduct) return;
  const documents = getQpDocumentPack(qpSelectedProduct);
  const checkedDocs = [...document.querySelectorAll("[data-qp-doc-check]")];
  if (checkedDocs.length) {
    const batchNumber = qpSelectedProduct.batch;
    const previous = qpReleaseRecords[batchNumber] || {};
    const documentsState = { ...(previous.documents || {}) };
    checkedDocs.forEach((check) => { documentsState[check.dataset.qpDocCheck] = check.checked; });
    qpReleaseRecords[batchNumber] = { ...previous, documents: documentsState };
    const openChecklist = document.querySelector("[data-qp-open-checklist]");
    if (openChecklist) openChecklist.disabled = !documents.every((document) => documentsState[document.id]);
  }
  if (!submitButton) return;
  const record = qpReleaseRecords[qpSelectedProduct.batch] || {};
  const declarationAccepted = document.querySelector("#qp-declaration");
  const quantityReleased = document.querySelector("#qp-quantity-released");
  const surplusStatus = document.querySelector("#qp-surplus-status");
  submitButton.disabled = !(areAllQpDashboardDocumentsVerified(qpSelectedProduct) && declarationAccepted && declarationAccepted.checked && quantityReleased && quantityReleased.value.trim() && surplusStatus && surplusStatus.value);
}
function collectQpReleaseState() {
  const existingRecord = qpSelectedProduct ? qpReleaseRecords[qpSelectedProduct.batch] || {} : {};
  const documents = { ...(existingRecord.documents || {}) };
  document.querySelectorAll("[data-qp-doc-check]").forEach((check) => {
    documents[check.dataset.qpDocCheck] = check.checked;
  });
  return {
    documents,
    retentionLot: document.querySelector("#qp-retention-lot") ? document.querySelector("#qp-retention-lot").value : "",
    quantityReleased: document.querySelector("#qp-quantity-released") ? document.querySelector("#qp-quantity-released").value : "",
    declarationAccepted: document.querySelector("#qp-declaration") ? document.querySelector("#qp-declaration").checked : false,
    surplusStatus: document.querySelector("#qp-surplus-status") ? document.querySelector("#qp-surplus-status").value : "",
    destroyedBy: document.querySelector("#qp-destroyed-by") ? document.querySelector("#qp-destroyed-by").value : "",
    comments: document.querySelector("#qp-release-comment") ? document.querySelector("#qp-release-comment").value : ""
  };
}

function collectQpReleaseLogState() {
  const values = {};
  document.querySelectorAll("[data-qp-log-field]").forEach((field) => {
    values[field.dataset.qpLogField] = field.value;
  });
  const batchExpiry = (values.batch || "").split("\n");
  return {
    ...values,
    batch: batchExpiry[0] || (qpSelectedProduct ? qpSelectedProduct.batch : ""),
    expiry: batchExpiry[1] || (qpSelectedProduct ? qpSelectedProduct.expiry : "")
  };
}

function saveQpReleaseLog() {
  if (!qpSelectedProduct) return;
  const batchNumber = qpSelectedProduct.batch;
  qpReleaseRecords[batchNumber] = {
    ...(qpReleaseRecords[batchNumber] || {}),
    releaseLog: {
      ...(qpReleaseRecords[batchNumber] && qpReleaseRecords[batchNumber].releaseLog ? qpReleaseRecords[batchNumber].releaseLog : {}),
      ...collectQpReleaseLogState()
    }
  };
  statusMessage.textContent = `QP Release Log changes saved for ${batchNumber}.`;
  updateQpReleaseAvailability();
}

function signQpReleaseLog() {
  if (!qpSelectedProduct) return;
  const batchNumber = qpSelectedProduct.batch;
  const now = getAssemblyAuditTimestamp();
  const releaseDate = new Date().toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  });
  qpReleaseRecords[batchNumber] = {
    ...(qpReleaseRecords[batchNumber] || {}),
    releaseLog: {
      ...(qpReleaseRecords[batchNumber] && qpReleaseRecords[batchNumber].releaseLog ? qpReleaseRecords[batchNumber].releaseLog : {}),
      ...collectQpReleaseLogState(),
      qpSignature: currentLogin ? currentLogin.user : "qp.release",
      releaseDate,
      signedBy: currentLogin ? currentLogin.user : "qp.release",
      signedDateTime: now
    }
  };
  statusMessage.textContent = `QP Release Log signed off for ${batchNumber}. Final batch approval is now available.`;
  printPreviewModal.classList.add("hidden");
  renderStage("qp-release");
}

function openQpDocumentPreview(documentId) {
  if (!qpSelectedProduct) return;
  const document = getQpDocumentPack(qpSelectedProduct).find((item) => item.id === documentId);
  if (!document) return;
  openPreQpDocumentPreview(`${document.group} - ${document.name}`);
}

function openQpReleaseLogPreview() {
  if (!qpSelectedProduct) return;
  const batchNumber = qpSelectedProduct.batch;
  qpReleaseRecords[batchNumber] = {
    ...(qpReleaseRecords[batchNumber] || {}),
    ...collectQpReleaseState()
  };
  const log = getQpReleaseLogDefaults(qpSelectedProduct);
  document.querySelector("#print-preview-title").textContent = "QP Release Log";
  printPreviewRequest = null;
  printPreviewBody.innerHTML = `
    <div class="release-log-modal-shell">
      <div class="preview-toolbar">
<strong>Generated QP Release Log - Editable</strong>
<button class="classic-button" type="button" data-close-print-preview>Close</button>
      </div>
      <section class="qp-release-log-editor">
<div class="release-log-brand">B&S HEALTHCARE</div>
<div class="qp-log-editor-grid">
  <label>Product <textarea data-qp-log-field="product" readonly>${log.product}</textarea></label>
  <label>B&S Batch No. / Exp Date <textarea data-qp-log-field="batch" readonly>${log.batch}\n${log.expiry}</textarea></label>
  <label>Country of Origin <input data-qp-log-field="country" value="${log.country}" readonly></label>
  <label>Manufacturer Batch Number / Quantity / IMP <textarea data-qp-log-field="manufacturerDetails" readonly>${log.manufacturerDetails}</textarea></label>
  <label>QTY Issued <input data-qp-log-field="qtyIssued" value="${log.qtyIssued}" readonly></label>
  <label>Ret. Sample <input data-qp-log-field="retentionSample" value="${log.retentionSample}" readonly></label>
  <label>Damaged / Reg. Sample <input data-qp-log-field="damagedSample" value="${log.damagedSample}"></label>
  <label>Yield <input data-qp-log-field="yieldQty" value="${log.yieldQty}" readonly></label>
  <label>Room No <input data-qp-log-field="roomNo" value="${log.roomNo}" readonly></label>
  <label>Boxes <input data-qp-log-field="boxes" value="${log.boxes}" readonly></label>
  <label>Approved
    <select data-qp-log-field="approved">
      <option ${log.approved === "Yes" ? "selected" : ""}>Yes</option>
      <option ${log.approved === "No" ? "selected" : ""}>No</option>
    </select>
  </label>
  <label class="wide">Comments <textarea data-qp-log-field="comments">${log.comments}</textarea></label>
</div>
<div class="qp-log-signoff-strip">
  <label>QP Signature <input data-qp-log-field="qpSignature" value="${log.qpSignature}" placeholder="Captured on sign off" readonly></label>
  <label>Release Date <input data-qp-log-field="releaseDate" value="${log.releaseDate}" placeholder="Captured on sign off" readonly></label>
  <label>Signed By <input value="${log.signedBy || "Pending sign off"}" readonly></label>
  <label>Date / Time <input value="${log.signedDateTime || "Pending sign off"}" readonly></label>
</div>
<div class="release-log-modal-actions">
  <button class="classic-button" type="button" data-save-qp-release-log>Save Changes</button>
  <button class="classic-button primary" type="button" data-sign-qp-release-log>${log.signedDateTime ? "Signed Off" : "Sign Off Release Log"}</button>
</div>
      </section>
    </div>
  `;
  printPreviewModal.classList.remove("hidden");
  statusMessage.textContent = `Editable QP Release Log opened for ${qpSelectedProduct.batch}.`;
}

function completeQpRelease() {
  if (!qpSelectedProduct) return;
  const batchNumber = qpSelectedProduct.batch;
  const now = getAssemblyAuditTimestamp();
  qpReleaseRecords[batchNumber] = {
    ...(qpReleaseRecords[batchNumber] || {}),
    ...collectQpReleaseState(),
    user: currentLogin ? currentLogin.user : "qp.release",
    dateTime: now,
    approved: true,
    decision: "Certified"
  };
  if (!qpReleasedBatchNumbers.includes(batchNumber)) qpReleasedBatchNumbers.push(batchNumber);
  if (!qpCertifiedBatchNumbers.includes(batchNumber)) qpCertifiedBatchNumbers.push(batchNumber);
  statusMessage.textContent = `Batch ${batchNumber} QP released, signed off, and moved to the next stage.`;
  window.setTimeout(() => {
    qpSelectedProduct = null;
    qpChecklistOpen = false;
    renderStage("qp-release");
  }, 900);
}

function renderBatchDetails(product) {
  return `
    <div class="created-bar-summary bar-detail-grid">
      <div>
<span>B&S Batch Number</span>
<strong>${product.batch}</strong>
      </div>
      <div class="wide-detail">
<span>Product Name</span>
<strong>${product.product}</strong>
      </div>
      <div class="wide-detail">
<span>Foreign Name</span>
<strong>${product.foreignName || "-"}</strong>
      </div>
      <div>
<span>Strength</span>
<strong>${product.strength}</strong>
      </div>
      <div>
<span>Pack Size</span>
<strong>${product.packSize}</strong>
      </div>
      <div>
<span>ECMA</span>
<strong>${product.ecma}</strong>
      </div>
      <div>
<span>PL No.</span>
<strong>${product.pl}</strong>
      </div>
      <div>
<span>Expiry Date</span>
<strong>${product.expiry}</strong>
      </div>
      <div>
<span>Mfg. Lot No.</span>
<strong>${product.manufLotNo || product.manufacturingLot || "-"}</strong>
      </div>
      <div>
<span>Units per pack</span>
<strong>${product.unitsPerPack || "1"}</strong>
      </div>
      <div>
<span>Country of origin</span>
<strong>${product.country}</strong>
      </div>
      <div>
<span>Product Introduced</span>
<strong>${product.productIntroduced || "-"}</strong>
      </div>
      <div>
<span>Leaflet Date</span>
<strong>${product.leafletDate || "-"}</strong>
      </div>
      <div>
<span>Date Revised</span>
<strong>${product.dateRevised || "-"}</strong>
      </div>
    </div>
  `;
}

function auditPrinterAction(type, product, detail) {
  printerAuditTrail.unshift({
    type,
    batch: product.batch,
    user: currentLogin ? currentLogin.user : "printer.user",
    dateTime: new Date().toLocaleString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    }),
    detail
  });
}

function renderPrinterBlock(title, product, options = {}) {
  const isLeaflet = options.type === "leaflet";
  const actualValue = options.actual || "";
  return `
    <section class="printer-block ${options.disabled ? "printer-block-disabled" : ""}">
      <div class="printer-block-title">${title}</div>
      <div class="printer-mini-grid">
<table>
  <thead>
    <tr>
      <th></th>
      <th>${isLeaflet ? "Reference" : "Per Pack"}</th>
      <th>${isLeaflet ? "Leaflet Size" : "Reference"}</th>
      <th>${isLeaflet ? "Leaflet Pages" : "Label Size"}</th>
      <th>Lot</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>${options.marker || ""}</td>
      <td>${options.perPack || "1"}</td>
      <td>${options.reference || product.ecma}</td>
      <td>${options.size || product.packSize}</td>
      <td>${product.batch}</td>
    </tr>
  </tbody>
</table>
      </div>
      <div class="printer-actions-row">
<button class="classic-button" type="button" ${options.disabled ? "disabled" : ""}>Print</button>
<label>Actual Print : <input value="${actualValue}" ${options.disabled ? "readonly" : ""}></label>
<button class="classic-button" type="button" ${options.disabled ? "disabled" : ""}>Done</button>
      </div>
    </section>
  `;
}

function renderPrinterMenu() {
  const labelCount = getLabelPrintingProducts().length;
  const leafletCount = getLeafletPrintingProducts().length;
  const cartonCount = getCartonPrintingProducts().length;
  const brailleCount = getBraillePrintingProducts().length;
  return `
    <div class="printer-menu-layout" style="padding: 15px; font-family: Tahoma, sans-serif;">
      <section class="printer-menu-window" style="background: #f0f0f0; border: 1px solid #b0b0b0; padding: 15px;">
<div style="text-align: center; font-size: 16px; font-weight: bold; margin-bottom: 15px; color: #333;">Printer</div>
<div class="printer-option-grid" style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
  <button class="printer-option classic-button" type="button" data-printer-section="label-list" style="display: flex; flex-direction: column; align-items: flex-start; padding: 12px; height: auto; text-align: left; background: #fff !important; border: 1px solid #b0c2d4 !important;">
    <strong style="font-size: 13px; color: #0b5894; margin-bottom: 4px;">Label Printing</strong>
    <span style="font-size: 11px; color: #555; margin-bottom: 8px;">Print labels, then sign off.</span>
    <span class="printer-option-count" style="font-size: 11px; font-weight: bold; background: #e2effa; color: #0b5894; padding: 2px 6px; border-radius: 4px;">Active: ${labelCount}</span>
  </button>
  <button class="printer-option classic-button" type="button" data-printer-section="leaflet-list" style="display: flex; flex-direction: column; align-items: flex-start; padding: 12px; height: auto; text-align: left; background: #fff !important; border: 1px solid #b0c2d4 !important;">
    <strong style="font-size: 13px; color: #0b5894; margin-bottom: 4px;">Leaflet Printing</strong>
    <span style="font-size: 11px; color: #555; margin-bottom: 8px;">Print leaflets after Label Printing is complete.</span>
    <span class="printer-option-count" style="font-size: 11px; font-weight: bold; background: #e2effa; color: #0b5894; padding: 2px 6px; border-radius: 4px;">Active: ${leafletCount}</span>
  </button>
  <button class="printer-option classic-button" type="button" data-printer-section="carton-list" style="display: flex; flex-direction: column; align-items: flex-start; padding: 12px; height: auto; text-align: left; background: #fff !important; border: 1px solid #b0c2d4 !important;">
    <strong style="font-size: 13px; color: #0b5894; margin-bottom: 4px;">Carton Printing</strong>
    <span style="font-size: 11px; color: #555; margin-bottom: 8px;">Print cartons for reboxing batches.</span>
    <span class="printer-option-count" style="font-size: 11px; font-weight: bold; background: #e2effa; color: #0b5894; padding: 2px 6px; border-radius: 4px;">Active: ${cartonCount}</span>
  </button>
  <button class="printer-option classic-button" type="button" data-printer-section="braille-list" style="display: flex; flex-direction: column; align-items: flex-start; padding: 12px; height: auto; text-align: left; background: #fff !important; border: 1px solid #b0c2d4 !important;">
    <strong style="font-size: 13px; color: #0b5894; margin-bottom: 4px;">Braille Printing</strong>
    <span style="font-size: 11px; color: #555; margin-bottom: 8px;">Print braille labels for relabelling batches when required.</span>
    <span class="printer-option-count" style="font-size: 11px; font-weight: bold; background: #e2effa; color: #0b5894; padding: 2px 6px; border-radius: 4px;">Active: ${brailleCount}</span>
  </button>
</div>
      </section>
    </div>
  `;
}

function renderPrinterBatchList(title, products, emptyText, rowAction) {
  const filteredProducts = products.filter(
    (product) =>
      matchesBatchOrMfgLot(product, printerSearch)
  );
  return `
    <div class="label-printing-layout">
      <section class="bns-window">
<div class="sub-window-title">${title}</div>
<div class="printer-list-search">
  <label class="classic-search-label">B&S Batch Number : <input class="classic-search-input" data-printer-search value="${printerSearch}" placeholder="Search batch number"></label>
  <label class="classic-search-label">MFG Lot No : <input class="classic-search-input" data-printer-search value="${printerSearch}" placeholder="Search MFG lot"></label>
  <button class="classic-search-button" type="button" data-printer-search-button>Search</button>
</div>
<div class="grid-scroll label-grid-scroll">
  <table class="classic-table product-grid label-product-grid">
    <thead>
      <tr>
<th></th>
<th>B&S Batch Number</th>
<th class="mfg-lot-col">MFG Lot No</th>
<th>Product Name</th>
<th>Strength</th>
<th>Pack Size</th>
<th>ECMA</th>
<th>Expiry Date</th>
<th>Required Qty</th>
<th>Status</th>
      </tr>
    </thead>
    <tbody>
      ${
filteredProducts.length
  ? filteredProducts
      .map(
(product, index) => `
  <tr class="${index === 0 ? "selected-row " : ""}clickable-row" ${rowAction}="${product.batch}">
    <td>${index === 0 ? ">" : ""}</td>
    <td>${product.batch}</td>
    <td class="mfg-lot-col">${getMfgLotNo(product) || "-"}</td>
    <td>${product.product}</td>
    <td>${product.strength}</td>
    <td>${product.packSize}</td>
    <td>${product.ecma}</td>
    <td>${product.expiry}</td>
    <td>${
      title === "Leaflet Printing List"
? product.leafletQuantity
: title === "Carton Printing List"
  ? product.cartonQuantity || product.quantity
  : title === "Braille Printing List"
    ? product.brailleQuantity || product.quantity
    : product.quantity
    }</td>
    <td>Ready</td>
  </tr>
`
      )
      .join("")
  : `<tr><td colspan="10">${emptyText}</td></tr>`
      }
    </tbody>
  </table>
</div>
      </section>
    </div>
  `;
}

function renderAuditTrailForBatch(batchNumber) {
  const rows = printerAuditTrail.filter((entry) => entry.batch === batchNumber);
  return `
    <div class="printer-audit-panel">
      <div class="panel-title">Audit Trail</div>
      ${
rows.length
  ? rows
      .map(
(entry) => `
  <div class="printer-audit-row">
    <strong>${entry.type}</strong>
    <span>${entry.user} | ${entry.dateTime}</span>
    <p>${entry.detail}</p>
  </div>
`
      )
      .join("")
  : `<div class="printer-audit-row"><span>No printer actions recorded yet.</span></div>`
      }
    </div>
  `;
}

function renderLabelPrintingWork(stage) {
  if (printerSection === "menu") return renderPrinterMenu();
  if (printerSection === "label-list") {
    labelSelectedProduct = null;
    return renderPrinterBatchList("Label Printing List", getLabelPrintingProducts(), "No batches available for Label Printing.", "data-open-label-print");
  }
  if (printerSection === "leaflet-list") {
    leafletSelectedProduct = null;
    return renderPrinterBatchList("Leaflet Printing List", getLeafletPrintingProducts(), "No batches available for Leaflet Printing.", "data-open-leaflet-print");
  }
  if (printerSection === "carton-list") {
    cartonSelectedProduct = null;
    return renderPrinterBatchList("Carton Printing List", getCartonPrintingProducts(), "No reboxing batches available for Carton Printing.", "data-open-carton-print");
  }
  if (printerSection === "braille-list") {
    brailleSelectedProduct = null;
    return renderPrinterBatchList("Braille Printing List", getBraillePrintingProducts(), "No relabelling batches available for Braille Printing.", "data-open-braille-print");
  }
  if (printerSection === "leaflet-detail") return renderLeafletPrintingTask(stage);
  if (printerSection === "carton-detail") return renderCartonPrintingTask(stage);
  if (printerSection === "braille-detail") return renderBraillePrintingTask(stage);
  if (!labelSelectedProduct) return renderPrinterMenu();

  const product = labelSelectedProduct;
  const labelRequirements = getLabelRequirements(product);
  const labelRecord = labelPrintRecords[product.batch] || {};
  const savedQuantities = labelRecord.quantities || [];
  const labelRowExtras = labelRecord.rowExtras || {};
  const getPrintQuantity = (item) => {
    const saved = savedQuantities.find((quantity) => quantity.label === item.label);
    return saved ? saved.quantity : item.quantity;
  };

  let formValidForPrint = true;
  if (product.routeType === "Reboxing") {
    const data = changeOfPackSizeData[product.batch];
    if (!data) {
      formValidForPrint = false;
    } else {
      const receivedOk = data.receivedAs.ecma && data.receivedAs.packSize && data.receivedAs.blisterPerPack && data.receivedAs.qty && data.receivedAs.totalBlisters && data.receivedAs.initials;
      const assembledOk = data.assembledAs.ecma && data.assembledAs.packSize && data.assembledAs.blisterPerPack && data.assembledAs.finishedQty && data.assembledAs.initials;
      const printerSigned = data.printerAmendmentsInitials;
      formValidForPrint = !!(receivedOk && assembledOk && printerSigned);
    }
  }

  return `
    <div class="label-printing-layout label-detail-layout">
      <section class="process-one-form label-print-task">
<div class="panel-title">Label Printing - ${product.batch}</div>
${renderBatchDetails(product)}

<div class="panel-title">Labels to Print</div>
<table class="classic-table label-requirements-table">
  <thead>
    <tr>
      <th>Label</th>
      <th>Reference</th>
      <th>Label Size</th>
      <th>Quantity to Print</th>
      <th>Extra Quantity</th>
      <th>Reason for Extra</th>
      <th>Status</th>
      <th>Test Printing</th>
      <th>Print</th>
    </tr>
  </thead>
  <tbody>
    ${labelRequirements
      .map(
(item) => `
  <tr>
    <td>${item.label}</td>
    <td>${item.reference}</td>
    <td>${item.size}</td>
    <td><input class="table-number-input" type="number" min="0" value="${getPrintQuantity(item)}" data-label-print-qty data-label-name="${item.label}" ${isPrintItemDone(labelRecord, item.label) ? "readonly" : ""}></td>
    <td><input class="table-number-input" type="number" min="0" value="${labelRowExtras[item.label] ? labelRowExtras[item.label].quantity : "0"}" data-label-extra data-label-extra-qty data-extra-item="${item.label}" ${isPrintItemDone(labelRecord, item.label) ? "disabled" : ""}></td>
    <td>
      <select data-label-extra data-label-extra-reason data-extra-item="${item.label}" ${isPrintItemDone(labelRecord, item.label) ? "disabled" : ""}>
<option value="">Select reason</option>
<option ${labelRowExtras[item.label] && labelRowExtras[item.label].reason === "Print damage" ? "selected" : ""}>Print damage</option>
<option ${labelRowExtras[item.label] && labelRowExtras[item.label].reason === "Line setup waste" ? "selected" : ""}>Line setup waste</option>
<option ${labelRowExtras[item.label] && labelRowExtras[item.label].reason === "Reconciliation correction" ? "selected" : ""}>Reconciliation correction</option>
<option ${labelRowExtras[item.label] && labelRowExtras[item.label].reason === "Printing alignment check" ? "selected" : ""}>Printing alignment check</option>
<option ${labelRowExtras[item.label] && labelRowExtras[item.label].reason === "Supervisor approved extra" ? "selected" : ""}>Supervisor approved extra</option>
      </select>
    </td>
    <td>${isPrintItemDone(labelRecord, item.label) ? "Printed" : "Waiting to print"}</td>
    <td><button class="classic-button row-print-button" type="button" data-test-preview-print data-preview-type="label" data-preview-batch="${product.batch}" data-preview-item="${item.label}" ${isPrintItemDone(labelRecord, item.label) || !(labelRowExtras[item.label] && labelRowExtras[item.label].reason) ? "disabled" : ""}>Test Printing</button></td>
    <td><button class="classic-button row-print-button" type="button" data-preview-print data-preview-type="label" data-preview-batch="${product.batch}" data-preview-item="${item.label}" ${isPrintItemDone(labelRecord, item.label) || !formValidForPrint ? "disabled" : ""} title="${!formValidForPrint ? 'Fill and digitally sign the Change of Pack Size form before printing' : ''}">Print</button></td>
  </tr>
`
      )
      .join("")}
  </tbody>
</table>



${
  product.routeType === "Reboxing"
    ? renderChangeOfPackSizeForm(product.batch, labelRecord.printed || labelRecord.completed, stage)
    : ""
}

<div class="signature-grid label-signoff-grid">
  <label>Printed By <input value="${currentLogin ? currentLogin.user : stage.user}" readonly></label>
  <label>Date / Time <input value="${labelRecord.printedAt || "Pending print"}" readonly></label>
  <div class="signoff-action">
    <button class="classic-button primary" type="button" id="label-complete-button" disabled>User Sign Off</button>
  </div>
</div>
      </section>
    </div>
  `;
}

function renderLeafletPrintingTask(stage) {
  if (!leafletSelectedProduct) return renderPrinterBatchList("Leaflet Printing List", getLeafletPrintingProducts(), "No batches available for Leaflet Printing.", "data-open-leaflet-print");
  const product = leafletSelectedProduct;
  const leafletRecord = leafletPrintRecords[product.batch] || {};
  const leafletRequirements = getLeafletRequirements(product);
  const savedQuantities = leafletRecord.quantities || [];
  const leafletRowExtras = leafletRecord.rowExtras || {};
  const getLeafletQuantity = (item) => {
    const saved = savedQuantities.find((quantity) => quantity.label === item.label);
    return saved ? saved.quantity : item.quantity;
  };

  return `
    <div class="label-printing-layout label-detail-layout">
      <section class="process-one-form label-print-task">
<div class="panel-title">Leaflet Printing - ${product.batch}</div>
${renderBatchDetails(product)}

<div class="panel-title">Leaflets to Print</div>
<table class="classic-table label-requirements-table">
  <thead>
    <tr>
      <th>Leaflet</th>
      <th>Reference</th>
      <th>Leaflet Size</th>
      <th>Quantity to Print</th>
      <th>Extra Quantity</th>
      <th>Reason for Extra</th>
      <th>Status</th>
      <th>Test Printing</th>
      <th>Print</th>
    </tr>
  </thead>
  <tbody>
    ${leafletRequirements
      .map(
(item) => `
  <tr>
    <td>${item.label}</td>
    <td>${item.reference}</td>
    <td>${item.size}</td>
    <td><input class="table-number-input" type="number" min="0" value="${getLeafletQuantity(item)}" data-leaflet-print-qty data-leaflet-name="${item.label}" ${isPrintItemDone(leafletRecord, item.label) ? "readonly" : ""}></td>
    <td><input class="table-number-input" type="number" min="0" value="${leafletRowExtras[item.label] ? leafletRowExtras[item.label].quantity : "0"}" data-leaflet-extra data-leaflet-extra-qty data-extra-item="${item.label}" ${isPrintItemDone(leafletRecord, item.label) ? "disabled" : ""}></td>
    <td>
      <select data-leaflet-extra data-leaflet-extra-reason data-extra-item="${item.label}" ${isPrintItemDone(leafletRecord, item.label) ? "disabled" : ""}>
<option value="">Select reason</option>
<option ${leafletRowExtras[item.label] && leafletRowExtras[item.label].reason === "Print damage" ? "selected" : ""}>Print damage</option>
<option ${leafletRowExtras[item.label] && leafletRowExtras[item.label].reason === "Line setup waste" ? "selected" : ""}>Line setup waste</option>
<option ${leafletRowExtras[item.label] && leafletRowExtras[item.label].reason === "Reconciliation correction" ? "selected" : ""}>Reconciliation correction</option>
<option ${leafletRowExtras[item.label] && leafletRowExtras[item.label].reason === "Printing alignment check" ? "selected" : ""}>Printing alignment check</option>
<option ${leafletRowExtras[item.label] && leafletRowExtras[item.label].reason === "Supervisor approved extra" ? "selected" : ""}>Supervisor approved extra</option>
      </select>
    </td>
    <td>${isPrintItemDone(leafletRecord, item.label) ? "Printed" : "Waiting to print"}</td>
    <td><button class="classic-button row-print-button" type="button" data-test-preview-print data-preview-type="leaflet" data-preview-batch="${product.batch}" data-preview-item="${item.label}" ${isPrintItemDone(leafletRecord, item.label) || !(leafletRowExtras[item.label] && leafletRowExtras[item.label].reason) ? "disabled" : ""}>Test Printing</button></td>
    <td><button class="classic-button row-print-button" type="button" data-preview-print data-preview-type="leaflet" data-preview-batch="${product.batch}" data-preview-item="${item.label}" ${isPrintItemDone(leafletRecord, item.label) ? "disabled" : ""}>Print</button></td>
  </tr>
`
      )
      .join("")}
  </tbody>
</table>



<div class="signature-grid label-signoff-grid">
  <label>Leaflet Printed By <input value="${currentLogin ? currentLogin.user : stage.user}" readonly></label>
  <label>Date / Time <input value="${leafletRecord.printedAt || "Pending print"}" readonly></label>
  <div class="signoff-action">
    <button class="classic-button primary" type="button" id="leaflet-complete-button" disabled>User Sign Off</button>
  </div>
</div>
      </section>
    </div>
  `;
}

function renderRoutePrintingTask(stage, config) {
  const product = config.product;
  if (!product) return renderPrinterBatchList(config.listTitle, config.products, config.emptyText, config.rowAction);
  const record = config.records[product.batch] || {};
  const requirements = config.requirements(product);
  const savedQuantities = record.quantities || [];
  const rowExtras = record.rowExtras || {};
  const getQuantity = (item) => {
    const saved = savedQuantities.find((quantity) => quantity.label === item.label);
    return saved ? saved.quantity : item.quantity;
  };

  return `
    <div class="label-printing-layout label-detail-layout">
      <section class="process-one-form label-print-task">
<div class="panel-title">${config.title} - ${product.batch}</div>
${renderBatchDetails(product)}

${
  config.showBatchBarcode
    ? `
      <div class="batch-barcode-card">
<div>
  <span>B&S Batch Number Barcode</span>
  <strong>${product.batch}</strong>
</div>
<div class="barcode-strip" aria-label="Barcode for ${product.batch}"></div>
      </div>
    `
    : ""
}

<div class="panel-title">${config.itemsTitle}</div>
<table class="classic-table label-requirements-table">
  <thead>
    <tr>
      <th>${config.itemColumn}</th>
      <th>Reference</th>
      <th>${config.sizeColumn}</th>
      <th>Quantity to Print</th>
      ${config.rowPrintPreview ? "<th>Extra Quantity</th><th>Reason for Extra</th>" : ""}
      <th>Status</th>
      ${config.rowPrintPreview ? "<th>Test Printing</th><th>Print</th>" : ""}
    </tr>
  </thead>
  <tbody>
    ${requirements
      .map(
(item) => `
  <tr>
    <td>${item.label}</td>
    <td>${item.reference}</td>
    <td>${item.size}</td>
    <td><input class="table-number-input" type="number" min="0" value="${getQuantity(item)}" ${config.qtyAttr} data-${config.type}-name="${item.label}" ${isPrintItemDone(record, item.label) ? "readonly" : ""}></td>
    ${
      config.rowPrintPreview
? `<td><input class="table-number-input" type="number" min="0" value="${rowExtras[item.label] ? rowExtras[item.label].quantity : "0"}" data-${config.type}-extra data-${config.type}-extra-qty data-extra-item="${item.label}" ${isPrintItemDone(record, item.label) ? "disabled" : ""}></td>
   <td>
     <select data-${config.type}-extra data-${config.type}-extra-reason data-extra-item="${item.label}" ${isPrintItemDone(record, item.label) ? "disabled" : ""}>
       <option value="">Select reason</option>
       <option ${rowExtras[item.label] && rowExtras[item.label].reason === "Print damage" ? "selected" : ""}>Print damage</option>
       <option ${rowExtras[item.label] && rowExtras[item.label].reason === "Line setup waste" ? "selected" : ""}>Line setup waste</option>
       <option ${rowExtras[item.label] && rowExtras[item.label].reason === "Reconciliation correction" ? "selected" : ""}>Reconciliation correction</option>
       <option ${rowExtras[item.label] && rowExtras[item.label].reason === "Printing alignment check" ? "selected" : ""}>Printing alignment check</option>
<option ${rowExtras[item.label] && rowExtras[item.label].reason === "Supervisor approved extra" ? "selected" : ""}>Supervisor approved extra</option>
     </select>
   </td>`
: ""
    }
    <td>${isPrintItemDone(record, item.label) ? config.doneStatus : config.waitingStatus}</td>
    ${config.rowPrintPreview ? `<td><button class="classic-button row-print-button" type="button" data-test-preview-print data-preview-type="${config.type}" data-preview-batch="${product.batch}" data-preview-item="${item.label}" ${isPrintItemDone(record, item.label) || !(rowExtras[item.label] && rowExtras[item.label].reason) ? "disabled" : ""}>Test Printing</button></td><td><button class="classic-button row-print-button" type="button" data-preview-print data-preview-type="${config.type}" data-preview-batch="${product.batch}" data-preview-item="${item.label}" ${isPrintItemDone(record, item.label) ? "disabled" : ""}>Print</button></td>` : ""}
  </tr>
`
      )
      .join("")}
  </tbody>
</table>

${
  config.rowPrintPreview
    ? ""
    : `<div class="print-quantity-grid extra-label-grid">
<label>Extra ${config.extraName} Quantity <input type="number" min="0" value="${record.extraQuantity || "0"}" id="extra-${config.type}-qty" data-${config.type}-extra></label>
<label>Reason for Extra ${config.extraNamePlural}
  <select id="extra-${config.type}-reason" data-${config.type}-extra>
    <option value="">Select reason</option>
    <option ${record.extraReason === "Print damage" ? "selected" : ""}>Print damage</option>
    <option ${record.extraReason === "Line setup waste" ? "selected" : ""}>Line setup waste</option>
    <option ${record.extraReason === "Reconciliation correction" ? "selected" : ""}>Reconciliation correction</option>
    <option ${record.extraReason === "Printing alignment check" ? "selected" : ""}>Printing alignment check</option>
<option ${record.extraReason === "Supervisor approved extra" ? "selected" : ""}>Supervisor approved extra</option>
  </select>
</label>
      </div>`
}

${
  config.rowPrintPreview
    ? ""
    : `<div class="print-action-row compact-print-action">
<button class="classic-button primary" type="button" ${config.printAttr}="${product.batch}" ${record.printed ? "disabled" : ""}>${config.actionLabel}</button>
      </div>`
}





<div class="signature-grid label-signoff-grid">
  <label>${config.signedByLabel} <input value="${currentLogin ? currentLogin.user : stage.user}" readonly></label>
  <label>Date / Time <input value="${record.printedAt || "Pending print"}" readonly></label>
  <div class="signoff-action">
    <button class="classic-button primary" type="button" id="${config.type}-complete-button" disabled>User Sign Off</button>
  </div>
</div>
      </section>
    </div>
  `;
}

function renderCartonPrintingTask(stage) {
  return renderRoutePrintingTask(stage, {
    type: "carton",
    title: "Carton Printing",
    listTitle: "Carton Printing List",
    products: getCartonPrintingProducts(),
    emptyText: "No reboxing batches available for Carton Printing.",
    rowAction: "data-open-carton-print",
    product: cartonSelectedProduct,
    records: cartonPrintRecords,
    itemsTitle: "Cartons to Print",
    itemColumn: "Carton",
    sizeColumn: "Carton Size",
    extraName: "Carton",
    extraNamePlural: "Cartons",
    evidenceTitle: "Carton Evidence",
    evidenceLabel: "Upload photo evidence",
    singleEvidence: true,
    showBatchBarcode: true,
    actionLabel: "Confirm Carton Quantity",
    waitingStatus: "Waiting to locate",
    doneStatus: "Located",
    signedByLabel: "Carton Printed By",
    printAttr: "data-print-cartons",
    qtyAttr: "data-carton-print-qty",
    requirements: (product) => [
      { label: "Approved Carton", reference: product.ecma, size: product.packSize, quantity: product.cartonQuantity || product.quantity },
      { label: "Peel Out Carton", reference: product.pl, size: product.packSize, quantity: product.cartonQuantity || product.quantity }
    ]
  });
}

function renderBraillePrintingTask(stage) {
  return renderRoutePrintingTask(stage, {
    type: "braille",
    title: "Braille Printing",
    listTitle: "Braille Printing List",
    products: getBraillePrintingProducts(),
    emptyText: "No relabelling batches available for Braille Printing.",
    rowAction: "data-open-braille-print",
    product: brailleSelectedProduct,
    records: braillePrintRecords,
    itemsTitle: "Braille Labels to Print",
    itemColumn: "Braille Label",
    sizeColumn: "Label Size",
    extraName: "Braille",
    extraNamePlural: "Braille Labels",
    evidenceTitle: "Braille Evidence",
    firstEvidenceLabel: "First printed braille photo",
    lastEvidenceLabel: "Last printed braille photo",
    actionLabel: "Print Braille Labels",
    waitingStatus: "Waiting to print",
    doneStatus: "Printed",
    rowPrintPreview: true,
    signedByLabel: "Braille Printed By",
    printAttr: "data-print-braille",
    qtyAttr: "data-braille-print-qty",
    requirements: (product) => [
      { label: "Braille Label", reference: product.ecma, size: product.packSize, quantity: product.brailleQuantity || product.quantity },
      { label: "Braille Declaration Copy", reference: product.pl, size: "Master copy", quantity: "1" }
    ]
  });
}

function renderStage(stageId) {
  const stage = findStage(stageId);
  currentStageId = stage.id;
  welcomeWindow.classList.add("hidden");
  dashboardWindow.classList.add("hidden");
  moduleWindow.classList.remove("hidden");
  moduleWindow.classList.toggle("packing-list-mode", stage.id === "packing-list");
  moduleWindow.classList.toggle("rp-pack-mode", stage.id === "rp-pack");
  moduleWindow.classList.toggle("batch-checker-mode", stage.id === "batch-checker");
  moduleWindow.classList.toggle("bar-creation-mode", stage.id === "bar-creation");
  moduleWindow.classList.toggle("label-printing-mode", stage.id === "label-printing");
  moduleWindow.classList.toggle("leaflet-folding-mode", stage.id === "leaflet-folding");
  moduleWindow.classList.toggle("double-check-mode", stage.id === "pre-assembly-qc");
  moduleWindow.classList.toggle("production-mode", stage.id === "room-allocation");
  moduleWindow.classList.toggle("assembly-mode", stage.id === "assembly-room");
  moduleWindow.classList.toggle("postassembly-mode", stage.id === "post-assembly-qc");
  moduleWindow.classList.toggle("preqp-mode", stage.id === "pre-qp");
  moduleWindow.classList.toggle("qp-release-mode", stage.id === "qp-release" || stage.id === "qp-certified");
  statusMessage.textContent =
    stage.id === "packing-list"
      ? `Packing List opened as ${currentLogin ? currentLogin.user : stage.user}`
      : stage.id === "rp-pack"
      ? `RPi Pack Creation / Approval opened as ${currentLogin ? currentLogin.user : stage.user}`
      : stage.id === "batch-checker"
      ? `Batch Checker opened as ${currentLogin ? currentLogin.user : stage.user}`
      : stage.id === "bar-creation"
      ? `BNS Batch Add opened as ${currentLogin ? currentLogin.user : stage.user}`
      : stage.id === "pre-assembly-qc"
? `Pre Assembly opened as ${currentLogin ? currentLogin.user : stage.user}`
: stage.id === "room-allocation"
  ? `Production Controller opened as ${currentLogin ? currentLogin.user : stage.user}`
: stage.id === "assembly-room"
  ? `Assembly Room opened as ${currentLogin ? currentLogin.user : stage.user}`
: stage.id === "post-assembly-qc"
  ? `Production Checking opened as ${currentLogin ? currentLogin.user : stage.user}`
: stage.id === "pre-qp"
  ? `Pre QP opened as ${currentLogin ? currentLogin.user : stage.user}`
: stage.id === "qp-release"
  ? `QP Release opened as ${currentLogin ? currentLogin.user : stage.user}`
: stage.id === "qp-certified"
  ? `QP Certified Batches opened as ${currentLogin ? currentLogin.user : stage.user}`
: `Printer opened as ${currentLogin ? currentLogin.user : stage.user}`;

  document.querySelector("#module-window-title").textContent =
    stage.id === "packing-list"
      ? "Packing List"
      : stage.id === "rp-pack"
      ? "RPi Pack"
      : stage.id === "batch-checker"
      ? "Batch Check"
      : stage.id === "bar-creation"
      ? "BNS Batch Add"
      : stage.id === "label-printing"
? "Printer"
: stage.id === "pre-assembly-qc"
  ? "Pre Assembly"
: stage.id === "room-allocation"
  ? "Production Controller"
: stage.id === "assembly-room"
  ? "Assembly Room"
: stage.id === "post-assembly-qc"
  ? "Production Checking"
: stage.id === "pre-qp"
  ? "Pre QP"
: stage.id === "qp-release"
  ? "QP Release"
: stage.id === "qp-certified"
  ? "QP Certified Batches"
: `${stage.loginTitle} - ${stage.title}`;
  document.querySelector("#stage-code").textContent = `${stage.code} | ${stage.owner}`;
  document.querySelector("#stage-title").textContent = stage.title;
  document.querySelector("#login-context").textContent = `Logged in: ${currentLogin ? currentLogin.user : stage.user} | Role: ${currentLogin ? currentLogin.role : stage.role}`;
  const batchValues = document.querySelectorAll(".batch-strip strong");
  if (batchValues.length >= 4) {
    batchValues[0].textContent = stage.id === "bar-creation" ? "Pending creation" : "03A1582";
    batchValues[1].textContent = "Flutiform 250/10mcg";
    batchValues[2].textContent = "03A1582";
    batchValues[3].textContent = "650";
  }
  document.querySelector("#checks-progress").textContent = `${stage.progress[0]}%`;
  document.querySelector("#evidence-progress").textContent = `${stage.progress[1]}%`;
  document.querySelector("#checks-bar").style.width = `${stage.progress[0]}%`;
  document.querySelector("#evidence-bar").style.width = `${stage.progress[1]}%`;
  document.querySelector("#exception-title").textContent = stage.status === "hold" ? "Active hold requires resolution" : "No active exception";
  document.querySelector("#exception-copy").textContent =
    stage.status === "hold"
      ? "The batch cannot move forward until the recorded mismatch or missing evidence is closed."
      : "Mismatches, missing evidence, or failed checks are held here until resolved.";

  document.querySelector("#stage-work-content").innerHTML =
    stage.id === "packing-list"
      ? renderPackingListWork(stage)
      : stage.id === "rp-pack"
      ? renderRpPackWork(stage)
      : stage.id === "batch-checker"
      ? renderBatchCheckerWork(stage)
      : stage.id === "bar-creation"
      ? renderBarCreationWork(stage)
      : stage.id === "label-printing"
? renderLabelPrintingWork(stage)
: stage.id === "leaflet-folding"
  ? renderLeafletFoldingWork(stage)
  : stage.id === "pre-assembly-qc"
    ? renderPreAssemblyWork(stage)
  : stage.id === "room-allocation"
    ? renderProductionControlWork(stage)
  : stage.id === "assembly-room"
    ? renderAssemblyRoomWork(stage)
  : stage.id === "post-assembly-qc"
    ? renderPostAssemblyWork(stage)
  : stage.id === "pre-qp"
    ? renderPreQpWork(stage)
  : stage.id === "qp-release" || stage.id === "qp-certified"
    ? renderQpReleaseWork(stage)
  : renderGenericStageWork(stage);
  updateSignoffAvailability();
  updatePackingListAvailability();
  updateRpApprovalAvailability();
  updateBatchCheckerAvailability();
  updateLabelCompletionAvailability();
  updateLeafletCompletionAvailability();
  updateCartonCompletionAvailability();
  updateBrailleCompletionAvailability();
  updateLeafletFoldingAvailability();
  updatePreAssemblyAvailability();
  updateProductionAvailability();
  updateAssemblyAvailability();
  updatePostAssemblyAvailability();
  updatePreQpAvailability();
  updateQpReleaseAvailability();

  document.querySelector("#stage-evidence").innerHTML = stage.evidence
    .map(
      (item) => `
<div class="evidence-tile">
  <strong>${item}</strong>
  <span>Required for ${stage.title}</span>
  <div class="upload-box">Upload / Attach Evidence</div>
</div>
      `
    )
    .join("");

  document.querySelector("#phase-controls").innerHTML = stage.controls.map((control) => `<li>${control}</li>`).join("");

  const queueRows =
    stage.id === "bar-creation"
      ? [
  ["Ready to create", "Flutiform 250/10mcg", "Selected row"],
  ["Not Printed BAR", "ADARTEL 0.25mg", "Search result"],
  ["Not Printed BAR", "ADARTREL 2mg", "Search result"]
]
      : [
  ["03A1582", "Flutiform 250/10mcg", "Created in BAR Creation"],
  ["BAR-240621", "Omeprazole 10mg", "Hold"],
  ["BAR-240627", "Metformin 500mg", "Routine"]
];

  document.querySelector("#module-queue").innerHTML = queueRows
    .map(
      ([bar, product, due]) => `
<div class="queue-card">
  <strong>${bar}</strong>
  <span>${product}</span>
  <span>${stage.title} | ${due}</span>
</div>
      `
    )
    .join("");

  document.querySelector("#audit-list").innerHTML = [
    ["Module login", `${currentLogin ? currentLogin.user : stage.user} authenticated for ${stage.title}`, "Today 09:08"],
    ["Batch opened", `${stage.owner} opened 03A1582`, "Today 09:12"],
    ["Checklist updated", "Line clearance and product checks saved", "Today 09:28"],
    ["Evidence attached", `${stage.evidence[0]} added to batch pack`, "Today 09:41"],
    ["Draft saved", "Electronic record version 3 saved", "Today 10:05"]
  ]
    .map(
      ([title, body, time]) => `
<li>
  <strong>${title}</strong>
  ${body}
  <span>${time}</span>
</li>
      `
    )
    .join("");

  document.querySelectorAll(".tab").forEach((button) => {
    button.classList.toggle("active", button.dataset.tab === "checks");
  });
  document.querySelectorAll(".tab-panel").forEach((panel) => {
    panel.classList.toggle("active", panel.id === "checks-panel");
  });
}

document.addEventListener("click", (event) => {
  const psSignBtn = event.target.closest("[data-ps-sign]");
  if (psSignBtn) {
    const batch = psSignBtn.dataset.psBatch;
    const section = psSignBtn.dataset.psSign;
    const user = currentLogin ? currentLogin.user : (currentStageId === "pre-assembly-qc" ? "preassembly.qc" : "printer.user");
    const now = new Date().toLocaleString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    });
    
    if (changeOfPackSizeData[batch]) {
      if (section === "receivedAs" || section === "assembledAs") {
changeOfPackSizeData[batch][section].initials = `Signed by ${user} on ${now}`;
      } else {
changeOfPackSizeData[batch][section + "Initials"] = `Signed by ${user} on ${now}`;
      }
      
      renderStage(currentStageId);
      updateLabelCompletionAvailability();
      updatePreAssemblyAvailability();
    }
    return;
  }

  const psClearSigBtn = event.target.closest("[data-ps-clear-sig]");
  if (psClearSigBtn) {
    const batch = psClearSigBtn.dataset.psBatch;
    const section = psClearSigBtn.dataset.psClearSig;
    
    if (changeOfPackSizeData[batch]) {
      if (section === "receivedAs" || section === "assembledAs") {
changeOfPackSizeData[batch][section].initials = "";
      } else {
changeOfPackSizeData[batch][section + "Initials"] = "";
      }
      
      renderStage(currentStageId);
      updateLabelCompletionAvailability();
      updatePreAssemblyAvailability();
    }
    return;
  }

  const loginTrigger = event.target.closest("[data-login-stage]");
  if (loginTrigger) {
    openLogin(loginTrigger.dataset.loginStage);
    return;
  }

  if (event.target.closest("[data-open-dashboard]")) {
    openDashboard();
    return;
  }

  if (event.target.closest("[data-close-login]")) {
    closeLogin();
    return;
  }

  if (event.target.closest("[data-close-dashboard]")) {
    dashboardWindow.classList.add("hidden");
    welcomeWindow.classList.remove("hidden");
    statusMessage.textContent = "BAR Dashboard closed";
    return;
  }

  if (event.target.closest("#user-signoff-button")) {
    requestUserSignoff(confirmSignoff, "BNS Batch Add");
    return;
  }

  if (event.target.closest("[data-signoff-no]")) {
    closeSignoffDialog();
    return;
  }

  if (event.target.closest("[data-app-confirm-no]")) {
    closeAppConfirm();
    return;
  }

  const createBarTrigger = event.target.closest("[data-create-bar]");
  if (createBarTrigger) {
    openCreateBarDialog(createBarTrigger.dataset.createBar);
    return;
  }
  const testPreviewTrigger = event.target.closest("[data-test-preview-print]");
  if (testPreviewTrigger) {
    openPrintPreview(testPreviewTrigger.dataset.previewType, testPreviewTrigger.dataset.previewBatch, testPreviewTrigger.dataset.previewItem, true);
    return;
  }

  const previewTrigger = event.target.closest("[data-preview-print]");
  if (previewTrigger) {
    openPrintPreview(previewTrigger.dataset.previewType, previewTrigger.dataset.previewBatch, previewTrigger.dataset.previewItem);
    return;
  }

  if (event.target.closest("[data-close-print-preview]")) {
    closePrintPreview();
    return;
  }

  if (event.target.id === "preview-print-button" || event.target.closest("#preview-print-button")) {
    confirmPreviewPrint();
    return;
  }

  // Batch Checker Row selection
  const batchOpenPo = event.target.closest("[data-batchchecker-open-po]");
  if (batchOpenPo) {
    batchCheckerSelectedPo = batchOpenPo.dataset.batchcheckerOpenPo;
    batchCheckerSearch = batchCheckerSelectedPo;
    batchCheckerDashboardOpen = true;
    selectedBatchCheckerRowKey = null;
    renderStage("batch-checker");
    statusMessage.textContent = `Batch Checker dashboard opened for PO ${batchCheckerSelectedPo}.`;
    return;
  }

  if (event.target.closest("[data-batchchecker-back-list]")) {
    batchCheckerDashboardOpen = false;
    selectedBatchCheckerRowKey = null;
    renderStage("batch-checker");
    return;
  }

  if (event.target.closest("[data-batchchecker-back-dashboard]")) {
    selectedBatchCheckerRowKey = null;
    renderStage("batch-checker");
    return;
  }

  const batchOpenLine = event.target.closest("[data-batchchecker-open-line]");
  if (batchOpenLine) {
    selectedBatchCheckerRowKey = Number(batchOpenLine.dataset.batchcheckerOpenLine);
    renderStage("batch-checker");
    return;
  }

  if (event.target.closest("#batchchecker-detail-print-label")) {
    const rows = getBatchCheckerRows();
    const row = rows[selectedBatchCheckerRowKey];
    if (row && areBatchCheckerLineChecksComplete(row)) {
      const nowDate = new Date().toLocaleDateString("en-GB").replace(/\//g, "-");
      const nowTime = new Date().toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
      batchCheckerVerifiedRows[getBatchCheckerRowKey(row)] = { checker: currentLogin ? currentLogin.user : "checker.user", date: nowDate, time: nowTime };
      row.status = "BatchCheck";
      markBatchCheckerLabelPrinted(row, "Goods In Label");
      renderStage("batch-checker");
      statusMessage.textContent = "Line clearance captured. Print PCL and Print Label is now enabled for this product.";
    }
    return;
  }

  const checkerRow = event.target.closest("[data-batchchecker-row-index]");
  if (checkerRow && !event.target.closest("button") && !event.target.closest("input") && !event.target.closest(".manufacturer-cell")) {
    const idx = Number(checkerRow.dataset.batchcheckerRowIndex);
    selectedBatchCheckerRowKey = idx;
    
    // Auto-check the checkbox of the clicked row
    const rows = getBatchCheckerRows();
    const row = rows[idx];
    const rowKey = `${row.orderNo}_${row.batchNo}`;
    batchCheckerCheckedRows[rowKey] = true;
    
    const chkInput = checkerRow.querySelector("input[type='checkbox']");
    if (chkInput) chkInput.checked = true;
    
    const currentPoRowKeys = rows.map(r => `${r.orderNo}_${r.batchNo}`);
    const totalChecked = Object.keys(batchCheckerCheckedRows).filter(k => batchCheckerCheckedRows[k] && currentPoRowKeys.includes(k)).length;
    const totalScanEl = document.querySelector("#batchchecker-total-scan");
    if (totalScanEl) totalScanEl.textContent = totalChecked;
    
    document.querySelectorAll(".batchchecker-table tbody tr").forEach((tr, trIdx) => {
      tr.classList.toggle("selected-row", trIdx === selectedBatchCheckerRowKey);
    });
    updateBatchCheckerAvailability();
    return;
  }

  // Batch Checker Checkbox selection
  const checkerSelect = event.target.closest("[data-batchchecker-row-select]");
  if (checkerSelect) {
    const idx = Number(checkerSelect.dataset.batchcheckerRowSelect);
    const rows = getBatchCheckerRows();
    const row = rows[idx];
    const rowKey = `${row.orderNo}_${row.batchNo}`;
    batchCheckerCheckedRows[rowKey] = checkerSelect.checked;
    const currentPoRowKeys = rows.map(r => `${r.orderNo}_${r.batchNo}`);
    const totalChecked = Object.keys(batchCheckerCheckedRows).filter(k => batchCheckerCheckedRows[k] && currentPoRowKeys.includes(k)).length;
    document.querySelector("#batchchecker-total-scan").textContent = totalChecked;
    selectedBatchCheckerRowKey = idx;
    document.querySelectorAll(".batchchecker-table tbody tr").forEach((tr, wIdx) => {
      tr.classList.toggle("selected-row", wIdx === selectedBatchCheckerRowKey);
    });
    updateBatchCheckerAvailability();
    return;
  }

  // Batch Checker Search
  if (event.target.closest("[data-batchchecker-search-btn]")) {
    const scanInput = document.querySelector("[data-batchchecker-scan-input]");
    const batchInput = document.querySelector('[data-batchchecker-filter="batch"]');
    const mfgLotInput = document.querySelector('[data-batchchecker-filter="mfgLot"]');
    if (scanInput) {
      batchCheckerSearch = scanInput.value;
      batchCheckerSelectedPo = scanInput.value || batchCheckerSelectedPo;
    }
    batchCheckerFilters.batch = batchInput ? batchInput.value : "";
    batchCheckerFilters.mfgLot = mfgLotInput ? mfgLotInput.value : "";
    selectedBatchCheckerRowKey = null; // Reset selection on new search to avoid out-of-bounds
    renderStage("batch-checker");
    statusMessage.textContent = `Search results for PO ${batchCheckerSelectedPo} loaded.`;
    return;
  }
  // Batch Checker Clear Scan
  if (event.target.closest("[data-batchchecker-clear-scan]")) {
    batchCheckerCheckedRows = {};
    batchCheckerFilters = { product: "", site: "", po: "", status: "", mfgLot: "" };
    renderStage("batch-checker");
    statusMessage.textContent = "Scans cleared.";
    return;
  }
  // Batch Checker Manufacturer select popup open
  const mfgClick = event.target.closest("[data-batchchecker-mfg-click]");
  if (mfgClick) {
    selectedBatchCheckerRowIndexForPopup = Number(mfgClick.dataset.batchcheckerMfgClick);
    openMfgPopup();
    return;
  }

  // Manufacturer select confirm
  if (event.target.closest("#mfg-popup-select-btn")) {
    const selectedRadio = document.querySelector("input[name='mfg-select-radio']:checked");
    if (selectedRadio && selectedBatchCheckerRowIndexForPopup !== null) {
      const mfgIdx = Number(selectedRadio.value);
      const mfg = batchCheckerMfgList[mfgIdx];
      const rows = getBatchCheckerRows();
      const row = rows[selectedBatchCheckerRowIndexForPopup];
      row.manufacturer = mfg.name;
      row.mfgId = "30" + (mfgIdx + 1);
      document.querySelector("#mfg-popup-modal").classList.add("hidden");
      renderStage("batch-checker");
      statusMessage.textContent = `Manufacturer set to ${mfg.name} for row.`;
    }
    return;
  }

  // Manufacturer popup close
  if (event.target.closest("[data-close-mfg-popup]")) {
    document.querySelector("#mfg-popup-modal").classList.add("hidden");
    return;
  }

  // Split Batch popup open
  const splitClick = event.target.closest("[data-batchchecker-split]");
  if (splitClick) {
    const idx = Number(splitClick.dataset.batchcheckerSplit);
    openSplitBatchPopup(idx);
    return;
  }

  // Split Batch save
  if (event.target.closest("#split-batch-save-btn")) {
    const lotNo = document.querySelector("#split-batch-no").value;
    const qty = document.querySelector("#split-qty").value;
    const exp = document.querySelector("#split-exp").value;
    
    if (lotNo && qty && selectedBatchCheckerRowIndexForSplit !== null) {
      const rows = getBatchCheckerRows();
      const originalRow = rows[selectedBatchCheckerRowIndexForSplit];
      const newQty = Number(qty);
      if (newQty <= 0) {
alert("Quantity must be greater than 0.");
return;
      }
      
      originalRow.mfgLotNo = lotNo;
      originalRow.manufLotNo = lotNo;
      originalRow.qty = qty.toString();
      originalRow.expiryDate = exp;
      
      document.querySelector("#split-batch-modal").classList.add("hidden");
      renderStage("batch-checker");
      statusMessage.textContent = `Batch details updated successfully for ${lotNo}.`;
    } else {
      alert("Please enter a Lot Batch Number and Quantity.");
    }
    return;
  }

  // Split Batch close
  if (event.target.closest("[data-close-split-batch]")) {
    document.querySelector("#split-batch-modal").classList.add("hidden");
    return;
  }

  // Batch Check popup open
  if (event.target.closest("#batchchecker-btn-check")) {
    const rows = getBatchCheckerRows();
    const row = rows[selectedBatchCheckerRowKey];
    if (row) {
      if (!row.manufacturer || row.mfgId === "0") {
        showSystemMessage("Batch Check", "Please select manufacturer.", "Select a manufacturer before opening Batch Check.");
        return;
      }
      batchCheckerCheckedRows[getBatchCheckerRowKey(row)] = true;
      openBatchCheckVerifyPopup();
    }
    return;
  }

  // Batch Check confirm
  if (event.target.closest("#batch-check-confirm-btn")) {
    const nowDate = new Date().toLocaleDateString("en-GB").replace(/\//g, "-");
    const nowTime = new Date().toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    const user = currentLogin ? currentLogin.user : "checker.user";
    
    const rows = getBatchCheckerRows();
    const row = rows[selectedBatchCheckerRowKey];
    if (!row || !areBatchCheckerLineChecksComplete(row)) {
      statusMessage.textContent = "Complete all Batch Check verification items before verifying.";
      return;
    }
    const rowKey = getBatchCheckerRowKey(row);
    batchCheckerCheckedRows[rowKey] = true;
    batchCheckerVerifiedRows[rowKey] = { checker: user, date: nowDate, time: nowTime };
    row.status = "BatchCheck";
    
    document.querySelector("#batch-check-verify-modal").classList.add("hidden");
    renderStage("batch-checker");
    statusMessage.textContent = `Batch check verified by ${user} at ${nowTime} on ${nowDate}. Print PCL and Print Label is now enabled.`;
    return;
  }

  // Batch Check verify close
  if (event.target.closest("[data-close-batch-check-verify]")) {
    document.querySelector("#batch-check-verify-modal").classList.add("hidden");
    return;
  }

  // Generate PCL popup open
  if (event.target.closest("#batchchecker-generate-pcl") || event.target.closest("#batchchecker-generate-pcl-cold")) {
    openGeneratePclPopup();
    return;
  }

  // Submit Line Clearance
  if (event.target.closest("#pcl-clearance-submit-btn")) {
    document.querySelector("#generate-pcl-modal").classList.add("hidden");
    
    const rows = getBatchCheckerRows();
    const row = rows[selectedBatchCheckerRowKey];
    row.printType = "Printed - PCL";
    row.status = "Printer";
    batchCheckerPclGeneratedRows[getBatchCheckerRowKey(row)] = { user: currentLogin ? currentLogin.user : "batch.checker", dateTime: getAssemblyAuditTimestamp() };

    // Add to bnsProducts if not already there, so it is available in BNS Batch Add (bar-creation)
    const exists = bnsProducts.some(p => p.batch === row.batchNo);
    if (!exists) {
      bnsProducts.push({
status: "Active",
site: "WHO",
country: row.country,
partNo: row.partNo,
product: row.product || row.description,
ecma: row.ecma,
strength: row.strength,
packSize: row.packSize,
batch: row.batchNo,
expiry: row.expiryDate,
quantity: row.qty,
imp: row.orderNo,
invoice: row.invoice || "2904",
description: row.description || row.product,
warehouse: "Q-25-A",
pl: "18799/3264",
productId: row.productId,
foreignName: row.foreignName,
unitsPerPack: "1",
productIntroduced: "11 Sep 2020",
leafletDate: "04 Feb 2025",
dateRevised: "09 Apr 2025",
variationInfo: "",
supplierName: row.supplier,
reviewDate: row.reviewDate,
supplierInvoice: row.invoice || "2904",
manufLotNo: row.batchNo + "-" + row.country.substring(0, 2),
category: "Relabelling",
batchType: "Composite",
routeInstruction: "Relabel only",
routeType: "Relabelling",
leafletRequired: true,
leafletQuantity: row.qty,
blisterRequired: "Yes",
cartonQuantity: "0",
brailleRequired: true,
brailleQuantity: row.qty
      });
    }
    
    selectedBatchCheckerRowKey = null;
    batchCheckerDashboardOpen = true;
    renderStage("batch-checker");
    statusMessage.textContent = `User sign off completed and PCL generated for ${row.batchNo}. Batch moved to BNS Batch Add queue.`;
    return;
  }

  // Generate PCL close
  if (event.target.closest("[data-close-generate-pcl]")) {
    document.querySelector("#generate-pcl-modal").classList.add("hidden");
    return;
  }

  // View Supplier Declaration
  const supplierDeclarationClick = event.target.closest("[data-batchchecker-view-supplier-declaration]");
  if (supplierDeclarationClick) {
    const idx = Number(supplierDeclarationClick.dataset.batchcheckerViewSupplierDeclaration);
    const row = getBatchCheckerRows()[idx];
    if (row) openBatchCheckerDocumentViewer(row, "supplier");
    return;
  }

  // View Temperature Record
  const temperatureRecordClick = event.target.closest("[data-batchchecker-view-temperature-record]");
  if (temperatureRecordClick) {
    const idx = Number(temperatureRecordClick.dataset.batchcheckerViewTemperatureRecord);
    const row = getBatchCheckerRows()[idx];
    if (row) openBatchCheckerDocumentViewer(row, "temperature");
    return;
  }
  // View Product Mockup
  const mockupClick = event.target.closest("[data-batchchecker-view-mockup]");
  if (mockupClick) {
    const prodId = mockupClick.dataset.batchcheckerViewMockup;
    const imgEl = document.querySelector("#image-viewer-img");
    imgEl.src = "carton_mockup.png";
    document.querySelector("#image-viewer-title").textContent = `Product Mockup - Carton (ID: ${prodId})`;
    document.querySelector("#image-viewer-modal").classList.remove("hidden");
    return;
  }

  // View Raw Pack Scans
  const scanClick = event.target.closest("[data-batchchecker-view-scan]");
  if (scanClick) {
    const prodId = scanClick.dataset.batchcheckerViewScan;
    const imgEl = document.querySelector("#image-viewer-img");
    imgEl.src = "drug_capsule_mockup.png";
    document.querySelector("#image-viewer-title").textContent = `Raw Pack Scan - Drug (ID: ${prodId})`;
    document.querySelector("#image-viewer-modal").classList.remove("hidden");
    return;
  }

  // Close image viewer modal
  if (event.target.closest("#close-image-viewer") || event.target.closest("#close-image-viewer-btn")) {
    document.querySelector("#image-viewer-modal").classList.add("hidden");
    return;
  }

  // Reprint Goods In Label
  if (event.target.closest("#batchchecker-reprint-label")) {
    const rows = getBatchCheckerRows();
    const row = rows[selectedBatchCheckerRowKey];
    const record = markBatchCheckerLabelPrinted(row, "Goods In Label");
    if (record) {
      renderStage("batch-checker");
      statusMessage.textContent = `Goods In Label printed for selected line ${row.batchNo} by ${record.user} at ${record.dateTime}. Print PCL and Print Label is now available for this line after selection.`;
    }
    return;
  }

  // Print Box Label
  if (event.target.closest("#batchchecker-print-box")) {
    const rows = getBatchCheckerRows();
    const row = rows[selectedBatchCheckerRowKey];
    const record = markBatchCheckerLabelPrinted(row, "Box Label");
    if (record) {
      renderStage("batch-checker");
      statusMessage.textContent = `Box label printed for selected line ${row.batchNo} by ${record.user} at ${record.dateTime}. Print PCL and Print Label is now available for this line after selection.`;
    }
    return;
  }

  const packingTab = event.target.closest("[data-packing-tab]");
  if (packingTab) {
    packingListMode = packingTab.dataset.packingTab;
    renderStage("packing-list");
    if (packingListMode === "documents") setTimeout(updateRpDocumentsAvailability, 0);
    return;
  }

  if (event.target.closest("[data-rp-docs-back]")) {
    selectedRpPackPo = null;
    renderStage("packing-list");
    return;
  }

  const poSelectTrigger = event.target.closest("[data-rp-select-po]");
  if (poSelectTrigger) {
    selectedRpPackPo = poSelectTrigger.dataset.rpSelectPo;
    renderStage("packing-list");
    if (packingListMode === "documents") setTimeout(updateRpDocumentsAvailability, 0);
    return;
  }

  if (event.target.id === "pl-add-clear-btn") {
    packingListSelectedPo = "";
    packingListSearch = "";
    renderStage("packing-list");
    statusMessage.textContent = "Add Packing List search cleared.";
    return;
  }

  if (event.target.id === "pl-add-search-btn") {
    const input = document.querySelector("#pl-add-po-input");
    const poNo = input ? input.value.trim() : "";
    if (poNo) {
      packingListSelectedPo = poNo;
      packingListSearch = poNo;
      
      const existingRows = getPackingListRows().filter(row => row.orderNo === poNo);
      const hasRealData = existingRows.some(row => row.partNo && row.description);
      
      if (!hasRealData) {
        packingListRowsState = getPackingListRows().filter(row => row.orderNo !== poNo);
        const newRows = [];
        for (let i = 0; i < 5; i++) {
          newRows.push({
            orderNo: poNo,
            lineNo: String(i + 1),
            partNo: "",
            description: "",
            batchNo: "",
            expiryDate: "",
            qty: "",
            boxes: "",
            suppName: "",
            suppCode: "",
            country: "",
            ecma: "",
            mfgLotNo: "",
            rowId: `pl-new-${poNo}-${i + 1}`
          });
        }
        packingListRowsState = getPackingListRows().concat(newRows);
      }
      
      if (!rpPackWorkflows[poNo]) {
        rpPackWorkflows[poNo] = createPackingWorkflow(poNo);
      }
      
      renderStage("packing-list");
      statusMessage.textContent = `PO ${poNo} created. Enter item details manually.`;
    }
    return;
  }

  if (event.target.id === "pl-add-line-btn") {
    if (isPackingListLocked()) {
      statusMessage.textContent = "Packing List is generated and locked. Add line is disabled.";
      return;
    }
    const poNo = packingListSelectedPo;
    if (poNo) {
      const rows = getPackingListRows().filter(r => r.orderNo === poNo);
      const nextIndex = rows.length + 1;
      const newRow = {
        orderNo: poNo,
        lineNo: String(nextIndex),
        partNo: "",
        description: "",
        batchNo: "",
        expiryDate: "",
        qty: "",
        boxes: "",
        suppName: "",
        suppCode: "",
        country: "",
        ecma: "",
        mfgLotNo: "",
        rowId: `pl-new-${poNo}-${nextIndex}`
      };
      packingListRowsState = getPackingListRows().concat(newRow);
      renderStage("packing-list");
      statusMessage.textContent = "New line added to packing list.";
    }
    return;
  }

  if (event.target.id === "pl-add-save-btn" || event.target.closest("[data-packing-save]")) {
    if (isPackingListLocked()) {
      statusMessage.textContent = "Packing List is generated and locked. Save is disabled.";
      return;
    }
    statusMessage.textContent = `PO ${packingListSelectedPo} packing list draft saved successfully.`;
    return;
  }

  if (event.target.id === "pl-add-remove-btn" || event.target.closest("[data-remove-packing-lines]")) {
    if (isPackingListLocked()) {
      statusMessage.textContent = "Packing List is generated and locked. Remove line is disabled.";
      return;
    }
    const rows = getPackingListRows().filter(r => r.orderNo === packingListSelectedPo);
    if (rows.length > 0) {
      const lastRow = rows[rows.length - 1];
      packingListRowsState = getPackingListRows().filter(r => r.rowId !== lastRow.rowId);
      renderStage("packing-list");
      statusMessage.textContent = `Removed last line: ${lastRow.lineNo}`;
    }
    return;
  }

  if (event.target.id === "pl-add-generate-btn" || event.target.closest("[data-generate-packing-list]") || event.target.closest("[data-view-generated-packing-list]")) {
    const visibleRows = currentStageId === "packing-list" ? getVisiblePackingListRowsSnapshot() : null;
    const visiblePoNo = visibleRows && visibleRows.length && visibleRows.every((row) => row.orderNo === visibleRows[0].orderNo) ? visibleRows[0].orderNo : "";
    const poNo = visiblePoNo || packingListSelectedPo || packingListSearch || "C13719";
    packingListSelectedPo = poNo;
    packingListSearch = poNo;
    if (canGeneratePackingList(poNo) || packingListGenerated) {
      if (!rpPackWorkflows[poNo]) {
        rpPackWorkflows[poNo] = createPackingWorkflow(poNo);
      }
      openPackingListPreview(poNo, visibleRows);
    } else {
      statusMessage.textContent = "Error: All lines must be verified and printed before generating the packing list.";
    }
    return;
  }

  const splitPackingTrigger = event.target.closest("[data-split-packing-line]");
  if (splitPackingTrigger) {
    if (isPackingListLocked()) {
      statusMessage.textContent = "Packing List is generated and locked. Split line is disabled.";
      return;
    }
    splitPackingLine(splitPackingTrigger.dataset.splitPackingLine);
    return;
  }

  const plVerifyTrigger = event.target.closest("[data-pl-verify-print]");
  if (plVerifyTrigger) {
    if (isPackingListLocked()) {
      statusMessage.textContent = "Packing List is generated and locked. Verify and print is disabled.";
      return;
    }
    const key = plVerifyTrigger.dataset.plVerifyPrint;
    const row = getPackingListRows().find(r => getPackingLineKey(r) === key);
    if (row) {
      const boxes = parseInt(row.boxes) || 1;
      const qty = parseInt(row.qty) || 0;
      
      const printAction = () => {
        const now = new Date().toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" });
        packingLabelPrintRecords[key] = { user: currentLogin ? currentLogin.user : "goods.in", dateTime: now, printedCount: boxes };
        statusMessage.textContent = `Verified and printed ${boxes} labels for ${row.description}. Line clearance recorded.`;
        renderStage("packing-list");
      };
      
      requestUserSignoff(printAction, "Print PCL and Print Label");
      
      // Override default text inside the modal for custom style
      document.querySelector("#app-confirm-title").textContent = "Print PCL and Print Label";
      document.querySelector("#app-confirm-header").textContent = "Verify Line Clearance?";
      document.querySelector("#app-confirm-copy").textContent = `Confirm verification and printing of ${boxes} packing labels for ${row.description} (Qty: ${qty})?`;
      const yesButton = document.querySelector("#app-confirm-yes");
      if (yesButton) {
        yesButton.textContent = "Yes, Verify & Print";
      }
    }
    return;
  }

  const plPreviewTrigger = event.target.closest("[data-pl-preview-doc]");
  if (plPreviewTrigger) {
    const poNo = plPreviewTrigger.dataset.plPreviewPo;
    const docId = plPreviewTrigger.dataset.plPreviewDoc;
    openDocumentPreview(poNo, docId);
    return;
  }

  const rpViewTrigger = event.target.closest("[data-rp-view-file]");
  if (rpViewTrigger) {
    const docId = rpViewTrigger.dataset.rpViewFile;
    const poNo = rpViewTrigger.dataset.rpPo;
    openDocumentPreview(poNo, docId);
    return;
  }

  if (event.target.closest("[data-pl-preview-generated-packing-list]")) {
    const trigger = event.target.closest("[data-pl-preview-generated-packing-list]");
    const poNo = trigger.dataset.plPreviewPo || selectedRpPackPo || selectedRpApprovalPo || packingListSelectedPo;
    markGeneratedPackingListViewedForCurrentContext(poNo);
    openPackingListPreview(poNo);
    if (currentStageId === "rp-pack") setTimeout(updateRpApprovalAvailability, 0);
    if (currentStageId === "packing-list" && packingListMode === "documents") setTimeout(updateRpDocumentsAvailability, 0);
    return;
  }

  if (event.target.closest("[data-rp-view-generated-packing-list]")) {
    const poNo = selectedRpApprovalPo || selectedRpPackPo || packingListSelectedPo;
    markGeneratedPackingListViewedForCurrentContext(poNo);
    openPackingListPreview(poNo);
    if (currentStageId === "rp-pack") setTimeout(updateRpApprovalAvailability, 0);
    if (currentStageId === "packing-list" && packingListMode === "documents") setTimeout(updateRpDocumentsAvailability, 0);
    return;
  }

  if (event.target.id === "pl-preview-verify-btn") {
    const poNo = activePreviewPo || (currentStageId === "packing-list" && packingListMode === "documents"
      ? (selectedRpPackPo || packingListSelectedPo)
      : currentStageId === "rp-pack"
        ? (selectedRpApprovalPo || selectedRpPackPo || packingListSelectedPo)
        : (packingListSelectedPo || selectedRpPackPo || selectedRpApprovalPo));
    if (rpPackWorkflows[poNo]) {
      if (!rpPackWorkflows[poNo].viewedDocs) {
        rpPackWorkflows[poNo].viewedDocs = {};
      }
      rpPackWorkflows[poNo].viewedDocs["generated-packing-list"] = true;
      if (currentStageId === "rp-pack") {
        getRpTaskViewedDocs(rpPackWorkflows[poNo])["generated-packing-list"] = true;
      }
      statusMessage.textContent = "Generated PO Packing List viewed.";
      closePrintPreview();
      renderStage(currentStageId);
      if (currentStageId === "rp-pack") {
        setTimeout(updateRpApprovalAvailability, 0);
      } else if (currentStageId === "packing-list") {
        updateRpDocumentsAvailability();
      }
    }
    return;
  }

  if (event.target.closest("[data-packing-search-button]")) {
    const searchInput = document.querySelector("[data-packing-search]");
    if (searchInput) {
      packingListSearch = searchInput.value;
      packingListSelectedPo = searchInput.value || packingListSelectedPo;
    }
    packingListMode = "view";
    renderStage("packing-list");
    statusMessage.textContent = `Search results for PO ${packingListSelectedPo} loaded.`;
    return;
  }

  const printPackingLabelTrigger = event.target.closest("[data-print-packing-label]");
  if (printPackingLabelTrigger) {
    if (isPackingListLocked()) {
      statusMessage.textContent = "Packing List is generated and locked. Print Packing Label is disabled.";
      return;
    }
    requestUserSignoff(() => printPackingLabel(printPackingLabelTrigger.dataset.printPackingLabel), "Packing Label");
    return;
  }

  if (event.target.closest("[data-print-selected-po-labels]")) {
    if (isPackingListLocked()) {
      statusMessage.textContent = "Packing List is generated and locked. Print PO Packing Label is disabled.";
      return;
    }
    requestUserSignoff(printSelectedPoPackingLabels, "selected PO Packing Label lines");
    return;
  }

  if (event.target.closest("[data-delete-packing-lines]")) {
    if (isPackingListLocked()) {
      statusMessage.textContent = "Packing List is generated and locked. Delete is disabled.";
      return;
    }
    deleteSelectedPackingLines("deleted");
    return;
  }


  if (event.target.closest("[data-sign-po-packing-list]")) {
    requestUserSignoff(signPoPackingList, "generated PO Packing List");
    return;
  }

  if (event.target.closest("#rp-documents-signoff-button")) {
    updateRpDocumentsAvailability();
    const button = document.querySelector("#rp-documents-signoff-button");
    if (button && button.disabled) {
      statusMessage.textContent = button.title || "Upload and verify all RPi Pack documents before sign off.";
      return;
    }
    requestAppConfirmation(
      completeRpDocumentsSignoff,
      "RPi Pack Sign Off",
      "Confirm RPi Pack document sign off?",
      `This will capture ${currentLogin ? currentLogin.user : "goods.in"} with the current date and time.`,
      "Yes, Sign Off"
    );
    return;
  }

  if (event.target.closest("[data-rp-approval-search-button]")) {
    renderStage("rp-pack");
    statusMessage.textContent = "RPi Task search applied.";
    return;
  }

  const rpApprovalPoTrigger = event.target.closest("[data-rp-approval-select-po]");
  if (rpApprovalPoTrigger) {
    selectedRpApprovalPo = rpApprovalPoTrigger.dataset.rpApprovalSelectPo;
    renderStage("rp-pack");
    return;
  }

  if (event.target.id === "rp-verify-signoff-btn") {
    updateRpApprovalAvailability();
    if (event.target.disabled) {
      statusMessage.textContent = "Complete all checklist answers and verify every document before sign off.";
      return;
    }
    const poNo = selectedRpApprovalPo;
    const overlay = document.createElement("div");
    overlay.id = "rp-pdf-modal-container";
    overlay.innerHTML = renderRpApprovalExactPdfModal(poNo, rpApprovalAnswers[poNo], null);
    document.body.appendChild(overlay);
    
    const closeSignedPreview = () => {
      overlay.remove();
      renderStage("rp-pack");
    };
    document.querySelector("#rp-pdf-close").addEventListener("click", closeSignedPreview);
    document.querySelector("#rp-pdf-cancel").addEventListener("click", closeSignedPreview);
    
    document.querySelector("#rp-pdf-sign-btn").addEventListener("click", () => {
      const rpStage = stages.find((stage) => stage.id === "rp-pack");
      const rpUser = currentLogin && currentLogin.user && currentLogin.user !== "goods.in" ? currentLogin.user : (rpStage ? rpStage.user : "rp.user");
      const sigObj = {
        user: rpUser,
        dateTime: getAssemblyAuditTimestamp()
      };
      rpApprovalSignoffs[poNo] = sigObj;
      const po = rpPackWorkflows[poNo];
      if (po) {
        po.status = "RPi Approved";
      }
      overlay.innerHTML = renderRpApprovalExactPdfModal(poNo, rpApprovalAnswers[poNo], sigObj);
      document.querySelector("#rp-pdf-close").addEventListener("click", closeSignedPreview);
      document.querySelector("#rp-pdf-cancel").addEventListener("click", closeSignedPreview);
      statusMessage.textContent = `RPi Task digitally signed by ${sigObj.user} at ${sigObj.dateTime}. Moved to Batch Checker queue.`;
      setTimeout(() => {
        selectedRpApprovalPo = null;
        overlay.remove();
        renderStage("rp-pack");
      }, 900);
    });
    return;
  }

  const rpApproveOpen = event.target.closest("[data-rp-approve-open-checklist]");
  if (rpApproveOpen) {
    const poNo = rpApproveOpen.dataset.rpApproveOpenChecklist;
    if (rpPackWorkflows[poNo]) {
      rpPackWorkflows[poNo].rpChecklistOpen = true;
      rpPackWorkflows[poNo].status = "RPi Checklist Open";
      selectedRpApprovalPo = poNo;
      statusMessage.textContent = `RPi Task approved document pack for PO ${poNo}. Checklist opened.`;
      renderStage("rp-pack");
    }
    return;
  }

  const rpRejectPo = event.target.closest("[data-rp-reject-po]");
  if (rpRejectPo) {
    openRpRejectPopup(rpRejectPo.dataset.rpRejectPo);
    return;
  }

  if (event.target.id === "pl-preview-download-btn") {
    statusMessage.textContent = "Generated PO Packing List download started.";
    closePrintPreview();
    renderStage(currentStageId);
    return;
  }
  const modernPillBtn = event.target.closest(".modern-pill-btn");
  if (modernPillBtn) {
    const field = modernPillBtn.dataset.rpField;
    const val = modernPillBtn.dataset.val;
    const poNo = selectedRpApprovalPo;
    
    if (!rpApprovalAnswers[poNo]) {
      rpApprovalAnswers[poNo] = {};
    }
    
    if (rpApprovalAnswers[poNo][field] === val) {
      delete rpApprovalAnswers[poNo][field];
    } else {
      rpApprovalAnswers[poNo][field] = val;
    }
    
    const group = modernPillBtn.closest(".modern-check-options");
    if (group) {
      group.querySelectorAll(".modern-pill-btn").forEach((button) => {
        button.classList.remove("active-yes", "active-no", "active-na");
      });
      if (rpApprovalAnswers[poNo][field] === val) {
        const activeClass = val === "Y" ? "active-yes" : val === "N" ? "active-no" : "active-na";
        modernPillBtn.classList.add(activeClass);
      }
    }
    if (field === "fe-status") {
      const reasonInput = document.querySelector("#rp-form-inactive-reason");
      if (reasonInput) {
        const inactive = rpApprovalAnswers[poNo][field] === "N";
        reasonInput.disabled = !inactive;
        if (!inactive) {
          reasonInput.value = "";
          delete rpApprovalAnswers[poNo]["inactive-reason"];
        }
      }
    }
    updateRpApprovalAvailability();
    return;
  }

  if (event.target.closest("[data-close-rp-approval-form]")) {
    document.querySelector("#rp-approval-form-modal").classList.add("hidden");
    return;
  }

  const labelPrintTrigger = event.target.closest("[data-open-label-print]");
  if (labelPrintTrigger) {
    labelSelectedProduct = bnsProducts.find((product) => product.batch === labelPrintTrigger.dataset.openLabelPrint) || null;
    printerSection = "label-detail";
    renderStage("label-printing");
    return;
  }

  const leafletPrintTrigger = event.target.closest("[data-open-leaflet-print]");
  if (leafletPrintTrigger) {
    leafletSelectedProduct = bnsProducts.find((product) => product.batch === leafletPrintTrigger.dataset.openLeafletPrint) || null;
    printerSection = "leaflet-detail";
    renderStage("label-printing");
    return;
  }

  const cartonPrintTrigger = event.target.closest("[data-open-carton-print]");
  if (cartonPrintTrigger) {
    cartonSelectedProduct = bnsProducts.find((product) => product.batch === cartonPrintTrigger.dataset.openCartonPrint) || null;
    printerSection = "carton-detail";
    renderStage("label-printing");
    return;
  }

  const braillePrintTrigger = event.target.closest("[data-open-braille-print]");
  if (braillePrintTrigger) {
    brailleSelectedProduct = bnsProducts.find((product) => product.batch === braillePrintTrigger.dataset.openBraillePrint) || null;
    printerSection = "braille-detail";
    renderStage("label-printing");
    return;
  }

  const leafletFoldingTrigger = event.target.closest("[data-open-leaflet-folding]");
  if (leafletFoldingTrigger) {
    leafletFoldingSelectedProduct = bnsProducts.find((product) => product.batch === leafletFoldingTrigger.dataset.openLeafletFolding) || null;
    renderStage("leaflet-folding");
    return;
  }

  const preAssemblyTrigger = event.target.closest("[data-open-preassembly]");
  if (preAssemblyTrigger) {
    preAssemblySelectedProduct = bnsProducts.find((product) => product.batch === preAssemblyTrigger.dataset.openPreassembly) || null;
    renderStage("pre-assembly-qc");
    return;
  }

  const productionTrigger = event.target.closest("[data-open-production]");
  if (productionTrigger) {
    const product = bnsProducts.find((item) => item.batch === productionTrigger.dataset.openProduction) || null;
    if (!product) return;
    if (window.confirm("This checklist will be done in hand held device.")) {
      const batchNumber = product.batch;
      const boxCount = String(Math.max(1, Math.ceil(Number(product.quantity || 0) / 100)));
      productionRecords[batchNumber] = {
        ...(productionRecords[batchNumber] || {}),
        user: currentLogin ? currentLogin.user : "production.control",
        dateTime: getAssemblyAuditTimestamp(),
        boxCount,
        roomNo: productionRecords[batchNumber] ? productionRecords[batchNumber].roomNo || "Room 2" : "Room 2",
        handheldChecklist: true
      };
      if (!productionAllocatedBatchNumbers.includes(batchNumber)) productionAllocatedBatchNumbers.push(batchNumber);
      productionSelectedProduct = null;
      renderStage("room-allocation");
      statusMessage.textContent = `Batch ${batchNumber} checklist assigned to handheld device and removed from Production Controller queue.`;
    }
    return;
  }

  const assemblyTrigger = event.target.closest("[data-open-assembly]");
  if (assemblyTrigger) {
    const selectedAssemblyProduct = bnsProducts.find((product) => product.batch === assemblyTrigger.dataset.openAssembly) || null;
    if (!selectedAssemblyProduct) return;
    const selectedAssemblyRecord = assemblyRecords[selectedAssemblyProduct.batch] || {};
    const startRecord = getAssemblyLifecycleRecord(selectedAssemblyRecord, "start");
    if (!startRecord.dateTime) {
      requestAssemblyBatchStart(selectedAssemblyProduct);
      return;
    }
    assemblySelectedProduct = selectedAssemblyProduct;
    assemblyExtraIpcRows = 0;
    assemblyActiveTab = "materials";
    renderStage("assembly-room");
    return;
  }

  const assemblyTab = event.target.closest("[data-assembly-tab]");
  if (assemblyTab) {
    assemblyActiveTab = assemblyTab.dataset.assemblyTab;
    document.querySelectorAll("[data-assembly-tab]").forEach((tab) => {
      tab.classList.toggle("active", tab === assemblyTab);
    });
    document.querySelectorAll("[data-assembly-panel]").forEach((panel) => {
      panel.classList.toggle("active", panel.dataset.assemblyPanel === assemblyTab.dataset.assemblyTab);
    });
    return;
  }


  const assemblyPageSignoff = event.target.closest("[data-assembly-page-signoff]");
  if (assemblyPageSignoff) {
    requestUserSignoff(() => signOffAssemblyPage(assemblyPageSignoff.dataset.assemblyPageSignoff), "this assembly page");
    return;
  }

  if (event.target.closest("[data-add-ipc-row]")) {
    assemblyExtraIpcRows += 1;
    renderStage("assembly-room");
    return;
  }

  const postAssemblyTrigger = event.target.closest("[data-open-postassembly]");
  if (postAssemblyTrigger) {
    postAssemblySelectedProduct = bnsProducts.find((product) => product.batch === postAssemblyTrigger.dataset.openPostassembly) || null;
    renderStage("post-assembly-qc");
    return;
  }

  if (event.target.closest("[data-postassembly-search-button]")) {
    renderStage("post-assembly-qc");
    statusMessage.textContent = "Production Checking search applied.";
    return;
  }

  if (event.target.closest("#postassembly-print-button")) {
    printQuarantineLabel();
    return;
  }

  if (event.target.closest("[data-test-quarantine-print]")) {
    statusMessage.textContent = "Test quarantine label sent to printer.";
    return;
  }

  const preQpLogSelect = event.target.closest("[data-preqp-log-select]");
  if (preQpLogSelect) {
    const batchNumber = preQpLogSelect.dataset.preqpLogSelect;
    if (preQpLogSelect.checked && !preQpReleaseLogSelection.includes(batchNumber)) preQpReleaseLogSelection.push(batchNumber);
    if (!preQpLogSelect.checked) preQpReleaseLogSelection = preQpReleaseLogSelection.filter((batch) => batch !== batchNumber);
    renderStage("pre-qp");
    statusMessage.textContent = preQpReleaseLogSelection.length ? `${preQpReleaseLogSelection.length} verified Pre QP batch selected for QP Release Log.` : "No Pre QP batches selected for QP Release Log.";
    return;
  }

  if (event.target.closest("[data-preqp-select-verified]")) {
    preQpReleaseLogSelection = getPreQpProducts()
      .filter((product) => preQpCheckedBatchNumbers.includes(product.batch))
      .map((product) => product.batch);
    renderStage("pre-qp");
    statusMessage.textContent = `${preQpReleaseLogSelection.length} verified Pre QP batch selected for QP Release Log.`;
    return;
  }

  if (event.target.closest("#preqp-print-release-log-button")) {
    openPreQpReleaseLogPrintPreview();
    return;
  }
  const preQpTrigger = event.target.closest("[data-open-preqp]");
  if (preQpTrigger) {
    preQpSelectedProduct = bnsProducts.find((product) => product.batch === preQpTrigger.dataset.openPreqp) || null;
    renderStage("pre-qp");
    return;
  }

  const qpCertifiedLabelSelect = event.target.closest("[data-qp-certified-label-select]");
  if (qpCertifiedLabelSelect) {
    const batchNumber = qpCertifiedLabelSelect.dataset.qpCertifiedLabelSelect;
    if (qpCertifiedLabelSelect.checked && !qpCertifiedLabelSelection.includes(batchNumber)) qpCertifiedLabelSelection.push(batchNumber);
    if (!qpCertifiedLabelSelect.checked) qpCertifiedLabelSelection = qpCertifiedLabelSelection.filter((batch) => batch !== batchNumber);
    renderStage("qp-certified");
    statusMessage.textContent = qpCertifiedLabelSelection.length ? `${qpCertifiedLabelSelection.length} approved batch selected for release label printing.` : "No approved batch selected for release label printing.";
    return;
  }

  const qpTrigger = event.target.closest("[data-open-qp]");
  if (qpTrigger) {
    if (currentStageId === "qp-certified") return;
    qpSelectedProduct = bnsProducts.find((product) => product.batch === qpTrigger.dataset.openQp) || null;
    qpChecklistOpen = false;
    renderStage("qp-release");
    return;
  }

  if (event.target.closest("[data-qp-back-list]")) {
    qpSelectedProduct = null;
    qpChecklistOpen = false;
    renderStage("qp-release");
    return;
  }

  if (event.target.closest("[data-qp-back-dashboard]")) {
    qpChecklistOpen = false;
    renderStage("qp-release");
    return;
  }

  if (event.target.closest("[data-qp-approve-batch]")) {
    if (!qpSelectedProduct || !areAllQpDashboardDocumentsVerified(qpSelectedProduct)) {
      statusMessage.textContent = "Verify every QP document before approving this batch.";
      return;
    }
    setQpBatchDecision("Approve");
    return;
  }

  if (event.target.closest("[data-qp-reject-batch]")) {
    setQpBatchDecision("Rejected");
    return;
  }

  if (event.target.closest("[data-qp-hold-batch]")) {
    setQpBatchDecision("Hold");
    return;
  }
  if (event.target.closest("[data-qp-open-checklist]")) {
    if (!qpSelectedProduct || !areAllQpDashboardDocumentsVerified(qpSelectedProduct)) {
      statusMessage.textContent = "Verify every QP document before opening the checklist.";
      return;
    }
    qpChecklistOpen = true;
    renderStage("qp-release");
    return;
  }
  if (event.target.closest("[data-preqp-search-button]")) {
    renderStage("pre-qp");
    statusMessage.textContent = "Pre QP search applied.";
    return;
  }

  if (event.target.closest("[data-qp-search-button]")) {
    renderStage(currentStageId === "qp-certified" ? "qp-certified" : "qp-release");
    statusMessage.textContent = currentStageId === "qp-certified" ? "QP Certified Batches search applied." : "QP Release search applied.";
    return;
  }

  if (event.target.closest("[data-printer-search-button]")) {
    renderStage("label-printing");
    statusMessage.textContent = "Printer batch search applied.";
    return;
  }

  const preQpDocTrigger = event.target.closest("[data-view-preqp-document]");
  if (preQpDocTrigger) {
    openPreQpDocumentPreview(preQpDocTrigger.dataset.viewPreqpDocument);
    return;
  }

  const qpDocTrigger = event.target.closest("[data-view-qp-document]");
  if (qpDocTrigger) {
    openQpDocumentPreview(qpDocTrigger.dataset.viewQpDocument);
    return;
  }

  if (event.target.closest("[data-view-qp-release-log]")) {
    openQpReleaseLogPreview();
    return;
  }

  if (event.target.closest("[data-save-qp-release-log]")) {
    saveQpReleaseLog();
    return;
  }

  if (event.target.closest("[data-sign-qp-release-log]")) {
    requestUserSignoff(signQpReleaseLog, "QP Release Log");
    return;
  }

  if (event.target.closest("#preqp-preview-log-button")) {
    previewPreQpReleaseLog();
    return;
  }

  if (event.target.closest("#preqp-proceed-log-button")) {
    proceedGeneratePreQpReleaseLog();
    return;
  }

  if (event.target.closest("[data-print-release-label]")) {
    if (!qpCertifiedLabelSelection.length) {
      statusMessage.textContent = "Select an approved batch before printing release labels.";
      return;
    }
    statusMessage.textContent = `Release label print requested for ${qpCertifiedLabelSelection.length} approved batch${qpCertifiedLabelSelection.length === 1 ? "" : "es"}.`;
    return;
  }

  if (event.target.closest("[data-preqp-reprint-log]")) {
    statusMessage.textContent = "QP Certified Batches reprint requested.";
    return;
  }

  if (event.target.closest("[data-preassembly-search-button]")) {
    renderStage("pre-assembly-qc");
    statusMessage.textContent = "Pre Assembly search applied.";
    return;
  }

  if (event.target.closest("[data-production-search-button]")) {
    renderStage("room-allocation");
    statusMessage.textContent = "Production Controller search applied.";
    return;
  }

  const mockupTrigger = event.target.closest("[data-view-mockup]");
  if (mockupTrigger) {
    openMockupPreview(mockupTrigger.dataset.viewMockup);
    return;
  }

  const printerSectionTrigger = event.target.closest("[data-printer-section]");
  if (printerSectionTrigger) {
    printerSection = printerSectionTrigger.dataset.printerSection;
    labelSelectedProduct = null;
    leafletSelectedProduct = null;
    cartonSelectedProduct = null;
    brailleSelectedProduct = null;
    renderStage("label-printing");
    return;
  }

  if (event.target.closest("#label-complete-button")) {
    requestUserSignoff(completeLabelPrinting, "Label Printing");
    return;
  }

  if (event.target.closest("#leaflet-complete-button")) {
    requestUserSignoff(completeLeafletPrinting, "Leaflet Printing");
    return;
  }

  if (event.target.closest("#carton-complete-button")) {
    requestUserSignoff(completeCartonPrinting, "Carton Printing");
    return;
  }

  if (event.target.closest("#braille-complete-button")) {
    requestUserSignoff(completeBraillePrinting, "Braille Printing");
    return;
  }

  if (event.target.closest("#leaflet-folding-complete-button")) {
    requestUserSignoff(completeLeafletFolding, "Leaflet Folding");
    return;
  }

  if (event.target.closest("#preassembly-complete-button")) {
    requestUserSignoff(completePreAssemblyCheck, "Pre Assembly");
    return;
  }

  if (event.target.closest("#production-complete-button")) {
    requestUserSignoff(completeProductionControl, "Production Controller");
    return;
  }

  if (event.target.closest("#postassembly-complete-button")) {
    requestUserSignoff(completePostAssembly, "Production Checking");
    return;
  }

  if (event.target.closest("#preqp-complete-button")) {
    requestUserSignoff(completePreQp, "Pre QP");
    return;
  }

  if (event.target.closest("#qp-release-complete-button")) {
    requestUserSignoff(completeQpRelease, "QP Release");
    return;
  }

  const printTrigger = event.target.closest("[data-print-labels]");
  if (printTrigger) {
    printLabels(printTrigger.dataset.printLabels);
    return;
  }

  const leafletPrintButton = event.target.closest("[data-print-leaflets]");
  if (leafletPrintButton) {
    printLeaflets(leafletPrintButton.dataset.printLeaflets);
    return;
  }

  const cartonPrintButton = event.target.closest("[data-print-cartons]");
  if (cartonPrintButton) {
    printCartons(cartonPrintButton.dataset.printCartons);
    return;
  }

  const braillePrintButton = event.target.closest("[data-print-braille]");
  if (braillePrintButton) {
    printBraille(braillePrintButton.dataset.printBraille);
    return;
  }

  if (event.target.closest("[data-create-bar-no]")) {
    closeCreateBarDialog();
  }
});

document.addEventListener("dblclick", (event) => {
  const splitTrigger = event.target.closest("[data-split-packing-line]");
  if (splitTrigger) {
    if (isPackingListLocked()) {
      statusMessage.textContent = "Packing List is generated and locked. Split line is disabled.";
      return;
    }
    splitPackingLine(splitTrigger.dataset.splitPackingLine);
  }
});











document.querySelector("#login-submit").addEventListener("click", submitLogin);
document.querySelector("#signoff-yes").addEventListener("click", confirmSignoff);
document.querySelector("#app-confirm-yes").addEventListener("click", confirmAppSignoff);
document.querySelector("#create-bar-yes").addEventListener("click", confirmCreateBar);

document.addEventListener("change", (event) => {
  if (event.target.matches("[data-packing-row-checkbox]")) {
    if (isPackingListLocked()) {
      event.target.checked = !event.target.checked;
      statusMessage.textContent = "Packing List is generated and locked. Editing is disabled.";
      return;
    }
    const key = event.target.dataset.packingRowKey;
    const prop = event.target.dataset.packingRowCheckbox;
    const val = event.target.checked;
    updatePackingRowValue(key, prop, val);
    return;
  }
  if (event.target.matches("[data-bns-filter]")) {
    bnsFilters[event.target.dataset.bnsFilter] = event.target.value;
    renderStage("bar-creation");
    statusMessage.textContent = "BNS Batch Add filter updated.";
    return;
  }
  if (event.target.matches("[data-rp-file-upload]")) {
    const poNo = event.target.dataset.rpPo;
    const docId = event.target.dataset.rpFileUpload;
    const file = event.target.files[0];
    if (file && rpPackWorkflows[poNo]) {
      const doc = rpPackWorkflows[poNo].documents.find((d) => d.id === docId);
      if (doc) {
        doc.uploaded = true;
        doc.fileName = file.name;
        doc.verified = false;
        if (rpPackWorkflows[poNo].status === "Rejected by RPi") {
          rpPackWorkflows[poNo].viewedDocs = {};
          rpPackWorkflows[poNo].rpTaskViewedDocs = {};
          rpPackWorkflows[poNo].status = "Signed Off";
        }
      }
    }
    updateRpDocumentsAvailability();
    renderStage("rp-pack");
    return;
  }
  if (event.target.matches("[data-pl-add-file]")) {
    const poNo = event.target.dataset.plAddPo;
    const docId = event.target.dataset.plAddFile;
    const file = event.target.files[0];
    if (file && rpPackWorkflows[poNo]) {
      const doc = rpPackWorkflows[poNo].documents.find((d) => d.id === docId);
      if (doc) {
        doc.uploaded = true;
        doc.fileName = file.name;
        doc.verified = false;
        if (rpPackWorkflows[poNo].status === "Rejected by RPi") {
          rpPackWorkflows[poNo].viewedDocs = {};
          rpPackWorkflows[poNo].rpTaskViewedDocs = {};
          rpPackWorkflows[poNo].status = "Signed Off";
        }
      }
    }
    renderStage("packing-list");
    statusMessage.textContent = `Document '${docId}' uploaded successfully.`;
    return;
  }
  if (event.target.matches("[data-process-check], [data-process-comment]")) {
    updateSignoffAvailability();
  }
  if (event.target.matches("[data-packing-check], [data-packing-input], [data-packing-evidence]")) {
    updatePackingListAvailability();
  }
  if (event.target.matches("[data-rp-document]")) {
    updateRpDocumentsAvailability();
  }
  if (event.target.matches("[data-rp-check]")) {
    updateRpApprovalAvailability();
  }
  if (event.target.matches("[data-label-evidence], [data-label-extra]")) {
    updateLabelCompletionAvailability();
    syncTestPrintButtons("label");
  }
  if (event.target.matches("[data-leaflet-evidence], [data-leaflet-extra]")) {
    updateLeafletCompletionAvailability();
    syncTestPrintButtons("leaflet");
  }
  if (event.target.matches("[data-carton-evidence], [data-carton-extra]")) {
    updateCartonCompletionAvailability();
  }
  if (event.target.matches("[data-braille-evidence], [data-braille-extra]")) {
    updateBrailleCompletionAvailability();
    syncTestPrintButtons("braille");
  }
  if (event.target.matches("[data-folding-line-clearance], [data-folding-quantity]")) {
    updateLeafletFoldingAvailability();
  }
  if (event.target.matches("[data-preassembly-material], [data-preassembly-input]")) {
    updatePreAssemblyAvailability();
  }
  if (event.target.matches("[data-production-check], [data-production-input]")) {
    updateProductionAvailability();
  }
  if (event.target.matches("[data-assembly-check], [data-assembly-input]")) {
    updateAssemblyAvailability();
  }
  if (event.target.matches("[data-postassembly-input], [data-postassembly-pack-check]")) {
    updatePostAssemblyAvailability();
  }
  if (event.target.matches("[data-preqp-doc-check]") && event.target.checked) {
    const row = event.target.closest("[data-preqp-doc-row]");
    if (row) {
      row.querySelectorAll("[data-preqp-doc-check]").forEach((check) => {
if (check !== event.target) check.checked = false;
      });
    }
  }
  if (event.target.matches("[data-preqp-input], [data-preqp-doc-check], [data-preqp-material-check]")) {
    updatePreQpAvailability();
  }
  if (event.target.matches("[data-qp-doc-check], [data-qp-input]")) {
    updateQpReleaseAvailability();
  }
  if (event.target.matches("[data-batchcheck-field-check]")) {
    const rows = getBatchCheckerRows();
    const row = rows[selectedBatchCheckerRowKey];
    if (row) {
      const checks = getBatchCheckerLineChecks(row);
      checks[Number(event.target.dataset.batchcheckFieldCheck)] = event.target.checked;
      const confirmBtn = document.querySelector("#batch-check-confirm-btn");
      if (confirmBtn) confirmBtn.disabled = !checks.every(Boolean);
    }
    return;
  }
  if (event.target.matches("[data-batchchecker-row-select]")) {
    selectedBatchCheckerRowKey = event.target.checked ? Number(event.target.dataset.batchcheckerRowSelect) : null;
    renderStage("batch-checker");
    return;
  }
  if (event.target.matches("[data-batchchecker-row-edit]")) {
    const rows = getBatchCheckerRows();
    const row = rows[Number(event.target.dataset.batchcheckerRowIndex)];
    if (row) {
      const field = event.target.dataset.batchcheckerRowEdit;
      if (!["mfgLotNo", "expiryDate", "qty"].includes(field)) return;
      row[field] = event.target.value;
      if (field === "mfgLotNo") row.manufLotNo = event.target.value;
      statusMessage.textContent = "Batch Checker row updated.";
    }
    return;
  }

  if (event.target.id === "chk-line-clearance" || event.target.classList.contains("pcl-checkbox")) {
    updatePclSubmissionAvailability();
  }
  
  if (event.target.classList.contains("rp-form-chk")) {
    const field = event.target.dataset.rpField;
    const value = event.target.dataset.val;
    
    if (!rpApprovalAnswers[selectedRpApprovalPo]) {
      rpApprovalAnswers[selectedRpApprovalPo] = {};
    }
    
    if (event.target.checked) {
      rpApprovalAnswers[selectedRpApprovalPo][field] = value;
    } else {
      delete rpApprovalAnswers[selectedRpApprovalPo][field];
    }
    
    // Uncheck other checkboxes for the same field
    document.querySelectorAll(`.rp-form-chk[data-rp-field='${field}']`).forEach(chk => {
      if (chk !== event.target) chk.checked = false;
    });
    
    // Enable/disable inactive reason input based on supplier status
    if (field === "fe-status") {
      const reasonInput = document.querySelector("#rp-form-inactive-reason");
      if (reasonInput) {
const isInactive = (value === "N" && event.target.checked);
reasonInput.disabled = !isInactive;
if (!isInactive) {
  reasonInput.value = "";
  delete rpApprovalAnswers[selectedRpApprovalPo]["inactive-reason"];
}
      }
    }
    
    updateRpApprovalAvailability();
  }
});

document.addEventListener("input", (event) => {
  const psField = event.target.closest("[data-ps-field]");
  if (psField) {
    const batch = psField.dataset.psBatch;
    const section = psField.dataset.psSection;
    const field = psField.dataset.psField;
    const value = event.target.value;
    
    if (!changeOfPackSizeData[batch]) {
      changeOfPackSizeData[batch] = {
receivedAs: { ecma: "", packSize: "", blisterPerPack: "", qty: "", totalBlisters: "", initials: "" },
assembledAs: { ecma: "", packSize: "", blisterPerPack: "", finishedQty: "", surplus: "", initials: "" },
printerAmendmentsInitials: "",
qcAmendmentsInitials: ""
      };
    }
    
    changeOfPackSizeData[batch][section][field] = value;
    
    // Automatically calculate total blisters: totalBlisters = qty * blisterPerPack
    if (section === "receivedAs" && (field === "qty" || field === "blisterPerPack")) {
      const qtyVal = parseInt(changeOfPackSizeData[batch].receivedAs.qty) || 0;
      const bppVal = parseInt(changeOfPackSizeData[batch].receivedAs.blisterPerPack) || 0;
      const total = qtyVal * bppVal;
      changeOfPackSizeData[batch].receivedAs.totalBlisters = total;
      
      const totalBlistersInput = document.querySelector(`[data-ps-batch="${batch}"][data-ps-section="receivedAs"][data-ps-field="totalBlisters"]`);
      if (totalBlistersInput) {
totalBlistersInput.value = total;
      }
    }
    
    updateLabelCompletionAvailability();
    updatePreAssemblyAvailability();
  }
  if (event.target.id === "rp-form-inactive-reason") {
    if (!rpApprovalAnswers[selectedRpApprovalPo]) rpApprovalAnswers[selectedRpApprovalPo] = {};
    rpApprovalAnswers[selectedRpApprovalPo]["inactive-reason"] = event.target.value;
    updateRpApprovalAvailability();
    return;
  }
  if (event.target.id === "rp-form-comments") {
    rpApprovalComments[selectedRpApprovalPo] = event.target.value;
    return;
  }
  if (event.target.matches("[data-batchchecker-filter]")) {
    batchCheckerFilters[event.target.dataset.batchcheckerFilter] = event.target.value;
    selectedBatchCheckerRowKey = null;
    renderStage("batch-checker");
    return;
  }
  if (event.target.matches("[data-rp-approval-search]")) {
    rpApprovalSearch = event.target.value;
    selectedRpApprovalPo = null;
    renderStage("rp-pack");
    statusMessage.textContent = "RPi Task PO search updated.";
    return;
  }
  if (event.target.matches("[data-packing-search]")) {
    packingListSearch = event.target.value;
    packingListSelectedPo = event.target.value || packingListSelectedPo;
    statusMessage.textContent = "Enter a PO number and click Search.";
    return;
  }
  if (event.target.matches("[data-bns-filter]")) {
    bnsFilters[event.target.dataset.bnsFilter] = event.target.value;
    renderStage("bar-creation");
    statusMessage.textContent = "BNS Batch Add filter updated.";
    return;
  }
  if (event.target.matches("[data-process-comment]")) {
    updateSignoffAvailability();
  }
  if (event.target.matches("[data-packing-row-input]")) {
    if (isPackingListLocked()) {
      statusMessage.textContent = "Packing List is generated and locked. Editing is disabled.";
      renderStage("packing-list");
      return;
    }
    updatePackingRowValue(event.target.dataset.packingRowKey, event.target.dataset.packingRowInput, event.target.value);
    return;
  }
  if (event.target.matches("[data-packing-input]")) {
    updatePackingListAvailability();
  }
  if (event.target.matches("[data-label-extra]")) {
    updateLabelCompletionAvailability();
    syncTestPrintButtons("label");
  }
  if (event.target.matches("[data-leaflet-extra]")) {
    updateLeafletCompletionAvailability();
    syncTestPrintButtons("leaflet");
  }
  if (event.target.matches("[data-carton-extra]")) {
    updateCartonCompletionAvailability();
  }
  if (event.target.matches("[data-braille-extra]")) {
    updateBrailleCompletionAvailability();
    syncTestPrintButtons("braille");
  }
  if (event.target.matches("[data-folding-quantity]")) {
    updateLeafletFoldingAvailability();
  }
  if (event.target.matches("[data-preassembly-search]")) {
    preAssemblySearch = event.target.value;
    renderStage("pre-assembly-qc");
    statusMessage.textContent = "Pre Assembly filter updated.";
    return;
  }
  if (event.target.matches("[data-preassembly-input]")) {
    updatePreAssemblyAvailability();
  }
  if (event.target.matches("[data-production-search]")) {
    productionSearch = event.target.value;
    renderStage("room-allocation");
    statusMessage.textContent = "Production Controller filter updated.";
    return;
  }
  if (event.target.matches("[data-production-input]")) {
    updateProductionAvailability();
  }
  if (event.target.matches("[data-assembly-search]")) {
    assemblySearch = event.target.value;
    const match = getAssemblyProducts().find((product) => exactBatchOrMfgLotMatch(product, assemblySearch));
    if (match) {
      assemblySelectedProduct = match;
      renderStage("assembly-room");
      statusMessage.textContent = `Assembly Room opened for ${match.batch}.`;
      return;
    }
    renderStage("assembly-room");
    statusMessage.textContent = "Assembly Room filter updated.";
    return;
  }
  if (event.target.matches("[data-assembly-input]")) {
    updateAssemblyAvailability();
  }
  if (event.target.matches("[data-postassembly-search]")) {
    postAssemblySearch = event.target.value;
    const match = getPostAssemblyProducts().find((product) => exactBatchOrMfgLotMatch(product, postAssemblySearch));
    if (match) {
      postAssemblySelectedProduct = match;
      renderStage("post-assembly-qc");
      statusMessage.textContent = `Production Checking opened for ${match.batch}.`;
      return;
    }
    renderStage("post-assembly-qc");
    statusMessage.textContent = "Production Checking filter updated.";
    return;
  }
  if (event.target.matches("[data-postassembly-input], [data-postassembly-pack-check]")) {
    updatePostAssemblyAvailability();
  }
  if (event.target.matches("[data-preqp-search]")) {
    preQpSearch = event.target.value;
    const normalizedPreQpSearch = preQpSearch.trim().toLowerCase();
    const match = getPreQpProducts().find((product) => String(product.batch || product.batchNo || "").trim().toLowerCase() === normalizedPreQpSearch);
    if (match) {
      preQpSelectedProduct = match;
      renderStage("pre-qp");
      statusMessage.textContent = `Pre QP opened for ${match.batch}.`;
      return;
    }
    renderStage("pre-qp");
    statusMessage.textContent = "Pre QP filter updated.";
    return;
  }
  if (event.target.matches("[data-preqp-input], [data-preqp-material-check]")) {
    updatePreQpAvailability();
  }
  if (event.target.matches("[data-printer-search]")) {
    printerSearch = event.target.value;
    statusMessage.textContent = "Enter a B&S batch number and click Search.";
    return;
  }
  if (event.target.matches("[data-qp-id-search]")) {
    qpIdSearch = event.target.value;
    renderStage(currentStageId === "qp-certified" ? "qp-certified" : "qp-release");
    statusMessage.textContent = currentStageId === "qp-certified" ? "QP Certified Batches QP ID filter updated." : "QP Release QP ID filter updated.";
    return;
  }
  if (event.target.matches("[data-qp-status-search]")) {
    qpStatusSearch = event.target.value;
    renderStage(currentStageId === "qp-certified" ? "qp-certified" : "qp-release");
    statusMessage.textContent = currentStageId === "qp-certified" ? "QP Certified Batches status filter updated." : "QP Release status filter updated.";
    return;
  }
  if (event.target.matches("[data-qp-batch-search]")) {
    qpBatchSearch = event.target.value;
    renderStage(currentStageId === "qp-certified" ? "qp-certified" : "qp-release");
    statusMessage.textContent = currentStageId === "qp-certified" ? "QP Certified Batches BNS batch filter updated." : "QP Release BNS batch filter updated.";
    return;
  }
  if (event.target.matches("[data-qp-search]")) {
    qpBatchSearch = event.target.value;
    renderStage(currentStageId === "qp-certified" ? "qp-certified" : "qp-release");
    statusMessage.textContent = currentStageId === "qp-certified" ? "QP Certified Batches filter updated." : "QP Release filter updated.";
    return;
  }
});

document.querySelectorAll(".tab").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((item) => item.classList.toggle("active", item === button));
    document.querySelectorAll(".tab-panel").forEach((panel) => {
      panel.classList.toggle("active", panel.id === `${button.dataset.tab}-panel`);
    });
  });
});

startWireframe();

































































































































































